function ok=testConfiguredCombinedPUCCHReceptionCandidate(outputRoot)
% Actual encoded/decoded combined PUCCH component waveforms. Scheduling and
% CSI/HARQ/SR values are declared test inputs, not connected-runtime evidence.
setup6GRSimToolkit('Verbose',false);
assert(~isfolder(outputRoot),'test:EvidenceExists','Preserve earlier captures.');
mkdir(outputRoot);
request=struct('ReportConfigID',"installed_wideband_test",'Epoch',1, ...
    'CodebookType',"typeI-SinglePanel",'Ports',2,'Rank',1,'AllowedRanks',[1 2], ...
    'MaxRank',2,'ReportQuantity',"cri-RI-PMI-CQI",'NumCSIResources',4, ...
    'FrequencyGranularity',"wideband",'UCIChannel',"PUCCH");
installed=sixgr.phy.mimo.CSIReportConfiguration(request,1);
obligation=struct('ObservationID',"gnb_combined_capture",'ConfigurationEpoch',1, ...
    'HARQBitCount',2,'SRBitCount',1,'PriorityIndex',0, ...
    'CSIReportConfigID',installed.ReportConfigID,'CSIConfigurationEpoch',1);
context=buildConfiguredPUCCHReceiveContextCandidate(obligation,installed);
% Construct the receiver before any payload. This context stays byte-identical
% across different HARQ/SR values and the transmitter's rank choice.
digest=context.Digest;
fixture=sixgr.phy.pucch.PUCCHFixtureFactory.connected(2,int8(zeros(context.Sequence1Length,1)));
rxAssignment=sixgr.phy.pucch.PUCCHReceptionAssignment(struct( ...
    'ObservationID',obligation.ObservationID,'ResourceID',fixture.Assignment.Resource.ID, ...
    'RNTI',fixture.Report.Data.RNTI,'AbsoluteSlot0',0, ...
    'Source',"declared_gNB_component_obligation_and_installed_RRC", ...
    'TimingSource',"received_PUCCH_DMRS"),fixture.RRCContext,context);
audit=table();
for rank=1:2
    txRequest=request; txRequest.Rank=rank;
    txConfig=sixgr.phy.mimo.CSIReportConfiguration(txRequest,1);
    values=struct('CRI',2,'RI',rank,'CQI_CW0',9,'PMI',0);
    if rank==1, values.PMI=3; end
    csi=txConfig.build(values);
    harq=int8([rank-1;2-rank]); sr=int8(rank-1);
    d=fixture.Report.Data; d.ReportID="ue_report_"+rank;
    d.HARQACKReport=struct('Bits',harq);
    d.SchedulingRequestReports=struct('Bits',sr);
    d.CSIReports=struct('Part1Bits',csi.Part1Bits,'Part2Bits',csi.Part2Bits,'Priority',0,'ReportID',1);
    report=sixgr.phy.pucch.UCIReport(d);
    assignment=sixgr.phy.pucch.PUCCHTransmissionAssignment.fromCombinedUCI(report,fixture.UEContext,fixture.FrameState);
    tx=sixgr.phy.pucch.PUCCHTransmitter.transmit(fixture.Carrier,assignment,report);
    [waveform,~]=sixgr.link.addRuntimeComplexNoise(tx.Waveform,1e-8,91+rank,0,struct());
    rx=sixgr.phy.pucch.PUCCHReceiver.receive(waveform,fixture.Carrier,rxAssignment,context, ...
        'NoiseVariance',NaN,'NoiseVarianceMode','received_dmrs_estimate', ...
        'ChannelProfile','AWGN','DetectionThreshold',0.2);
    assert(rx.ReceiverOnlyAssignment && ~rx.OraclePayloadBitsUsed && rx.ReceiverUsable && ~rx.DTX && rx.CRCPassed);
    assert(isequal(rx.DecodedFields.HARQACK,harq) && isequal(rx.DecodedFields.SR,sr));
    decoded=installed.decode(rx.DecodedFields.CSIPart1,rx.DecodedFields.CSIPart2);
    assert(decoded.RI==rank && decoded.CRI==2 && decoded.CQI_CW0==9 && decoded.PMI==values.PMI);
    assert(context.Digest==digest && ...
        buildConfiguredPUCCHReceiveContextCandidate(obligation,txConfig).Digest==digest);
    save(fullfile(outputRoot,sprintf('combined_rank_%d.mat',rank)), ...
        'request','obligation','context','rxAssignment','report','tx','waveform','rx','decoded');
    row=table(rank,string(context.Digest),string(rx.AssignmentDigest),true, ...
        "declared_obligation_actual_PUCCH_component_not_integrated", ...
        'VariableNames',{'TransmittedRI','ReceiverContextDigest','ReceiverAssignmentDigest','BitsRecovered','EvidenceClass'});
    audit=[audit;row]; %#ok<AGROW>
end
bad=obligation; bad.ExpectedBits=int8([1;0]);
reject(@()buildConfiguredPUCCHReceiveContextCandidate(bad,installed),'sixgr:truth:InvalidPUCCHReceiveObligation');
bad=obligation; bad.CSIConfigurationEpoch=2;
reject(@()buildConfiguredPUCCHReceiveContextCandidate(bad,installed),'sixgr:truth:CSIReceiveConfigurationMismatch');
reject(@()buildConfiguredPUCCHReceiveContextCandidate(obligation,[]),'sixgr:truth:MissingInstalledCSIReceiveConfiguration');
reject(@()buildConfiguredPUCCHReceiveContextCandidate(obligation,installed.forTransport('PUSCH')), ...
    'sixgr:truth:CSIReceiveConfigurationMismatch');
writetable(audit,fullfile(outputRoot,'combined_receiver_context_audit.csv'));
fprintf('CONFIGURED_COMBINED_PUCCH_RX_PASS waveforms=2 ranks=1,2 constant_receiver_schema=1 HARQ_SR_CSI_bits_exact=1 integrated=0\n');
ok=true;
end
function reject(fn,id)
try, fn(); catch cause
    assert(strcmp(cause.identifier,id),'Expected %s; got %s: %s',id,cause.identifier,cause.message); return;
end
error('test:MissingRejection','Expected %s.',id);
end
