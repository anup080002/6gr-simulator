# Sample-clock measurement guard candidate

Base: 8412775e52ffba94f2cb9cb6dc9779d6ac54192a. Not integrated or uploaded.
The unchanged production CSI reducer still exhibits the preserved backdating
regression. This candidate alone does not close that defect.

Candidate causalMeasurementState adds KnownAtSample, ClockSampleRateHz,
ClockEpoch and SlotStartSamples knowledge inputs. SlotStartSamples must be
the exact OFDM calendar from sixgr.phy.frame.slotStartSample, including the
terminal boundary; it is not absolute slot times mean slot duration.
No new scenario knob or PHY setting is introduced.

Valid clocked rows require ObservationStartSample, ObservationEndSampleExclusive,
ObservationSampleRateHz, ResultAvailableAtSample and MeasurementClockEpoch.
The guard verifies complete-capture-before-result ordering, exact slot/sample
agreement, shared sample rate and epoch, finite exact sample indices, and
explicit binary validity flags. It refuses clocked rows with slot-only
knowledge rather than silently discarding sub-slot timing. It retains an
older eligible measurement until a newer result becomes available; in sample
mode it orders available results by actual result sample, then source slot.
Unclocked legacy slot-ledger semantics are retained and separately tested.

Candidate tests use DECLARED timing rows, not CSI-RS, UCI or RF execution.
Run 01 and 02 tested an initial equal-slot-length draft. That draft is
superseded and preserved as fixedslot_02_source.m.txt and
superseded_csi_sample_clock_fixedslot_draft.patch.txt. Run 03 passed the
revised nonuniform-calendar candidate (MATLAB exit 0).

pending_csi_sample_clock_guard.patch contains the revised function and unit
test under intended repo names. The transformed package form is not yet
executed. Do not apply it under an active full-suite process, and do not
claim runtime integration from the candidate unit test.

Required atomic integration:

1. Bind the clock columns only after actual CSI receiver completion, using
   the physical observation and shared owner's result event, not report
   source-slot arithmetic or transmitter payload. In the existing data path,
   localCompleteSharedDataPlan already possesses these real objects and calls
   receivedDataSymbolTiming. Independent CSI-RS reception still needs its own
   equivalent event when no PDSCH decoder runs.
2. Preserve those columns and the actual availability slot in the measurement
   ledger. Do not let applyCSIRSTrialImpl overwrite availability with Slot.
   Validate flags before logical conversion at publication as well.
3. Pass actual decision sample, epoch and executed OFDM calendar to every
   shared CSI consumer. Future-grant planning keeps current knowledge rather
   than borrowing the future transmit sample. Filter UE/resource/BWP/report
   configuration identity explicitly; this chronology helper is not the
   complete report reference-resource or codebook selection procedure.
4. Integrate periodic report generation, independent gNB UCI obligations and
   missing/retained measurement behavior with the existing CSI/HARQ candidates.
5. Register the final test, exercise actual received cross-slot and within-slot
   cases, then run mandatory final-source full/NR/integrity tests and 12 dB.

The NR-validation and result-integrity skills guided fail-closed clock
validation and separation of declared unit fixtures from waveform evidence.
