function auditStagedCode
% Parse only: do not add staged packages to the MATLAB path or execute them.
stage = 'C:/Users/anup0/AppData/Local/Temp/sixgr_type2_mapping_probe_94c9cc53573247c6b73a9ecb12de0ff4/consolidated_receiver_fields_stage_20260913';
base = 'C:/Users/anup0/AppData/Local/Temp/sixgr_type2_runtime_20260913';
files = dir(fullfile(stage,'**','*.m'));
assert(numel(files)==28,'Unexpected staged MATLAB file count.');
records = cell(numel(files),1);
for k = 1:numel(files)
    candidate = fullfile(files(k).folder,files(k).name);
    relative = candidate(numel(stage)+2:end);
    baseline = fullfile(base,relative);
    fprintf('ANALYZE %d/%d %s\n',k,numel(files),relative);
    stagedMessages = checkcode(candidate,'-id');
    baselineMessages = [];
    if isfile(baseline)
        baselineMessages = checkcode(baseline,'-id');
    end
    records{k} = struct('RelativePath',relative, ...
        'CandidateMessages',stagedMessages,'BaseMessages',baselineMessages);
    save(fullfile(pwd,'staged_code_analysis.mat'),'records','stage','base');
    fprintf('DIAGNOSTICS candidate=%d base=%d\n', ...
        numel(stagedMessages),numel(baselineMessages));
    for j = 1:numel(stagedMessages)
        fprintf('CANDIDATE %s\n',jsonencode(stagedMessages(j)));
    end
end
fprintf('ANALYZER_COMPLETED %d files; diagnostics retained, no runtime qualification.\n',numel(files));
end
