# Staged-source Code Analyzer evidence (2026-09-13)

Status: STATIC ANALYSIS COMPLETED; not integration or 12 dB qualification.

MATLAB R2026a, JVM disabled, single computational thread, session 80898,
terminal exit 0. `auditStagedCode.m` checked all 28 MATLAB files in the
31-file consolidated receiver-fields stage and the corresponding existing
base files at revision 8412775e52ffba94f2cb9cb6dc9779d6ac54192a.
The staged packages were not added to the MATLAB path or executed.
All three full-suite source checkouts and running processes were preserved.

`staged_code_analysis.mat` retains the complete candidate and baseline
diagnostics, including line positions, for every file. The log retains all
candidate diagnostics. There were 481 candidate diagnostics, including 28
environment warnings: the configured R2025b Code Analyzer settings file
could not be read, so the analyzer used its defaults. No settings were changed.
No syntax-error diagnostic was reported. This is not an assertion that the
files are warning-free or that the staged runtime is correct.

All existing-file diagnostic counts matched their base counts. Comparison
by diagnostic ID and message found only changed line references in four
alignment messages and one duplicate-case message. New files contributed
the environment warnings, four unnecessary-comma suggestions, and one
isscalar suggestion. The duplicate PDCCHCausalGrantDecodeOk case value is
pre-existing and appears twice within the same case arm. Unreachable-code
and nonscalar-operator warnings also remain in the base and candidate.

The consolidated patch remains UNAPPLIED / UNCOMMITTED / NOT PUSHED.
Its SHA256 is
5EA5813188879975534E0365A7BE32ECD091D3F4ADD5806B270EF84A6FEEADD3.
A fresh `git apply --check --whitespace=error` against the base checkout
passed without applying it. Full-source testAll, integrated shared HARQ,
CSI timing/calendar, detector false/missed-ACK qualification, measurement
closure, and the actual 12 dB execution are still required.
