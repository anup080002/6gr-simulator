function ok=testUCIDecoderCRCCandidate(outputRoot)
% Actual UCI coding/decoding, including corrupted soft bits. Not an RF run.
setup6GRSimToolkit('Verbose',false);
assert(~isfolder(outputRoot),'test:EvidenceExists','Preserve earlier decoder evidence.');
mkdir(outputRoot); audit=table(); rejected=0;
for A=[1 2 3 11 12 19 20 359 360 1013 1706]
    E=max(96,4*A); payload=int8(mod((1:A).',2));
    coded=nrUCIEncode(payload,E);
    % Replace small-block placeholders as a transmitter scrambler would.
    coded(coded==-1)=1;
    for k=find(coded==-2).', coded(k)=coded(k-1); end
    llr=12*(1-2*double(coded));
    [nativeBits,nativeErrors]=nrUCIDecode(llr,A);
    clean=UCIDecoderCRCCandidate.decode(llr,A);
    assert(isequal(clean.Bits,nativeBits) && isequal(clean.Bits,payload) && clean.CRCPassed);
    assert(clean.CRCApplicable==(A>=12));
    if A<12
        assert(isempty(clean.CodeBlockCRCError) && clean.CRCStatus=="not_applicable");
    else
        assert(isequal(clean.CodeBlockCRCError,logical(nativeErrors(:))));
        random=RandStream('mt19937ar','Seed',12000+A);
        badLLR=randn(random,E,1);
        [badBits,badErrors]=nrUCIDecode(badLLR,A);
        bad=UCIDecoderCRCCandidate.decode(badLLR,A);
        original=sixgr.phy.pucch.UCIDecoder.decode(badLLR,A);
        assert(isequal(bad.Bits,badBits) && isequal(bad.CodeBlockCRCError,logical(badErrors(:))) && ...
            bad.CRCPassed==~any(badErrors(:)));
        assert(original.CRCPassed,'Baseline wrapper reproduces its unconditional CRC flag.');
        rejected=rejected+double(any(badErrors(:)));
        save(fullfile(outputRoot,sprintf('uci_A%d.mat',A)), ...
            'A','E','payload','llr','clean','badLLR','badBits','badErrors','bad','original');
        row=table(A,E,numel(badErrors),any(badErrors(:)),original.CRCPassed,bad.CRCPassed, ...
            'VariableNames',{'A','E','CodeBlocks','NativeCRCError','OriginalReportedPass','CandidateReportedPass'});
        audit=[audit;row]; %#ok<AGROW>
    end
end
assert(rejected>=1,'test:CRCFailureNotExercised','The fixed corrupted inputs must expose an actual CRC failure.');
empty=UCIDecoderCRCCandidate.decode(zeros(0,1),0);
assert(~empty.CRCApplicable && isempty(empty.Bits) && isempty(empty.CodeBlockCRCError));
writetable(audit,fullfile(outputRoot,'uci_crc_disposition_audit.csv'));
fprintf('UCI_CRC_CANDIDATE_PASS coding_cases=11 actual_corrupted_CRC_failures=%d native_bits_and_flags_preserved=1 integrated=0\n',rejected);
ok=true;
end
