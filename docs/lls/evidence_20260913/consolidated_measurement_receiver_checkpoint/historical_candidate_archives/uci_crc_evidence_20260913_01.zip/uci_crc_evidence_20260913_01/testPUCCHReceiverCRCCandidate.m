function ok=testPUCCHReceiverCRCCandidate(outputRoot)
% Actual waveform positive/negative CRC boundary; no link qualification claim.
setup6GRSimToolkit('Verbose',false);
assert(~isfolder(outputRoot),'test:EvidenceExists','Preserve earlier evidence.');
mkdir(outputRoot); audit=table();
bits=int8(mod((1:32).',2));
configured=sixgr.phy.pucch.PUCCHFixtureFactory.connected(2,bits,'RNTI',321);
context=sixgr.phy.pucch.UCIReportContext(struct('ReportID',"gnb_crc_observation", ...
    'ConfigurationEpoch',1,'Sequence1Length',32,'Sequence2Length',0, ...
    'HARQACKBits',32,'SRBits',0,'CSIPart1Bits',0,'CSIPart2Bits',0,'PriorityIndex',0));
assignment=sixgr.phy.pucch.PUCCHReceptionAssignment(struct( ...
    'ObservationID',"gnb_crc_observation",'ResourceID',configured.Assignment.Resource.ID, ...
    'RNTI',321,'AbsoluteSlot0',0,'Source',"declared_gNB_CRC_component", ...
    'TimingSource',"received_PUCCH_DMRS"),configured.RRCContext,context);
for rnti=[321 322]
    transmitter=sixgr.phy.pucch.PUCCHFixtureFactory.connected(2,bits,'RNTI',rnti);
    tx=sixgr.phy.pucch.PUCCHTransmitter.transmit(transmitter.Carrier,transmitter.Assignment,transmitter.Report);
    [waveform,~]=sixgr.link.addRuntimeComplexNoise(tx.Waveform,1e-8,18000+rnti,0,struct());
    args={'NoiseVariance',NaN,'NoiseVarianceMode','received_dmrs_estimate', ...
        'ChannelProfile','AWGN','DetectionThreshold',0.2};
    original=sixgr.phy.pucch.PUCCHReceiver.receive(waveform,configured.Carrier,assignment,context,args{:});
    candidate=PUCCHReceiverCRCCandidate.receive(waveform,configured.Carrier,assignment,context,args{:});
    assert(isequaln(original.DecodedSequence1,candidate.DecodedSequence1) && ...
        original.DetectionMetric==candidate.DetectionMetric && original.DTX==candidate.DTX && ...
        isequaln(original.ChannelEstimate,candidate.ChannelEstimate) && ...
        original.GridNoiseVariance==candidate.GridNoiseVariance);
    assert(candidate.CRCApplicable && numel(candidate.CodeBlockCRCError)==1);
    assert(~candidate.DTX && candidate.ReceiverUsable,'Test must exercise a detected waveform, not hide CRC failure as DTX.');
    assert(candidate.CRCPassed==(rnti==321));
    assert(original.CRCPassed,'Original decoder reproduces the unconditional pass.');
    if rnti==321, assert(isequal(candidate.DecodedSequence1,bits)); end
    save(fullfile(outputRoot,sprintf('rnti_%d.mat',rnti)), ...
        'bits','context','assignment','tx','waveform','original','candidate');
    row=table(rnti,candidate.DTX,original.CRCPassed,candidate.CRCPassed,candidate.CodeBlockCRCError, ...
        'VariableNames',{'TransmitterRNTI','DTX','OriginalReportedCRCPass','CandidateReportedCRCPass','NativeCodeBlockCRCError'});
    audit=[audit;row]; %#ok<AGROW>
end
writetable(audit,fullfile(outputRoot,'actual_pucch_crc_audit.csv'));
fprintf('ACTUAL_PUCCH_CRC_CANDIDATE_PASS desired_pass=1 wrong_RNTI_CRC_rejected=1 waveform_detected_in_both=1 receiver_bits_power_noise_unchanged=1 integrated=0\n');
ok=true;
end
