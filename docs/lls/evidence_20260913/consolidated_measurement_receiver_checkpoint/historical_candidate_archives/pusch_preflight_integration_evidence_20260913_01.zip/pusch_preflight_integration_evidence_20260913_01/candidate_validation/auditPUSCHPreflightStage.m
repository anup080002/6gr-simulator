function auditPUSCHPreflightStage
% Parse only. The other staged packages are not executed by this audit.
stage='C:/Users/anup0/AppData/Local/Temp/sixgr_type2_mapping_probe_94c9cc53573247c6b73a9ecb12de0ff4/consolidated_pusch_preflight_stage_20260913';
base='C:/Users/anup0/AppData/Local/Temp/sixgr_type2_runtime_20260913';
files=dir(fullfile(stage,'**','*.m'));
assert(numel(files)==35);
records=cell(numel(files),1);
for k=1:numel(files)
    candidate=fullfile(files(k).folder,files(k).name);
    relative=candidate(numel(stage)+2:end);
    fprintf('ANALYZE %d/%d %s\n',k,numel(files),relative);
    messages=checkcode(candidate,'-id');
    baseline=[];
    if isfile(fullfile(base,relative)), baseline=checkcode(fullfile(base,relative),'-id'); end
    records{k}=struct('RelativePath',relative,'CandidateMessages',messages,'BaseMessages',baseline);
    for j=1:numel(messages), fprintf('CANDIDATE %s\n',jsonencode(messages(j))); end
    save(fullfile(pwd,'pusch_preflight_stage_analysis.mat'),'records','stage','base');
end
fprintf('PUSCH_PREFLIGHT_STAGE_ANALYSIS_COMPLETED %d files; no radio-path qualification\n',numel(files));
end
