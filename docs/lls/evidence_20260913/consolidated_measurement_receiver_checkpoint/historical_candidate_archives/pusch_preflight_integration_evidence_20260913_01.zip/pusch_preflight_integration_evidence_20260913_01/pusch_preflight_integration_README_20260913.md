# PUSCH feedback preflight and decode/scoring separation

Status: STAGED / UNAPPLIED / UNCOMMITTED / NOT PUSHED. This is not a 12 dB pass.

Base revision: 8412775e52ffba94f2cb9cb6dc9779d6ac54192a.
Stage: consolidated_pusch_preflight_stage_20260913, 38 files (35 MATLAB, 3 YAML fixtures).
Patch: pending_consolidated_pusch_preflight_20260913.patch.
SHA256: A260106E64F84EC7211FD5ADF79C0443A387B4985B2FD27E319059B3EF58AC55.
Git application check with --whitespace=error passed without applying the patch.
Git stat: 1979 insertions, 186 deletions.
This candidate retains all 34 files from the previous shared HARQ-only PUCCH
candidate. All prior stages, successful evidence and failed attempts remain preserved.

## Defect and implementation

The existing PUSCH HARQ consumer checked one reservation and immediately
mutated its HARQ handle. An invalid later reservation, timeline association,
or process reference could throw after an earlier process had already changed.
Its PUSCHUCIDecodeOk and CombinedDecodeOK exports also used transmitted-bit
agreement, incorrectly marking a usable false ACK as undecoded.

The new preparePUSCHHARQACKBindings helper validates all legacy reservation
identities, owners, clocks, flags, and timeline associations without mutation.
The consumer validates every HARQ process reference before its mutation loop.
It then consumes the prepared indices instead of discovering late binding
failures mid-loop. Expected and received bits are checked before int8 conversion;
fractional values cannot round into valid bits. Decode flags use receiver
usability. UCIContentMatch, FalseAck/FalseNack, bit-error counts and scoring
Status remain separate and still expose incorrect decoded content.

This fixes preflight coverage for the listed binding/process failures. It is
not a transaction guarantee for arbitrary later scheduler/export exceptions.
The helper explicitly does not qualify the legacy row-to-bit association as
independent Type-2. Complete shared gNB association, gap/UL-DAI handling and
combined CSI/SR/PUSCH receive hypotheses remain separate unfinished work.
No radio gain, noise, channel profile, detector threshold, scenario policy,
proxy label or qualification gate was changed.

## Execution evidence

All batches used MATLAB R2026a, -nojvm -singleCompThread, without toolkit or
simulator initialization. Existing full-suite processes/checkouts were untouched.

1. Candidate session 89445, exit 0:
   - testPUSCHHARQACKBindingPreflight passed: reordered rows, 13 negative
     guards, no invented timeline, and unchanged read-only inputs.
   - testPUSCHHARQACKPreflightReducer passed against the exact staged
     CoupledTruthRuntime class; the selected class path was asserted.
     It used real HARQ entity handles, declared MAC/TB reservations, and
     nrUCIEncode/decodeUCIWithEvidence with ideal declared LLRs.
     Five negative cases (bad later due slot, missing later timeline row,
     invalid later HARQ process, fractional expected bits, fractional decoded
     bits) left HARQ statistics/processes unchanged. A valid decoded vector
     [1,1] against expected [1,0] applied two ACKs and cleared the matching
     buffers, while preserving the second bit as a false ACK/scoring FAIL.
     Both bits retained true receiver decode flags. No PUCCH transmission
     was claimed by the PUSCH reducer.
2. Base revision session 46917, exit 1 (expected regression reproduction):
   - The identical reducer test ran against the base class with its selected
     class path asserted. It failed at line 45, the no-mutation assertion
     immediately after rejecting the bad second due-slot binding.
   - This is preserved failing baseline evidence, not a passing candidate run.
3. Analyzer session 88266, exit 0:
   - All 35 staged MATLAB files and matching base files were analyzed.
   - Complete diagnostics are in pusch_preflight_stage_analysis.mat/log.
   - 494 diagnostics retained, including 35 environmental settings-file
     warnings; the configured R2025b Code Analyzer settings file was unreadable
     and MATLAB used defaults. No settings or suppressions were changed.
   - No syntax-error diagnostics. No additional ID/message diagnostics in
     existing files after accounting for shifted line references.

The tested class/helper/two focused tests were SHA256-equal to the staged
sources after all validation completed. The larger existing
testLLSPUSCHHARQACKRuntimeFeedback was extended with the same regression guards
but has NOT been executed on this revision. Both focused tests were registered
in staged testAll; no final-source full suite has yet run.

## Still required

This is a MAC/UCI coding/reducer regression, not PUSCH radio, shared waveform,
3GPP conformance, integrated measurement, or 12 dB qualification. The previous
shared HARQ-only PUCCH preparation/completion patch still needs actual execution.
Combined CSI/SR and full PUSCH Type-2 mapping, detector false/missed-ACK
qualification, CSI timing/calendar, all-measurement closure, final-source
testAll and applicable config/NR/strict/grant/export/E2E tests remain required.
The full 12 dB run, same-chain sweep, final consolidation/commit/push, and later
long all-impairments study remain unfinished and the overall goal is unchanged.
