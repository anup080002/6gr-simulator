# PRACH native allocation retention candidate

Base revision: 8412775e52ffba94f2cb9cb6dc9779d6ac54192a.
Status: isolated actual standalone comparison passed; not integrated/uploaded.

The PRACH detection runner discarded exact TX-grid objects after its per-RO
channel/detector work. The generator already retained native grid, Toolbox
indices, OFDM timing, waveform and normalized waveform-port grid. Candidate
runPRACHLLS retains observed allocation rows only after each active serving
or interfering transmitter is actually added to the receive waveform sum.
The detector reference template and noise-only detector create no TX rows.

Each allocation is identified by scenario/SNR/threshold/trial/RO ordinals,
transmitter role and UE. Seed, configured study SNR, threshold, preamble,
study design and DPI remain explicit extra fields. SNR is an operating-point
parameter here, not a newly measured SINR. Waveform hashes remain labelled at
the generator plane before power control, spatial projection and RF.

ZC-DPE now also retains its actually generated waveform-port grid and hash
plane metadata; no waveform samples, modulation, receiver or noise equation
are changed. Explicit fallback modulators are rejected for this primary
standard-waveform native allocation publication, not relabelled as truth.

## Executed comparison

Attempt 04 completed with MATLAB exit 0. Three isolated YAML fixtures inherit
the existing NR PRACH and study-item ZC-DPE scenarios:

- NR: one actual transmitted preamble, four native allocation rows, CSV/PNG.
- Noise only: zero actual preambles, zero allocation rows, no allocation CSV.
- ZC-DPE: one actual transmitted preamble, four native allocation rows, CSV/PNG.

For each case, TrialTable, ROTable and CorrelationTraceTable match the original
production implementation exactly after excluding ComputeLatency_ms only.
The actual no-transmission detector outcome is retained, not replaced by
synthetic successful results. Original/candidate MATs are preserved.
NR and ZC-DPE images were visually inspected and backed by their exact CSVs.
Existing ZC-DPE D=4/M=2 non-orthogonality warnings were preserved; no performance,
orthogonality, NR-conformance or 12 dB baseline qualification is claimed.

Earlier harness failures are preserved: attempt 01 used an unsupported YAML
num_trials key (removed; min_detection_trials retained); attempt 02 omitted
front-door ConfigHash/ScenarioID bindings; attempt 03 omitted the directory
needed to save a valid zero-transmission comparison. No production assertion
or physical setting was weakened to address these test-harness errors.

## Pending atomic integration

pending_prach_native_retention.patch contains the two producer changes, the
runSingle PRACH publication call, three portable test fixtures, the permanent
retention test and testAll registration. The transformed package form and
front-door runSingle adapter have not yet executed. Apply only after the
checkout's frozen full suite ends, then run all required tests plus the actual
PRACH matrix/front-door publication case. Additional multi-UE/interferer and
multi-attempt retention coverage remains useful before claiming that scope.

The earlier matrix warning was OPTIONAL browser publication: the terminal
log explicitly records that browser publication was not required, and
test6GScenarioMatrixRunner passed. Do not call it mandatory-gate bypass. The
missing native snapshot is still an output-coverage gap addressed by this
candidate. No synthetic allocation or policy-disable workaround was added.

Result-integrity guided the actual-TX-only export; NR-validation preserved
receiver and noise behavior; config-driven guidance kept fixture settings in
YAML and reused existing output policy. This is not a repaired-main receipt.
