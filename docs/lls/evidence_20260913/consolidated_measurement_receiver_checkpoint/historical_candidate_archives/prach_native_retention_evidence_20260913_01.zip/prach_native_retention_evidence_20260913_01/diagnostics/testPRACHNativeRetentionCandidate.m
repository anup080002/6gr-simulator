function ok=testPRACHNativeRetentionCandidate(root)
% Actual standalone generator/channel/detector executions, NOT a main 12 dB run.
setup6GRSimToolkit('Verbose',false);
assert(~isfolder(root),'test:PreserveExistingEvidence','Use a new output directory.');
mkdir(root);
folder=fileparts(mfilename('fullpath'));
fixtures=["prach_native_nr_fixture.yaml","prach_native_noise_fixture.yaml","prach_native_zcdpe_fixture.yaml"];
for k=1:numel(fixtures)
    scfg=sixgr.lls6g.config.loadScenarioConfig(fullfile(folder,fixtures(k)));
    target=fullfile(root,scfg.ScenarioID);
    mkdir(target); % Preserve comparison evidence even when there is no TX/CSV.
    cfg=sixgr.lls6g.buildInternalConfig(scfg,target);
    % Match the front-door runner's resolved execution identity; never
    % invent a hash from a rendered table or from expected test results.
    cfg.meta.configHash=char(scfg.ConfigHash);
    cfg.run.scenarioID=char(scfg.ScenarioID);
    scenario=struct('ScenarioName',char(scfg.ScenarioID));
    original=sixgr.rach.runPRACHLLS(cfg,'WriteOutputs',false,'ScenarioMatrix',scenario,'Verbose',false);
    candidate=runPRACHLLSNativeCandidate(cfg,'WriteOutputs',false,'ScenarioMatrix',scenario,'Verbose',false);
    for field=["TrialTable","ROTable","CorrelationTraceTable"]
        a=original.(field); b=candidate.(field);
        drop=intersect("ComputeLatency_ms",string(a.Properties.VariableNames));
        if ~isempty(drop), a=removevars(a,drop); b=removevars(b,drop); end
        assert(isequaln(a,b),'test:NativeCaptureChangedPHY','Capture altered %s.',field);
    end
    T=candidate.ObservedREAllocationTable;
    transmitted=nnz(candidate.TrialTable.preamble_tx_present);
    if transmitted==0
        assert(isempty(T),'test:InventedNativePRACH','Reference/noise-only waveform must not become a transmission.');
    else
        assert(numel(unique(T.allocation_id))==transmitted);
        assert(all(T.PRACHStudyTransmitterRole=="serving") && all(T.grid_domain=="prach_native_ofdm"));
        assert(all(T.PRACHStudySeed==candidate.ROTable.seed(1)));
        assert(all(T.PRACHStudyDesign==candidate.ROTable.prach_design(1)));
        assert(all(strlength(T.waveform_sha256)==64));
    end
    layout=verifyObservedREPublication(T,cfg,target);
    if transmitted>0
        [status,message]=system(sprintf('python "%s" "%s"', ...
            fullfile(pwd,'tests','verify_native_prach_publication.py'),layout.ReportCSVDir));
        assert(status==0,'test:NativePRACHPublication','%s',message); fprintf('%s',message);
    end
    save(fullfile(target,'native_retention_comparison.mat'),'original','candidate');
    fprintf('PRACH_NATIVE_RETENTION_CASE_PASS fixture=%s actual_tx=%d allocation_rows=%d PHY_equal=1\n', ...
        fixtures(k),transmitted,height(T));
end
fprintf('PRACH_NATIVE_RETENTION_CANDIDATE_PASS standalone_PHY_and_CSV_PNG_only integrated=0 main_12db_qualified=0\n');
ok=true;
end
