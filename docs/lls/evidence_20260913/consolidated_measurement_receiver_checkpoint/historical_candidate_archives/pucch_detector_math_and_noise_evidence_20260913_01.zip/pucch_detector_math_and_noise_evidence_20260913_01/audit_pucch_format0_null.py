"""Mathematical null-statistic audit, NEVER PHY or conformance evidence.

The ideal white complex-Gaussian model is deliberately separate from the
retained physical-receiver CSV. No IQ, decoder outcome or primary KPI is edited.
"""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import numpy as np
import scipy
from scipy.fft import irfft, next_fast_len, rfft
from scipy.io import loadmat
from scipy.special import beta as beta_function
from scipy.stats import beta, binom


def sha256(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def interval(count, total, alpha=0.001):
    return [0.0 if count == 0 else float(beta.ppf(alpha / 2, count, total-count+1)),
            1.0 if count == total else float(beta.ppf(1-alpha / 2, count+1, total-count))]


def correlation_tail_bounds(length, blocks, threshold, bins):
    # For a unit vector and isotropic CN(0,I_L) noise, |rho|^2 ~ Beta(1,L-1).
    # Quantize |rho| downwards, convolve blocks, and bound rounding error.
    edges = np.linspace(0.0, 1.0, bins+1)
    mass = -np.diff(np.power(1-edges*edges, length-1))
    size = blocks*(bins-1)+1
    distribution = irfft(rfft(mass, next_fast_len(size))**blocks,
                         next_fast_len(size))[:size]
    numerical_error = max(abs(float(distribution.sum())-1),
                          abs(min(float(distribution.min()), 0)))
    assert numerical_error < 1e-10
    distribution = np.maximum(distribution, 0)
    cutoff = blocks*threshold*bins
    lower = float(distribution[int(np.ceil(cutoff)):].sum())
    upper = float(distribution[max(0, int(np.ceil(cutoff-blocks))):].sum())
    return {'lower': lower, 'upper': upper, 'bins': bins,
            'fft_mass_or_negativity_error': numerical_error}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--native-source', type=Path, required=True)
    parser.add_argument('--samples', type=int, default=2000000)
    parser.add_argument('--seed', type=int, default=20260913)
    args = parser.parse_args()
    assert args.samples >= 100000
    assert not args.output.exists(), 'Preserve earlier audit outputs'
    config_path = args.evidence/'configuration.mat'
    config = loadmat(config_path, variable_names=['resource', 'nr'], simplify_cells=True)
    resource = config['resource']
    assert resource['format'] == 0 and resource['nrof_prbs'] == 1
    assert resource['intra_slot_hopping'] == 0
    length = 12
    blocks = int(resource['nrof_symbols'])*int(config['nr'])
    with (args.evidence/'noise_trials.csv').open(newline='', encoding='utf-8-sig') as stream:
        rows = list(csv.DictReader(stream))
    thresholds = {float(row['DetectionThreshold']) for row in rows}
    assert len(thresholds) == 1
    threshold = thresholds.pop()
    assert {int(row['HARQBits']) for row in rows} == {1, 2}
    assert all(int(row['SignalPresent']) == 0 for row in rows)
    assert all(int(row['Detected']) == (float(row['DetectionMetric']) >= threshold) for row in rows)
    with (args.evidence/'noise_summary.csv').open(newline='', encoding='utf-8-sig') as stream:
        summaries = {int(row['HARQBits']): row for row in csv.DictReader(stream)}
    retained = {}
    for bits in [1, 2]:
        case = [row for row in rows if int(row['HARQBits']) == bits]
        detected = sum(int(row['Detected']) for row in case)
        ack_bits = sum(int(row['FalseACKBits']) for row in case)
        any_ack = sum(int(row['FalseACKBits']) > 0 for row in case)
        summary = summaries[bits]
        assert detected == int(summary['FalseDetections'])
        assert ack_bits == int(summary['FalseACKBits'])
        assert any_ack == int(summary['OccasionsWithFalseACK'])
        retained[bits] = dict(occasions=len(case), false_detections=detected,
                              false_ack_bits=ack_bits, any_ack_occasions=any_ack,
                              false_ack_bit_fraction=ack_bits/(bits*len(case)))
    bound = correlation_tail_bounds(length, blocks, threshold, 16384)
    rng = np.random.default_rng(args.seed)
    counts = {bits: {'detections': 0, 'false_ack_bits': 0, 'any_ack': 0} for bits in [1, 2]}
    one_hypothesis = 0
    r2_sum = 0.0
    r_sum = 0.0
    completed = 0
    # Complete orthonormal basis energy shares follow Dirichlet(1,...,1).
    # Coordinates [0,1,2,3] label the four HARQ-only hypotheses; [0,3]
    # is the one-bit pair. Their exchangeability, not an actual sequence
    # generator or transmitted payload, supplies this ideal-null model.
    while completed < args.samples:
        count = min(4096, args.samples-completed)
        energy = rng.exponential(size=(count, blocks, length))
        energy /= energy.sum(axis=2, keepdims=True)
        projections = np.sqrt(energy[:, :, :4])
        metric = projections.mean(axis=1)
        r2_sum += float(energy[:, :, 0].sum())
        r_sum += float(projections[:, :, 0].sum())
        one_hypothesis += int(np.count_nonzero(metric[:, 0] >= threshold))
        for bits in [1, 2]:
            current = metric[:, [0, 3]] if bits == 1 else metric
            detected = current.max(axis=1) >= threshold
            winner = current.argmax(axis=1)
            bit_count = winner if bits == 1 else (winner & 1)+((winner >> 1) & 1)
            counts[bits]['detections'] += int(np.count_nonzero(detected))
            counts[bits]['false_ack_bits'] += int(bit_count[detected].sum())
            counts[bits]['any_ack'] += int(np.count_nonzero(detected & (winner != 0)))
        completed += count
    single_interval = interval(one_hypothesis, args.samples)
    assert single_interval[0] <= bound['upper'] and single_interval[1] >= bound['lower']
    expected_r = (length-1)*float(beta_function(1.5, length-1))
    assert abs(r2_sum/(args.samples*blocks)-1/length) < 0.001
    assert abs(r_sum/(args.samples*blocks)-expected_r) < 0.001
    model = {}
    for bits in [1, 2]:
        count = counts[bits]
        detection = count['detections']/args.samples
        actual = retained[bits]
        model[bits] = dict(count, samples=args.samples,
            detection_probability=detection,
            detection_probability_interval_99_9_percent=interval(count['detections'], args.samples),
            false_ack_bit_fraction=count['false_ack_bits']/(bits*args.samples),
            # Under the isotropic null the winning labels are exchangeable.
            expected_false_ack_bit_fraction_from_label_symmetry=detection/2,
            expected_any_ack_probability_from_label_symmetry=detection*(1-1/(2**bits)),
            single_hypothesis_union_bound=(2**bits)*bound['upper'],
            predicted_512_occasion_detection_count_interval_99_percent=[
                float(x) for x in binom.interval(0.99, actual['occasions'], detection)])
    result = dict(scope='mathematical_ideal_iid_null_model_NOT_PHY_or_conformance',
        status='independent_count_recheck_and_null_statistic_consistency_pass',
        conformance_qualified=False, production_receiver_changed=False,
        configuration=dict(sequence_length=length, ofdm_symbols=int(resource['nrof_symbols']),
                           receive_branches=int(config['nr']), blocks=blocks, threshold=threshold),
        assumptions=['IID circular complex Gaussian samples after OFDM extraction',
                     'independent symbol/antenna blocks', 'HARQ-only orthogonal reference hypotheses',
                     'negligible additive epsilon in correlation normalization',
                     'no colored noise, interference, nonlinearity, timing search or acquired synchronization'],
        limitations=['does not replay retained IQ through the receiver',
                     'does not qualify signal-present missed ACK or an integrated 12 dB run',
                     'does not recommend or modify a detector threshold',
                     'retained one/two-bit cases reuse the same occasions, not independent repetitions',
                     'a binomial interval applies to model occasions, not correlated ACK bits'],
        seed=args.seed, numpy=np.__version__, scipy=scipy.__version__,
        single_hypothesis_tail_bounds=bound,
        single_hypothesis_simulated_probability=one_hypothesis/args.samples,
        single_hypothesis_interval_99_9_percent=single_interval,
        normalized_projection_mean=r_sum/(args.samples*blocks),
        normalized_projection_expected_mean=expected_r,
        normalized_projection_energy_mean=r2_sum/(args.samples*blocks),
        retained_receiver_counts=retained, mathematical_model=model,
        input_sha256={str(path): sha256(path) for path in [
            config_path, args.evidence/'noise_trials.csv', args.evidence/'noise_summary.csv',
            args.evidence/'source_provenance.json', args.native_source]},
        script_sha256=sha256(Path(__file__)))
    args.output.mkdir(parents=True)
    with (args.output/'audit.json').open('w', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
