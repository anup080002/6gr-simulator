"""Read-only, bounded-memory noise-IQ audit; not a PHY acceptance gate."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

import h5py
import numpy as np
from scipy.io import loadmat


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def complex_json(value):
    return {'real': value.real.tolist(), 'imag': value.imag.tolist()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    with (args.evidence/'noise_trials.csv').open(newline='', encoding='utf-8-sig') as stream:
        rows = list(csv.DictReader(stream))
    unique = [row for row in rows if int(row['HARQBits']) == 1]
    samples = {int(row['IQRowCount']) for row in unique}
    branches = {int(row['ReceiveBranches']) for row in unique}
    variances = {float(row['InjectedSampleNoiseVariance']) for row in unique}
    hashes = {row['IQSHA256'].lower() for row in rows}
    assert len(samples) == len(branches) == len(variances) == len(hashes) == 1
    slot_length, nr, variance = samples.pop(), branches.pop(), variances.pop()
    iq_path = args.evidence/'noise_observations.mat'
    iq_hash = digest(iq_path)
    assert iq_hash == hashes.pop()
    assert all(int(row['IQFirstRow']) == 1+i*slot_length for i, row in enumerate(unique))
    total = len(unique)*slot_length
    sum_x = np.zeros(nr, complex)
    cross = np.zeros((nr, nr), complex)
    pseudo = cross.copy()
    fourth = np.zeros(nr)
    lag = np.zeros(nr, complex)
    left_sum = lag.copy()
    right_sum = lag.copy()
    lag_count = len(unique)*(slot_length-1)
    with h5py.File(iq_path, 'r') as source:
        data = source['IQ']
        assert data.shape == (nr, total)
        for first in range(0, len(unique), 16):
            count = min(16, len(unique)-first)
            packed = data[:, first*slot_length:(first+count)*slot_length]
            x = packed['real']+1j*packed['imag']
            assert np.isfinite(x).all()
            sum_x += x.sum(axis=1)
            cross += x @ x.conj().T
            pseudo += x @ x.T
            fourth += (np.abs(x)**4).sum(axis=1)
            within_slot = x.reshape(nr, count, slot_length)
            left, right = within_slot[:, :, :-1], within_slot[:, :, 1:]
            lag += (right*left.conj()).sum(axis=(1, 2))
            left_sum += left.sum(axis=(1, 2))
            right_sum += right.sum(axis=(1, 2))
    mean = sum_x/total
    covariance = cross/total-np.outer(mean, mean.conj())
    pseudocovariance = pseudo/total-np.outer(mean, mean)
    power = covariance.diagonal().real
    scale = np.sqrt(np.outer(power, power))
    lag_covariance = lag/lag_count-(right_sum/lag_count)*(left_sum/lag_count).conj()
    # Only the last occasion's complete replay was retained. Its exact
    # recorded gain is audit evidence, never an input to a practical decoder.
    terminal_path = args.evidence/'terminal.mat'
    replay = loadmat(terminal_path, variable_names=['execution'],
                     simplify_cells=True)['execution']['RX']['Replay']
    trace = replay['AGCStreamTrace']
    assert replay['RFAppliedStageCount'] == 1 and replay['AGCApplied'] == 1
    assert int(trace['StartSample']) == int(unique[-1]['StartSample'])
    assert int(trace['EndSampleExclusive']) == int(unique[-1]['EndSampleExclusive'])
    gain_db = np.asarray(trace['AppliedGain_dB'], dtype=float).reshape(-1)
    assert gain_db.size == slot_length and np.isfinite(gain_db).all()
    with h5py.File(iq_path, 'r') as source:
        packed = source['IQ'][:, -slot_length:]
        last_post = packed['real']+1j*packed['imag']
    inverse_gain_audit_only = last_post/(10**(gain_db/20))[None, :]
    recovered_power = (np.abs(inverse_gain_audit_only)**2).mean(axis=1)
    recorded_pre_power = np.asarray(replay['PreRFMeanSamplePowerPerBranch_mW']).reshape(-1)
    relative_error = np.abs(recovered_power-recorded_pre_power)/recorded_pre_power
    assert np.all(relative_error < 1e-12)
    result = dict(scope='retained_receiver_noise_IQ_moment_audit_NOT_conformance',
        status='byte_identity_shape_finiteness_and_moment_recomputation_complete',
        physical_capture_sha256=iq_hash, samples_per_branch=total,
        receive_branches=nr, distinct_recorded_occasions=len(unique),
        declared_injected_sample_noise_variance=variance,
        measured_centered_power=power.tolist(), power_ratio_to_declared_variance=(power/variance).tolist(),
        mean=complex_json(mean), covariance=complex_json(covariance),
        normalized_branch_correlation=complex_json(covariance/scale),
        normalized_pseudocovariance=complex_json(pseudocovariance/scale),
        normalized_lag_one_covariance_within_slots=complex_json(lag_covariance/power),
        raw_fourth_moment_over_squared_raw_second_moment=(
            (fourth/total)/(cross.diagonal().real/total)**2).tolist(),
        last_occasion_agc_accounting=dict(
            coverage_occasions=1, total_recorded_occasions=len(unique),
            actual_agc_applied=True, actual_agc_time_varying=bool(replay['AGCGainIsTimeVarying']),
            start_sample=int(trace['StartSample']), end_sample_exclusive=int(trace['EndSampleExclusive']),
            applied_gain_db_range=[float(gain_db.min()), float(gain_db.max())],
            recorded_pre_rf_sample_power=recorded_pre_power.tolist(),
            inverse_recorded_gain_audit_power=recovered_power.tolist(),
            relative_power_reconstruction_error=relative_error.tolist(),
            replay_sha256=digest(terminal_path),
            scope='exact recorded per-sample gain inversion for audit only; no decoder inputs changed'),
        limitations=['moments do not prove Gaussianity, independence or false-ACK qualification',
                     'lag statistics exclude joins between retained slots',
                     'one/two-bit score layouts are not counted as separate IQ observations',
                     'post-RF IQ and declared pre-RF variance are different measurement planes',
                     'time-varying AGC prevents treating the ideal IID null model as exact RF replay',
                     'exact recorded gain inversion covers only the final retained occasion',
                     'no receiver replay, signal-present measurement or threshold modification'],
        numpy=np.__version__, h5py=h5py.__version__, script_sha256=digest(Path(__file__)))
    args.output.mkdir(parents=True)
    with (args.output/'audit.json').open('w', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
