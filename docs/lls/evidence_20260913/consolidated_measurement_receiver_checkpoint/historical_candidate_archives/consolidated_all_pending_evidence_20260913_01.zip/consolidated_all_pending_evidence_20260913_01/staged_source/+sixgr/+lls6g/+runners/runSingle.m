function out = runSingle(configPath, outputDir, runTag, executionOptions)
%RUNSINGLE Execute one config-driven 6G PHY LLS scenario.

if nargin < 2 || strlength(string(outputDir)) == 0
    outputDir = "results";
end
if nargin < 3
    runTag = "";
end
if nargin < 4 || ~isstruct(executionOptions)
    executionOptions = struct();
end

setup6GRSimToolkit("Verbose", false, "RunToolboxChecks", false);

scfg = sixgr.lls6g.config.loadScenarioConfig(configPath);
leaf = localResolveLeaf(runTag);
backend = lower(string(scfg.get("output.backend", "filesystem")));
backendOverride = lower(strtrim(string(getenv("SIXGR_OUTPUT_BACKEND_OVERRIDE"))));
if strlength(backendOverride) > 0
    if ~ismember(backendOverride, ["filesystem","mysql_web"])
        error("sixgr:lls6g:InvalidOutputBackendOverride", ...
            "SIXGR_OUTPUT_BACKEND_OVERRIDE must be filesystem or mysql_web, not '%s'.", char(backendOverride));
    end
    backend = backendOverride;
    scfg = localApplyOutputBackendOverride(scfg, backend);
end
resumeExisting = logical(sixgr.util.structGet(executionOptions, ...
    "ResumeCompletedRuntimeFinalization", false));
existingRunFolder = string(sixgr.util.structGet(executionOptions, ...
    "ExistingRunFolder", ""));
if resumeExisting
    if strlength(strtrim(existingRunFolder)) == 0 || ...
            exist(char(existingRunFolder), "dir") ~= 7
        error("sixgr:lls6g:runner:MissingResumeRunFolder", ...
            "ResumeCompletedRuntimeFinalization requires an existing ExistingRunFolder.");
    end
    if backend ~= "filesystem"
        error("sixgr:lls6g:runner:UnsupportedResumeBackend", ...
            "Completed-runtime finalization resume currently requires output.backend=filesystem.");
    end
    runFolder = char(existingRunFolder);
    logicalRunFolder = char(existingRunFolder);
    % Validate the requested resolved YAML against immutable row-level
    % runtime identity before any snapshot or report in the existing run is
    % touched.  This prevents a finalization retry from silently rebinding a
    % completed waveform to a different scenario revision.
    sixgr.truth.assertResumeConfigurationIdentity(runFolder, ...
        string(scfg.ScenarioID), string(scfg.ConfigHash));
    % Source identity must be checked before any finalization/report path
    % can rewrite derived files. Configuration equality alone is not enough
    % when production code changed after the waveform was sealed.
    sixgr.runtime.assertResumeSourceIdentity(runFolder);
else
    logicalRunFolder = localComposeRunFolderNoCreate(outputDir, "lls", scfg.ScenarioID, leaf);
    if backend == "mysql_web"
        % Filesystem artifacts are the durable primary publication even
        % when MySQL mirroring is active.  Running from an OS-temporary
        % staging tree made a database or hydration failure erase the only
        % complete evidence set.  The artifact store can mirror writes from
        % this public folder without changing their filesystem authority.
        runFolder = sixgr.report.defaultRunFolder(outputDir, ...
            "Bucket", "lls", ...
            "Profile", scfg.ScenarioID, ...
            "Leaf", leaf, ...
            "CleanExisting", true);
        logicalRunFolder = runFolder;
    else
        runFolder = sixgr.report.defaultRunFolder(outputDir, ...
            "Bucket", "lls", ...
            "Profile", scfg.ScenarioID, ...
            "Leaf", leaf, ...
            "CleanExisting", true);
    end
end

cleanupStaging = onCleanup(@() localCleanupDBOnlyRunFolders(backend, runFolder, logicalRunFolder)); %#ok<NASGU>
execOut = localExecutePreparedScenario(scfg, runFolder, leaf, logicalRunFolder, executionOptions);

out = struct();
out.Ok = logical(execOut.Ok);
out.RunFolder = string(logicalRunFolder);
out.Config = scfg;
out.Manifest = execOut.Manifest;
out.Profile = string(execOut.Profile);
out.Result = execOut.Result;
% Preserve the terminal status reduction on the public runner result.  The
% status is already computed and persisted by localExecutePreparedScenario;
% omitting it here forced callers to reopen a CSV/MAT file and caused a
% successful waveform execution to look like an API failure.
out.ScenarioStatus = execOut.ScenarioStatus;
end

function scfg = localApplyOutputBackendOverride(scfg, backend)
backend = lower(strtrim(string(backend)));
data = scfg.toStruct();
data = sixgr.util.structSet(data, "output.backend", char(backend));
switch backend
    case "filesystem"
        data = sixgr.util.structSet(data, "output.persistence_mode", "results_folder");
        data = sixgr.util.structSet(data, "output.persist_to_database", false);
        data = sixgr.util.structSet(data, "output.persist_to_results_folder", true);
    case "mysql_web"
        data = sixgr.util.structSet(data, "output.persistence_mode", "both");
        data = sixgr.util.structSet(data, "output.persist_to_database", true);
        data = sixgr.util.structSet(data, "output.persist_to_results_folder", true);
end
scfg = sixgr.lls6g.config.ScenarioConfig(data, ...
    "SourceFiles", scfg.SourceFiles, ...
    "ConfigPath", scfg.ConfigPath, ...
    "ConfigHash", localHashScenarioStruct(data), ...
    "Kind", scfg.Kind);
end

function cfgHash = localHashScenarioStruct(data)
txt = jsonencode(data);
try
    cfgHash = char(string(sixgr.util.sha256Hex(uint8(unicode2native(char(txt), "UTF-8")))));
catch ME
    error("sixgr:lls6g:ConfigHashUnavailable", ...
        "Unable to compute backend-overridden scenario config SHA-256 hash: %s", ME.message);
end
end

function result = localRunWaveformBundleScenario(cfg, scfg, runFolder, executionOptions)
if nargin < 4 || ~isstruct(executionOptions)
    executionOptions = struct();
end
opt = struct();
numerology = localResolveConfigNumerology(cfg);
slotDuration_s = double(numerology.SlotDurationSeconds);
totalSlots = max(1, round(double(sixgr.util.structGet(cfg, "run.totalSlots", ...
    sixgr.util.structGet(cfg, "run.numTTI", sixgr.util.structGet(cfg, "run.numFrames", 1))))));
opt.LinkDuration_s = max(double(totalSlots) * slotDuration_s, ...
    double(scfg.get("simulation.min_duration_s")));
opt.LinkMaxSimFrames = double(totalSlots);
opt.LinkSNR_dB = double(cfg.channel.snr_dB);
receiverNoiseMode = localUsesReceiverNoiseMeasurement(cfg);
controlledSNRGrid = localBuildSweepGrid(cfg.channel.snr_dB, ...
    double(scfg.get("simulation.snr_sweep_offsets_db")), ...
    logical(scfg.get("sweeps_and_matrix.snr_sweep.enabled", false)), ...
    double(scfg.get("sweeps_and_matrix.snr_sweep.values_db", [])));
if receiverNoiseMode
    opt.LinkSNRGrid_dB = localBuildPhysicalOperatingPointGrid(cfg.channel.snr_dB);
else
    opt.LinkSNRGrid_dB = controlledSNRGrid;
end
opt.LinkQualityMode = char(string(sixgr.util.structGet(cfg, "run.noiseOperatingMode", ...
    "receiver_noise_figure_thermal_noise")));
mcIterations = max(1, round(double(scfg.get("simulation.monte_carlo_iterations", 1))));
opt.LinkSweepFrames = mcIterations;
opt.LinkSweepTrialsPerSNR = max(double(totalSlots), double(totalSlots) * mcIterations);
if receiverNoiseMode
    opt.LinkReferenceSweepFrames = 0;
    opt.LinkSweepMaxPoints = 1;
else
    opt.LinkReferenceSweepFrames = max(opt.LinkSweepTrialsPerSNR, ceil(1.5 * opt.LinkSweepTrialsPerSNR));
    opt.LinkSweepMaxPoints = numel(opt.LinkSNRGrid_dB);
end
opt.LinkAdaptiveSweepEnabled = ~receiverNoiseMode;
opt.LinkAdaptiveSweepStep_dB = 2;
opt.LinkAdaptiveSweepMaxPoints = ternaryDouble(receiverNoiseMode, 1, 12);
snrSweepEnabled = logical(scfg.get("sweeps_and_matrix.snr_sweep.enabled", false));
referenceSweepEnabled = logical(sixgr.util.structGet(cfg, ...
    "run.referenceSweepEnabled", false));
fixedLinkEnabledDefault = referenceSweepEnabled && ...
    ((~receiverNoiseMode) || ...
    (snrSweepEnabled && numel(unique(controlledSNRGrid)) >= 2));
defaultFixedTrials = max(1, opt.LinkSweepTrialsPerSNR);
fixedLinkCampaignCfg = localResolveFixedLinkCampaignRuntimeConfig(scfg, cfg, controlledSNRGrid, ...
    fixedLinkEnabledDefault, defaultFixedTrials, totalSlots);
opt.LinkFixedLinkCampaignConfig = fixedLinkCampaignCfg;
opt.LinkFixedLinkCampaignEnabled = logical(sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "Enabled", sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "enabled", false)));
opt.FixedLinkCampaignOnly = logical(scfg.get("sweeps_and_matrix.fixed_link_calibration.only", ...
    sixgr.util.structGet(fixedLinkCampaignCfg, "Only", ...
    sixgr.util.structGet(fixedLinkCampaignCfg, "only", false))));
opt.LinkFixedLinkSNRGrid_dB = double(sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "SNR_dB", sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "snr_db", controlledSNRGrid)));
opt.LinkFixedLinkMinTrials = max(1, round(double(sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "MinTBPerPoint", sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "min_tb_per_point", defaultFixedTrials)))));
opt.LinkFixedLinkMaxTrials = max(opt.LinkFixedLinkMinTrials, ...
    round(double(sixgr.util.structGet(fixedLinkCampaignCfg, ...
    "MaxTBPerPoint", sixgr.util.structGet(fixedLinkCampaignCfg, ...
    "max_tb_per_point", defaultFixedTrials)))));
opt.LinkFixedLinkTrialsPerDrop = max(1, round(double(sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "BatchTBCount", sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "trials_per_drop", totalSlots)))));
opt.LinkFixedLinkErrorTarget = double(sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "MinErrorsForCI", sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "min_errors_for_ci", inf)));
opt.LinkFixedLinkCIWidthTarget = 2 * double(sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "MaxCIHalfWidth", sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "max_ci_half_width", inf)));
opt.LinkFixedLinkConfidenceLevel = double(sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "ConfidenceLevel", sixgr.util.structGet( ...
    fixedLinkCampaignCfg, "confidence_level", 0.95)));
targetBLER = double(sixgr.util.structGet(fixedLinkCampaignCfg, ...
    "TargetBLER", sixgr.util.structGet(fixedLinkCampaignCfg, ...
    "target_bler", 0.10)));
opt.LinkFixedLinkTargetBLER = targetBLER(1);
opt.LinkFixedLinkSeed = double(sixgr.util.structGet(fixedLinkCampaignCfg, "SeedBase", ...
    sixgr.util.structGet(fixedLinkCampaignCfg, "seeds", ...
    double(sixgr.util.structGet(cfg, "run.seed", 1)) + 730001)));
opt.LinkFixedLinkSeed = opt.LinkFixedLinkSeed(1);
opt.LinkAnchorCases = scfg.get("scenario.bundle_anchor_cases", {});
% The artifact-contract engine owns final raster production from verified
% runtime CSVs.  When it is enabled, do not let the waveform bundle emit the
% retired MATLAB diagnostic PNG set before the transactional materializer
% replaces the raster tree.  output.save_figures still means that final
% CSV-derived figures are requested; it is not permission for two producers.
contractRasterAuthority = logical(scfg.get( ...
    "output.artifact_contract_engine.enabled", false));
publicationPolicy = sixgr.lls6g.runners.resolveWaveformBundlePublicationPolicy( ...
    cfg, contractRasterAuthority);
opt.SaveFigures = publicationPolicy.SaveFigures;
opt.LiveCSVPNGEnabled = publicationPolicy.LiveCSVPNGEnabled;
tuning = sixgr.lls6g.runners.resolveWaveformBundleRuntimeTuning(scfg, cfg, opt.LinkSNRGrid_dB);
opt.RuntimeTuning = tuning;
opt.LinkSweepTrialsPerSNR = double(tuning.PrimaryTrialsPerSNR);
opt.LinkReferenceSweepFrames = double(tuning.ReferenceTrialsPerSNR);
opt.LinkAdaptiveSweepEnabled = logical(tuning.AdaptiveSweepEnabled);
opt.LinkAdaptiveSweepStep_dB = double(tuning.AdaptiveSweepStep_dB);
opt.LinkAdaptiveSweepMaxPoints = double(tuning.AdaptiveSweepMaxPoints);
opt.HARQDiagnosticsEnabled = logical(tuning.HARQDiagnosticsEnabled);
opt.ResumeCompletedRuntimeFinalization = logical(sixgr.util.structGet( ...
    executionOptions, "ResumeCompletedRuntimeFinalization", false));
if strlength(strtrim(string(sixgr.util.structGet(tuning, "Notes", "")))) > 0
    localDBLog("INFO", "Waveform bundle runtime tuning: policy=%s notes=%s", ...
        char(string(sixgr.util.structGet(tuning, "Policy", ""))), ...
        char(string(sixgr.util.structGet(tuning, "Notes", ""))));
end
if receiverNoiseMode
    localDBLog("INFO", "Waveform bundle starting: qualityMode=%s operatingPointLabel=%.3f dB physicalPoints=%d canonicalSlots=%d monteCarlo=%d slotDuration_s=%.6f", ...
        char(string(opt.LinkQualityMode)), double(opt.LinkSNR_dB), double(numel(opt.LinkSNRGrid_dB)), ...
        double(opt.LinkMaxSimFrames), double(mcIterations), double(slotDuration_s));
else
    localDBLog("INFO", "Waveform bundle starting: snr=%.3f dB sweepPoints=%d canonicalSlots=%d monteCarlo=%d slotDuration_s=%.6f", ...
    double(opt.LinkSNR_dB), double(numel(opt.LinkSNRGrid_dB)), ...
    double(opt.LinkMaxSimFrames), double(mcIterations), double(slotDuration_s));
end
link = sixgr.truth.runWaveformLinkBundle(cfg, fullfile(runFolder, "air_interface"), opt);
localDBLog("INFO", "Waveform bundle finished: ok=%d", double(logical(sixgr.util.structGet(link, "Ok", false))));
strictControl = struct("Ok", true, "StrictOk", true, "SummaryTable", table(), "FailureReason", "");
if logical(sixgr.util.structGet(link, "ProfileStoppedEarly", false))
    localDBLog("WARN", "Waveform bundle profile debug stop observed; skipping supplemental strict validators: %s", ...
        char(string(sixgr.util.structGet(link, "ProfileStopReason", ""))));
    runtimeControl = sixgr.util.structGet(link, "RawTrials", struct());
    runtimeControl.CoupledRuntime = sixgr.util.structGet(link, "CoupledRuntime", struct());
    mobilityArtifacts = sixgr.util.structGet(link, "MobilityArtifacts", struct());
    if ~(istable(sixgr.util.structGet(runtimeControl, "ControlGatingSummaryTable", table())) && ...
            ~isempty(sixgr.util.structGet(runtimeControl, "ControlGatingSummaryTable", table())))
        runtimeControl.ControlGatingSummaryTable = sixgr.util.structGet(mobilityArtifacts, "ControlGatingSummaryTable", table());
    end
    if ~(istable(sixgr.util.structGet(runtimeControl, "ControlGatingStateTable", table())) && ...
            ~isempty(sixgr.util.structGet(runtimeControl, "ControlGatingStateTable", table())))
        runtimeControl.ControlGatingStateTable = sixgr.util.structGet(mobilityArtifacts, "ControlGatingStateTable", table());
    end
    controlTrace = sixgr.truth.exportControlPlaneTraces(runFolder, struct(), runtimeControl);
    result = struct();
    result.Ok = false;
    result.Link = link;
    result.Control = controlTrace;
    result.StrictControl = struct("Ok", true, "Skipped", true, ...
        "FailureReason", "profile_debug_stop_before_supplemental_validators", "SummaryTable", table());
    result.StrictSupplemental = struct("Ok", true, "Skipped", true, ...
        "FailureReason", "profile_debug_stop_before_supplemental_validators", "SummaryTable", table());
    return;
end
if localShouldRunStrictControlEvidence(scfg, cfg)
    localDBLog("INFO", "Evaluating strict control evidence from active slot-runtime rows; no supplemental waveform launched.");
    strictControl = sixgr.truth.evaluateInPathControlEvidence(cfg, ...
        sixgr.util.structGet(link, "RawTrials", struct()), ...
        "EnablePDCCH", localStrictControlTargetEnabled(scfg, cfg, "pdcch"), ...
        "EnablePUCCH", localStrictControlTargetEnabled(scfg, cfg, "pucch"), ...
        "EnablePUSCHUCI", localStrictControlTargetEnabled(scfg, cfg, "pusch_uci"));
    localDBLog("INFO", "Strict waveform-backed control evidence finished: ok=%d", ...
        double(logical(sixgr.util.structGet(strictControl, "Ok", false))));
    link.KPITable = localAppendStrictControlKPI(link.KPITable, strictControl);
    link.Ok = logical(sixgr.util.structGet(link, "Ok", false)) && logical(sixgr.util.structGet(strictControl, "Ok", true));
    if isfield(link, "Result") && isstruct(link.Result)
        link.Result.Ok = logical(link.Ok);
    end
    if ~logical(sixgr.util.structGet(strictControl, "Ok", true))
        link.Errors = [string(sixgr.util.structGet(link, "Errors", strings(0, 1))); ...
            string(sixgr.util.structGet(strictControl, "FailureReason", "strict_control_channel_evidence_failed"))];
    end
end
runtimeControl = sixgr.util.structGet(link, "RawTrials", struct());
runtimeControl.CoupledRuntime = sixgr.util.structGet(link, "CoupledRuntime", struct());
mobilityArtifacts = sixgr.util.structGet(link, "MobilityArtifacts", struct());
if ~(istable(sixgr.util.structGet(runtimeControl, "ControlGatingSummaryTable", table())) && ...
        ~isempty(sixgr.util.structGet(runtimeControl, "ControlGatingSummaryTable", table())))
    runtimeControl.ControlGatingSummaryTable = sixgr.util.structGet(mobilityArtifacts, "ControlGatingSummaryTable", table());
end
if ~(istable(sixgr.util.structGet(runtimeControl, "ControlGatingStateTable", table())) && ...
        ~isempty(sixgr.util.structGet(runtimeControl, "ControlGatingStateTable", table())))
    runtimeControl.ControlGatingStateTable = sixgr.util.structGet(mobilityArtifacts, "ControlGatingStateTable", table());
end
[link, strictSupplemental] = localRunWaveformBundleSupplementalStrictEvidence( ...
    link, cfg, scfg, runFolder, executionOptions);
runtimeControl = sixgr.util.structGet(link, "RawTrials", runtimeControl);
runtimeControl.CoupledRuntime = sixgr.util.structGet(link, "CoupledRuntime", struct());
if ~(istable(sixgr.util.structGet(runtimeControl, "ControlGatingSummaryTable", table())) && ...
        ~isempty(sixgr.util.structGet(runtimeControl, "ControlGatingSummaryTable", table())))
    runtimeControl.ControlGatingSummaryTable = sixgr.util.structGet(mobilityArtifacts, "ControlGatingSummaryTable", table());
end
if ~(istable(sixgr.util.structGet(runtimeControl, "ControlGatingStateTable", table())) && ...
        ~isempty(sixgr.util.structGet(runtimeControl, "ControlGatingStateTable", table())))
    runtimeControl.ControlGatingStateTable = sixgr.util.structGet(mobilityArtifacts, "ControlGatingStateTable", table());
end
controlTrace = sixgr.truth.exportControlPlaneTraces(runFolder, struct(), runtimeControl);
localDBLog("INFO", "Control-plane trace export complete.");

rows = repmat(struct("Block","", "Ok", false, "Notes",""), 0, 1);
if istable(link.KPITable)
    for i = 1:height(link.KPITable)
        rows(end+1,1) = struct( ... %#ok<AGROW>
            "Block", string(link.KPITable.Case(i)), ...
            "Ok", logical(link.KPITable.Ok(i)), ...
            "Notes", string(link.KPITable.Notes(i)));
    end
end
if ~isempty(rows)
    if localShouldWriteCSV(scfg)
        sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "case_status.csv"), struct2table(rows));
    end
end

result = struct();
result.Ok = logical(link.Ok);
result.Link = link;
result.Control = controlTrace;
result.StrictControl = strictControl;
result.StrictSupplemental = strictSupplemental;
end

function [link, strictSupplemental] = localRunWaveformBundleSupplementalStrictEvidence( ...
        link, cfg, scfg, runFolder, executionOptions)
if nargin < 5 || ~isstruct(executionOptions)
    executionOptions = struct();
end
resumeCompleted = logical(sixgr.util.structGet(executionOptions, ...
    "ResumeCompletedRuntimeFinalization", false));
strictSupplemental = struct("Ok", true, "SummaryTable", table(), ...
    "PRACH", struct(), "PRACHStatisticalCampaign", struct(), ...
    "PDCCHStatisticalCampaign", struct(), ...
    "SRS", struct(), "TRS", struct(), "SIB1", struct(), ...
    "ChannelRF", struct(), "MIMO", struct(), "Protocol", struct());
rows = repmat(struct("Case", "", "Ok", true, "Skipped", false, ...
    "EvidenceScope", "", "ArtifactRoot", "", "Notes", ""), 0, 1);

if localShouldRunStrictPRACHEvidence(scfg, cfg)
    prachPolicy = sixgr.lls6g.runners.resolveStrictComponentExecutionPolicy( ...
        scfg, cfg, "prach", runFolder);
    artifactRoot = prachPolicy.ArtifactRoot;
    if prachPolicy.SameScenarioInPathEligible
        localDBLog("INFO", ...
            "Evaluating strict PRACH from active slot-runtime rows; no supplemental waveform launched.");
        prach = sixgr.truth.evaluateInPathComponentEvidence(cfg, ...
            sixgr.util.structGet(link, "RawTrials", struct()), "prach");
        if localShouldRunPRACHStatisticalCampaign(scfg, cfg)
            campaignRoot = fullfile(runFolder, ...
                "statistical_campaigns", "prach");
            localDBLog("INFO", [ ...
                "Running the configured same-execution PRACH false-alarm/" ...
                "missed-detection campaign through the production PRACH TX/RX chain."]);
            tp = sixgr.perf.TimeProfiler.scope( ...
                "sixgr.phy.prach.runStrictPRACHValidation", ...
                "Stage", "same_execution_prach_statistical_campaign");
            campaign = sixgr.lls6g.runners.executeSupplementalValidator( ...
                "PRACH_StatisticalCampaign", ...
                @() sixgr.phy.prach.runStrictPRACHValidation(cfg, ...
                "RunFolder", campaignRoot, ...
                "RunId", prachPolicy.RunID, ...
                "ScenarioName", string(scfg.ScenarioID), ...
                "ExecutionID", prachPolicy.ExecutionID, ...
                "ScenarioConfigHash", prachPolicy.ConfigHash, ...
                "EvidenceScope", "same_execution_campaign", ...
                "WriteArtifacts", true));
            clear tp;
            campaign.EvidenceScope = "same_execution_campaign";
            campaign.SameScenarioInPathEligible = false;
            campaign.ArtifactRoot = string(campaignRoot);
            campaignGate = campaign;
            campaignGate.StrictOk = logical(sixgr.util.structGet( ...
                campaign, "StatisticallyQualified", false));
            campaignGate.Ok = campaignGate.StrictOk;
            if campaignGate.StrictOk
                campaignGate.FailureReason = "";
            else
                campaignGate.FailureReason = ...
                    "prach_statistical_qualification_not_passed:" + ...
                    string(sixgr.util.structGet(campaign, ...
                    "StatisticalQualification", "NOT_EVALUATED"));
            end
            strictSupplemental.PRACHStatisticalCampaign = campaign;
            [link, rows] = localAttachSupplementalStrictResult(link, rows, ...
                "PRACH_StatisticalCampaign", campaignGate, ...
                "same-execution PRACH statistical campaign passed", ...
                "same_execution_prach_statistical_campaign_failed");
        end
    elseif resumeCompleted && prachPolicy.ExecutionScope == "component_anchor" && ...
            sixgr.truth.isStrictPRACHComponentAnchorComplete(artifactRoot)
        localDBLog("INFO", ["Restoring completed strict PRACH evidence from " ...
            "identity-bound, hash-verified component artifacts."]);
        prach = sixgr.truth.restoreStrictPRACHComponentAnchor(artifactRoot, ...
            string(scfg.ScenarioID), string(scfg.ConfigHash));
    else
        if resumeCompleted && prachPolicy.ExecutionScope == "component_anchor"
            [~, missingAnchorPaths] = ...
                sixgr.truth.isStrictPRACHComponentAnchorComplete(artifactRoot);
            localDBLog("WARN", ["Completed runtime has no complete PRACH " ...
                "component anchor; executing the configured strict validator. " ...
                "Missing=%s"], strjoin(missingAnchorPaths, "|"));
        end
        localDBLog("INFO", ...
            "Running strict PRACH waveform validation with evidence_scope=%s.", ...
            char(prachPolicy.ExecutionScope));
        tp = sixgr.perf.TimeProfiler.scope("sixgr.phy.prach.runStrictPRACHValidation", ...
            "Stage", "strict_prach_validation");
        prach = sixgr.lls6g.runners.executeSupplementalValidator( ...
            "PRACH_StrictValidation", @() sixgr.phy.prach.runStrictPRACHValidation(cfg, ...
            "RunFolder", artifactRoot, ...
            "RunId", prachPolicy.ValidatorRunID, ...
            "ScenarioName", string(scfg.ScenarioID), ...
            "ExecutionID", prachPolicy.BindingExecutionID, ...
            "ScenarioConfigHash", prachPolicy.BindingConfigHash, ...
            "WriteArtifacts", true));
        clear tp;
    end
    prach = localMarkStrictComponentResult(prach, prachPolicy);
    strictSupplemental.PRACH = prach;
    [link, rows] = localAttachSupplementalStrictResult(link, rows, "PRACH_StrictValidation", prach, ...
        "strict PRACH waveform validation completed", "strict_prach_validation_failed");
    if ~prachPolicy.SameScenarioInPathEligible
        link = localAttachSupplementalStrictTrialTable(link, "PRACH", prach, "prach_trials");
    end
end

if localShouldRunPDCCHStatisticalCampaign(scfg, cfg)
    pdcchPolicy = sixgr.lls6g.runners.resolveStrictComponentExecutionPolicy( ...
        scfg, cfg, "pdcch", runFolder);
    if ~pdcchPolicy.SameScenarioInPathEligible
        error("sixgr:lls6g:PDCCHStatisticalCampaignNotInPath", ...
            "A runtime PDCCH statistical qualification request requires " + ...
            "validation.strict_component_evidence to include pdcch with " + ...
            "execution_scope=in_path.");
    end
    campaignRoot = fullfile(runFolder, "statistical_campaigns", "pdcch");
    localDBLog("INFO", [ ...
        "Running the configured same-execution PDCCH false-alarm campaign " ...
        "through the production PDCCH TX/channel/RX chain."]);
    tp = sixgr.perf.TimeProfiler.scope( ...
        "sixgr.phy.pdcch.runStrictPDCCHValidation", ...
        "Stage", "same_execution_pdcch_statistical_campaign");
    campaign = sixgr.lls6g.runners.executeSupplementalValidator( ...
        "PDCCH_StatisticalCampaign", ...
        @() sixgr.phy.pdcch.runStrictPDCCHValidation(cfg, ...
        "RunFolder", campaignRoot, ...
        "RunId", pdcchPolicy.RunID, ...
        "ScenarioName", string(scfg.ScenarioID), ...
        "ExecutionID", pdcchPolicy.ExecutionID, ...
        "ScenarioConfigHash", pdcchPolicy.ConfigHash, ...
        "EvidenceScope", "same_execution_campaign", ...
        "WriteArtifacts", true));
    clear tp;
    campaign.EvidenceScope = "same_execution_campaign";
    campaign.SameScenarioInPathEligible = false;
    campaign.ArtifactRoot = string(campaignRoot);
    campaignGate = campaign;
    campaignGate.StrictOk = logical(sixgr.util.structGet( ...
        campaign, "StatisticallyQualified", false));
    campaignGate.Ok = campaignGate.StrictOk;
    if campaignGate.StrictOk
        campaignGate.FailureReason = "";
    else
        campaignGate.FailureReason = ...
            "pdcch_statistical_qualification_not_passed:" + ...
            string(sixgr.util.structGet(campaign, ...
            "StatisticalQualification", "NOT_EVALUATED"));
    end
    strictSupplemental.PDCCHStatisticalCampaign = campaign;
    [link, rows] = localAttachSupplementalStrictResult(link, rows, ...
        "PDCCH_StatisticalCampaign", campaignGate, ...
        "same-execution PDCCH statistical campaign passed", ...
        "same_execution_pdcch_statistical_campaign_failed");
end

if localShouldRunStrictSRSEvidence(scfg, cfg)
    srsPolicy = sixgr.lls6g.runners.resolveStrictComponentExecutionPolicy( ...
        scfg, cfg, "srs", runFolder);
    if srsPolicy.SameScenarioInPathEligible
        localDBLog("INFO", ...
            "Evaluating strict SRS from active slot-runtime rows; no supplemental waveform launched.");
        srs = sixgr.truth.evaluateInPathComponentEvidence(cfg, ...
            sixgr.util.structGet(link, "RawTrials", struct()), "srs");
    else
        localDBLog("INFO", ...
            "Running strict SRS component-anchor waveform validation.");
        tp = sixgr.perf.TimeProfiler.scope("sixgr.phy.srs.runStrictSRSValidation", ...
            "Stage", "strict_srs_validation");
        srs = sixgr.lls6g.runners.executeSupplementalValidator( ...
            "SRS_StrictValidation", @() sixgr.phy.srs.runStrictSRSValidation(cfg, ...
            "RunFolder", srsPolicy.ArtifactRoot, ...
            "RunId", srsPolicy.ValidatorRunID, ...
            "ScenarioName", string(scfg.ScenarioID), ...
            "WriteArtifacts", true));
        clear tp;
    end
    srs = localMarkStrictComponentResult(srs, srsPolicy);
    strictSupplemental.SRS = srs;
    [link, rows] = localAttachSupplementalStrictResult(link, rows, "SRS_StrictValidation", srs, ...
        "strict SRS waveform channel-sounding validation completed", "strict_srs_validation_failed");
    if ~srsPolicy.SameScenarioInPathEligible
        link = localAttachSupplementalStrictTrialTable(link, "SRS", srs, "srs_trials");
    end
end

if localShouldRunStrictTRSEvidence(scfg, cfg)
    trsPolicy = sixgr.lls6g.runners.resolveStrictComponentExecutionPolicy( ...
        scfg, cfg, "trs", runFolder);
    if trsPolicy.SameScenarioInPathEligible
        localDBLog("INFO", ...
            "Evaluating strict TRS from active slot-runtime rows; no supplemental waveform launched.");
        trs = sixgr.truth.evaluateInPathComponentEvidence(cfg, ...
            sixgr.util.structGet(link, "RawTrials", struct()), "trs");
    else
        localDBLog("INFO", ...
            "Running strict TRS component-anchor waveform validation.");
        tp = sixgr.perf.TimeProfiler.scope("sixgr.phy.trs.runStrictTRSValidation", ...
            "Stage", "strict_trs_validation");
        trs = sixgr.lls6g.runners.executeSupplementalValidator( ...
            "TRS_StrictValidation", @() sixgr.phy.trs.runStrictTRSValidation(cfg, ...
            "RunFolder", trsPolicy.ArtifactRoot, ...
            "RunId", trsPolicy.ValidatorRunID, ...
            "ScenarioName", string(scfg.ScenarioID), ...
            "WriteArtifacts", true));
        clear tp;
    end
    trs = localMarkStrictComponentResult(trs, trsPolicy);
    strictSupplemental.TRS = trs;
    [link, rows] = localAttachSupplementalStrictResult(link, rows, "TRS_StrictValidation", trs, ...
        "strict TRS waveform tracking validation completed", "strict_trs_validation_failed");
    if ~trsPolicy.SameScenarioInPathEligible
        link = localAttachSupplementalStrictTrialTable(link, "TRS", trs, "trs_trials");
    end
end

if localShouldRunStrictSIB1Evidence(scfg, cfg)
    sib1Policy = sixgr.lls6g.runners.resolveStrictComponentExecutionPolicy( ...
        scfg, cfg, "sib1", runFolder);
    if sib1Policy.SameScenarioInPathEligible
        localDBLog("INFO", ...
            "Evaluating strict PBCH/MIB/SIB1 from active slot-runtime rows; no mini-anchor launched.");
        sib1 = sixgr.truth.evaluateInPathComponentEvidence(cfg, ...
            sixgr.util.structGet(link, "RawTrials", struct()), "sib1");
    else
        localDBLog("INFO", ...
            "Running strict SIB1/PBCH component-anchor waveform validation.");
        tp = sixgr.perf.TimeProfiler.scope("sixgr.phy.broadcast.runSIB1StrictMiniAnchor", ...
            "Stage", "strict_sib1_validation");
        sib1 = sixgr.lls6g.runners.executeSupplementalValidator( ...
            "SIB1_StrictMiniAnchor", ...
            @() sixgr.phy.broadcast.runSIB1StrictMiniAnchor( ...
            sib1Policy.ArtifactRoot, cfg, ...
            "RunId", sib1Policy.ValidatorRunID, ...
            "ScenarioName", string(scfg.ScenarioID)));
        clear tp;
    end
    sib1 = localMarkStrictComponentResult(sib1, sib1Policy);
    strictSupplemental.SIB1 = sib1;
    [link, rows] = localAttachSupplementalStrictResult(link, rows, "SIB1_StrictMiniAnchor", sib1, ...
        "strict SIB1/PBCH waveform mini-anchor validation completed", "strict_sib1_validation_failed");
end

if localShouldRunStrictChannelRFEvidence(scfg, cfg)
    channelRFPolicy = sixgr.lls6g.runners.resolveStrictComponentExecutionPolicy( ...
        scfg, cfg, "channel_rf", runFolder);
    localDBLog("INFO", ...
        "Running strict Channel/RF validation with evidence_scope=%s.", ...
        char(channelRFPolicy.ExecutionScope));
    tp = sixgr.perf.TimeProfiler.scope("sixgr.channel.runStrictChannelRFValidation", ...
        "Stage", "strict_channel_rf_validation");
    channelRF = sixgr.lls6g.runners.executeSupplementalValidator( ...
        "ChannelRF_StrictValidation", @() sixgr.channel.runStrictChannelRFValidation(cfg, ...
        "RunFolder", channelRFPolicy.ArtifactRoot, ...
        "RunId", channelRFPolicy.ValidatorRunID, ...
        "ScenarioName", string(scfg.ScenarioID), ...
        "ExecutionID", channelRFPolicy.BindingExecutionID, ...
        "ScenarioConfigHash", channelRFPolicy.BindingConfigHash, ...
        "RuntimeTrials", sixgr.util.structGet(link, "RawTrials", struct()), ...
        "WriteArtifacts", true));
    clear tp;
    channelRF = localMarkStrictComponentResult(channelRF, channelRFPolicy);
    strictSupplemental.ChannelRF = channelRF;
    [link, rows] = localAttachSupplementalStrictResult(link, rows, "ChannelRF_StrictValidation", channelRF, ...
        "strict Channel/RF configured-vs-applied validation completed", "strict_channel_rf_validation_failed");
end

if localShouldRunMIMOEvidence(scfg, cfg, link)
    localDBLog("INFO", "Refreshing MIMO nominal-vs-effective evidence from waveform-bundle raw trials.");
    mimoArtifacts = sixgr.lls6g.runners.executeSupplementalValidator( ...
        "MIMO_NominalEffectiveEvidence", @() sixgr.mimo.exportMIMOEvidenceArtifacts(runFolder, cfg, ...
        sixgr.util.structGet(link, "RawTrials", struct()), ...
        "RunId", string(sixgr.util.structGet(cfg, "run.runTag", "")), ...
        "ScenarioName", string(scfg.ScenarioID), ...
        "StrictMode", true));
    mimoArtifacts = localMarkInPathResult(mimoArtifacts, runFolder);
    strictSupplemental.MIMO = mimoArtifacts;
    [link, rows] = localAttachSupplementalStrictResult(link, rows, ...
        "MIMO_NominalEffectiveEvidence", mimoArtifacts, ...
        "MIMO nominal-vs-effective evidence refreshed from raw trials", ...
        "mimo_nominal_effective_evidence_failed");
end

if sixgr.lls6g.runners.shouldRunProtocolComponentEvidence(cfg)
    localDBLog("INFO", ...
        "Running configured bidirectional L2 protocol component validation.");
    tp = sixgr.perf.TimeProfiler.scope( ...
        "sixgr.protocol.runConfiguredProtocolComponentValidation", ...
        "Stage", "strict_protocol_component_validation");
    anchorRoot = sixgr.runtime.prepareComponentAnchorRoot(runFolder, "protocol", scfg, cfg);
    protocol = sixgr.lls6g.runners.executeSupplementalValidator( ...
        "Protocol_ConfiguredComponentValidation", ...
        @() sixgr.protocol.runConfiguredProtocolComponentValidation( ...
        cfg, string(anchorRoot), ...
        "RunId", string(scfg.ScenarioID), ...
        "ScenarioName", string(scfg.ScenarioID), ...
        "WriteArtifacts", true));
    clear tp;
    protocol = localMarkComponentAnchorResult(protocol, anchorRoot);
    strictSupplemental.Protocol = protocol;
    [link, rows] = localAttachSupplementalStrictResult(link, rows, ...
        "Protocol_ConfiguredComponentValidation", protocol, ...
        "configured bidirectional SDAP/PDCP/RLC/MAC component execution completed", ...
        "configured_protocol_component_validation_failed");
end

if ~isempty(rows)
    strictSupplemental.SummaryTable = struct2table(rows, "AsArray", true);
    strictSupplemental.Ok = all(logical(strictSupplemental.SummaryTable.Ok));
    link.KPITable = localAppendStrictControlKPI(sixgr.util.structGet(link, "KPITable", table()), ...
        struct("SummaryTable", strictSupplemental.SummaryTable));
    link.Ok = logical(sixgr.util.structGet(link, "Ok", true)) && logical(strictSupplemental.Ok);
    if isfield(link, "Result") && isstruct(link.Result)
        link.Result.Ok = logical(link.Ok);
    end
end
end

function [link, rows] = localAttachSupplementalStrictResult(link, rows, caseName, result, successNote, failureNote)
ok = logical(sixgr.util.structGet(result, "StrictOk", sixgr.util.structGet(result, "Ok", false)));
note = string(successNote);
if ~ok
    note = string(sixgr.util.structGet(result, "FailureReason", failureNote));
end
rows(end+1, 1) = struct("Case", string(caseName), "Ok", ok, "Skipped", false, ...
    "EvidenceScope", string(sixgr.util.structGet(result, "EvidenceScope", "component_anchor")), ...
    "ArtifactRoot", string(sixgr.util.structGet(result, "ArtifactRoot", "")), ...
    "Notes", note); %#ok<AGROW>
if ~ok
    existing = string(sixgr.util.structGet(link, "Errors", strings(0, 1)));
    link.Errors = [existing(:); string(caseName) + ":" + note];
end
end

function link = localAttachSupplementalStrictTrialTable(link, fieldName, result, tableName)
if ~(isstruct(result) && isfield(result, "ArtifactTables"))
    return;
end
T = sixgr.util.structGet(result.ArtifactTables, tableName, table());
if ~(istable(T) && ~isempty(T))
    return;
end
fieldName = char(fieldName);
T = localPrepareStrictRawTrialTable(fieldName, T, ...
    string(sixgr.util.structGet(result, "EvidenceScope", "component_anchor")), ...
    logical(sixgr.util.structGet(result, "SameScenarioInPathEligible", false)));
supplemental = sixgr.util.structGet(link, "SupplementalStrictRawTrials", struct());
supplemental.(fieldName) = T;
link.SupplementalStrictRawTrials = supplemental;
end

function T = localPrepareStrictRawTrialTable(fieldName, T, evidenceScope, inPathEligible)
if ~(istable(T) && ~isempty(T))
    return;
end
n = height(T);
fieldName = upper(string(fieldName));
if nargin < 3 || strlength(strtrim(string(evidenceScope))) == 0
    evidenceScope = "component_anchor";
end
if nargin < 4
    inPathEligible = false;
end
if ~ismember("Frame", string(T.Properties.VariableNames))
    T.Frame = NaN(n, 1);
end
if ~ismember("Slot", string(T.Properties.VariableNames))
    T.Slot = NaN(n, 1);
end
if ~ismember("UEIndex", string(T.Properties.VariableNames))
    if ismember("UEId", string(T.Properties.VariableNames))
        T.UEIndex = localNumericColumn(T, "UEId", NaN(n, 1));
    elseif ismember("UEID", string(T.Properties.VariableNames))
        T.UEIndex = localNumericColumn(T, "UEID", NaN(n, 1));
    else
        T.UEIndex = NaN(n, 1);
    end
end
if ~ismember("UEID", string(T.Properties.VariableNames))
    T.UEID = localNumericColumn(T, "UEIndex", NaN(n, 1));
end
if ~ismember("Direction", string(T.Properties.VariableNames))
    if any(fieldName == ["SRS", "PRACH", "PUCCH"])
        T.Direction = repmat("UL", n, 1);
    else
        T.Direction = repmat("DL", n, 1);
    end
end
if ~ismember("EvidenceScope", string(T.Properties.VariableNames))
    T.EvidenceScope = repmat(string(evidenceScope), n, 1);
else
    T.EvidenceScope(:) = string(evidenceScope);
end
if ~ismember("SameScenarioInPathEligible", string(T.Properties.VariableNames))
    T.SameScenarioInPathEligible = repmat(logical(inPathEligible), n, 1);
else
    T.SameScenarioInPathEligible(:) = logical(inPathEligible);
end
end

function Tout = localAppendCompatTable(Ta, Tb)
if ~(istable(Ta) && ~isempty(Ta))
    if istable(Tb)
        Tout = Tb;
    else
        Tout = table();
    end
    return;
end
if ~(istable(Tb) && ~isempty(Tb))
    Tout = Ta;
    return;
end
vars = union(string(Ta.Properties.VariableNames), string(Tb.Properties.VariableNames), "stable");
Ta = localEnsureTableVars(Ta, vars, Tb);
Tb = localEnsureTableVars(Tb, vars, Ta);
Tout = [Ta(:, cellstr(vars)); Tb(:, cellstr(vars))];
end

function T = localEnsureTableVars(T, vars, refT)
for i = 1:numel(vars)
    v = char(vars(i));
    if ~ismember(v, T.Properties.VariableNames)
        T.(v) = localDefaultColumnLike(refT, v, height(T));
    end
end
end

function col = localDefaultColumnLike(refT, varName, nRows)
if istable(refT) && ismember(varName, refT.Properties.VariableNames)
    refVal = refT.(varName);
    if isstring(refVal)
        col = strings(nRows, 1);
        return;
    end
    if iscellstr(refVal)
        col = repmat({''}, nRows, 1);
        return;
    end
    if islogical(refVal)
        col = false(nRows, 1);
        return;
    end
    if isnumeric(refVal)
        col = NaN(nRows, 1);
        return;
    end
end
col = strings(nRows, 1);
end

function vals = localNumericColumn(T, varName, defaultValue)
vals = defaultValue;
if ~(istable(T) && ismember(varName, string(T.Properties.VariableNames)))
    return;
end
raw = T.(char(varName));
if isnumeric(raw) || islogical(raw)
    vals = double(raw);
else
    vals = str2double(string(raw));
end
vals = vals(:);
if numel(vals) ~= height(T)
    vals = defaultValue;
end
end

function tf = localShouldRunStrictPRACHEvidence(scfg, cfg)
targetCases = localScenarioTargetCases(scfg);
validationObjectives = localValidationObjectives(cfg);
prachGateRequired = logical(sixgr.util.structGet(cfg, "run.controlGating.prachRequired", ...
    sixgr.util.structGet(cfg, "control_gating.prach_required", false)));
raEvidence = sixgr.util.structGet(cfg, "validation.random_access_evidence", struct());
raStrictRequired = builtin("isstruct", raEvidence) && ( ...
    logical(sixgr.util.structGet(raEvidence, "four_step_ra_required", false)) || ...
    logical(sixgr.util.structGet(raEvidence, "msg1_prach_required", false)) || ...
    logical(sixgr.util.structGet(raEvidence, "false_alarm_test_enabled", false)) || ...
    logical(sixgr.util.structGet(raEvidence, "missed_detection_test_enabled", false)));
tf = logical(sixgr.util.structGet(cfg, "phy.prach.enable", false)) && ...
    (any(ismember(targetCases, ["prach","ra","random_access"])) || ...
    any(ismember(validationObjectives, ["prach_strict_validation","random_access_four_step"])) || ...
    prachGateRequired || raStrictRequired);
end

function tf = localShouldRunPRACHStatisticalCampaign(scfg, cfg)
raEvidence = sixgr.util.structGet(cfg, ...
    "validation.random_access_evidence", struct());
falseAlarm = logical(sixgr.util.structGet(raEvidence, ...
    "false_alarm_test_enabled", scfg.get( ...
    "random_access_evidence.false_alarm_test_enabled", false)));
missedDetection = logical(sixgr.util.structGet(raEvidence, ...
    "missed_detection_test_enabled", scfg.get( ...
    "random_access_evidence.missed_detection_test_enabled", false)));
tf = falseAlarm || missedDetection;
end

function tf = localShouldRunPDCCHStatisticalCampaign(scfg, cfg)
enabled = logical(sixgr.util.structGet(cfg, ...
    "phy.pdcch.operatorControl.pdcch_strict.statistical_qualification.enabled", ...
    scfg.get("lls6g.control.pdcch_strict.statistical_qualification.enabled", false)));
tf = enabled && localStrictControlTargetEnabled(scfg, cfg, "pdcch");
end

function tf = localShouldRunStrictSRSEvidence(scfg, cfg)
targetCases = localScenarioTargetCases(scfg);
validationObjectives = localValidationObjectives(cfg);
tf = logical(sixgr.util.structGet(cfg, "phy.srs.enable", false)) && ...
    (any(targetCases == "srs") || any(validationObjectives == "srs_strict_validation") || ...
    localControlGatingRequired(cfg, "srs"));
end

function tf = localShouldRunStrictTRSEvidence(scfg, cfg)
targetCases = localScenarioTargetCases(scfg);
validationObjectives = localValidationObjectives(cfg);
tf = logical(sixgr.util.structGet(cfg, "phy.trs.enable", false)) && ...
    (any(targetCases == "trs") || any(validationObjectives == "trs_strict_validation") || ...
    localControlGatingRequired(cfg, "trs"));
end

function tf = localShouldRunStrictSIB1Evidence(scfg, cfg)
policy = sixgr.lls6g.runners.resolveStrictSupplementalEvidencePolicy(scfg, cfg);
tf = logical(sixgr.util.structGet(policy, "EnableSIB1", false));
end

function tf = localShouldRunStrictChannelRFEvidence(scfg, cfg)
targetCases = localScenarioTargetCases(scfg);
validationObjectives = localValidationObjectives(cfg);
section = sixgr.util.structGet(cfg, "validation.channel_rf_configured_vs_applied", struct());
enabled = builtin("isstruct", section) && logical(sixgr.util.structGet(section, "enabled", false));
tf = enabled || any(targetCases == "channel_rf") || any(validationObjectives == "channel_rf_strict_validation");
end

function tf = localShouldRunMIMOEvidence(scfg, cfg, link)
targetCases = localScenarioTargetCases(scfg);
rawTrials = sixgr.util.structGet(link, "RawTrials", struct());
hasRaw = builtin("isstruct", rawTrials) && (~isempty(fieldnames(rawTrials)));
configuredMIMO = double(sixgr.util.structGet(cfg, "phy.pdsch.nLayers", 1)) > 1 || ...
    double(sixgr.util.structGet(cfg, "scenario.bs.nTxAnt", 1)) > 1 || ...
    double(sixgr.util.structGet(cfg, "scenario.ue.nRxAnt", 1)) > 1;
tf = hasRaw && (configuredMIMO || any(ismember(targetCases, ["mimo","beam","ssb"])));
end

function targets = localScenarioTargetCases(scfg)
targets = lower(strtrim(string(scfg.get("scenario.target_cases", {}))));
targets = targets(strlength(targets) > 0);
end

function objectives = localValidationObjectives(cfg)
objectives = lower(strtrim(string(sixgr.util.structGet(cfg, "validation.objectives", strings(0, 1)))));
objectives = objectives(strlength(objectives) > 0);
end

function tf = localControlGatingRequired(cfg, signalName)
signalName = lower(strtrim(string(signalName)));
switch signalName
    case "srs"
        tf = logical(sixgr.util.structGet(cfg, "run.controlGating.srsRequired", ...
            sixgr.util.structGet(cfg, "control_gating.srs_required", ...
            sixgr.util.structGet(cfg, "control_gating.srsRequired", false))));
    case "trs"
        tf = logical(sixgr.util.structGet(cfg, "run.controlGating.trsRequired", ...
            sixgr.util.structGet(cfg, "control_gating.trs_required", ...
            sixgr.util.structGet(cfg, "control_gating.trsRequired", false))));
    otherwise
        tf = false;
end
end

function result = localRunSystemLevelScenario(cfg, scfg, runFolder)
layout = sixgr.report.resultLayout(runFolder);
ctx = sixgr.core.SimContext(cfg, "RunFolder", layout.SystemDir);

numerology = localResolveConfigNumerology(cfg);
slotDuration_s = double(numerology.SlotDurationSeconds);
numTTI = max(1, ceil(double(sixgr.util.structGet(cfg, "run.totalTime_ms", slotDuration_s * 1e3)) / (slotDuration_s * 1e3)));
params = struct();
params.PHYBackend = string(sixgr.util.structGet(cfg, "system.phyBackend", "waveform"));
params.DetailedTrace = true;
params.NumTTI = numTTI;
params.SimDuration_s = double(sixgr.util.structGet(cfg, "system.simDuration_s", numTTI * slotDuration_s));
params.TTI_s = slotDuration_s;

localDBLog("INFO", "System-level LLS starting: NumTTI=%d PHYBackend=%s simulationMode=%s", ...
    double(numTTI), char(string(params.PHYBackend)), char(string(sixgr.util.structGet(cfg, "run.simulationMode", ""))));
systemOut = sixgr.system.SystemLevelRunner.run(ctx, params);
localDBLog("INFO", "System-level LLS finished: ok=%d", double(logical(sixgr.util.structGet(systemOut, "Ok", false))));

canon = sixgr.truth.exportSystemLevelCanonicalArtifacts(runFolder, scfg, cfg, systemOut);
strictControl = struct("Ok", true, "StrictOk", true, "SummaryTable", table(), "FailureReason", "");
if localShouldRunStrictControlEvidence(scfg, cfg)
    localDBLog("INFO", "Evaluating strict control evidence from active system-runtime rows; no supplemental waveform launched.");
    strictControl = sixgr.truth.evaluateInPathControlEvidence(cfg, ...
        sixgr.util.structGet(canon, "RawTrials", struct()), ...
        "EnablePDCCH", localStrictControlTargetEnabled(scfg, cfg, "pdcch"), ...
        "EnablePUCCH", localStrictControlTargetEnabled(scfg, cfg, "pucch"), ...
        "EnablePUSCHUCI", localStrictControlTargetEnabled(scfg, cfg, "pusch_uci"));
    localDBLog("INFO", "Strict waveform-backed control evidence finished: ok=%d", ...
        double(logical(sixgr.util.structGet(strictControl, "Ok", false))));
end

notes = string(strjoin(string(sixgr.util.structGet(systemOut, "Errors", strings(0, 1))), "; "));
if strlength(notes) == 0
    notes = "system_level_lls_runner_completed";
end
kpitable = table( ...
    string("system_level_lls"), ...
    logical(sixgr.util.structGet(systemOut, "Ok", false)), ...
    false, ...
    notes, ...
    'VariableNames', {'Case','Ok','Skipped','Notes'});
strictSummaryT = sixgr.util.structGet(strictControl, "SummaryTable", table());
if istable(strictSummaryT) && ~isempty(strictSummaryT)
    strictCases = "strict_" + lower(string(strictSummaryT.SignalFamily)) + "_waveform_control";
    strictNotes = string(strictSummaryT.FailureReason);
    strictNotes(strlength(strtrim(strictNotes)) == 0) = "strict waveform-backed control evidence completed";
    strictKPI = table(strictCases(:), logical(strictSummaryT.StrictOk(:)), false(height(strictSummaryT), 1), strictNotes(:), ...
        'VariableNames', {'Case','Ok','Skipped','Notes'});
    kpitable = [kpitable; strictKPI];
end
combinedOk = logical(sixgr.util.structGet(systemOut, "Ok", false)) && logical(sixgr.util.structGet(strictControl, "Ok", true));

link = struct();
link.Ok = combinedOk;
link.Result = struct("Ok", combinedOk);
link.Errors = string(sixgr.util.structGet(systemOut, "Errors", strings(0, 1)));
if ~logical(sixgr.util.structGet(strictControl, "Ok", true))
    link.Errors = [link.Errors(:); string(sixgr.util.structGet(strictControl, "FailureReason", "strict_control_channel_evidence_failed"))];
end
link.UnsupportedCases = table();
link.KPITable = kpitable;
link.RawTrials = canon.RawTrials;

result = struct();
result.Ok = combinedOk;
result.Link = link;
result.System = systemOut;
result.Canonical = canon;
result.StrictControl = strictControl;
end

function tf = localShouldRunStrictControlEvidence(scfg, cfg)
policy = sixgr.lls6g.runners.resolveStrictControlEvidencePolicy(scfg, cfg);
tf = logical(policy.ShouldRun);
end

function tf = localStrictControlTargetEnabled(scfg, cfg, signalName)
signalName = lower(string(signalName));
policy = sixgr.lls6g.runners.resolveStrictControlEvidencePolicy(scfg, cfg);
switch signalName
    case "pdcch"
        tf = logical(policy.EnablePDCCH);
    case "pucch"
        tf = logical(policy.EnablePUCCH);
    case "pusch_uci"
        tf = logical(policy.EnablePUSCHUCI);
    otherwise
        tf = false;
end
end

function canon = localAttachStrictControlRawTrials(canon, strictControl)
if ~(isstruct(canon) && isfield(canon, "RawTrials"))
    return;
end
pdcch = sixgr.util.structGet(strictControl, "PDCCH", struct());
if isstruct(pdcch) && isfield(pdcch, "ArtifactTables")
    T = sixgr.util.structGet(pdcch.ArtifactTables, "pdcch_trials", table());
    if istable(T) && ~isempty(T)
        supplemental = sixgr.util.structGet(canon, "SupplementalStrictRawTrials", struct());
        supplemental.PDCCH = T;
        canon.SupplementalStrictRawTrials = supplemental;
    end
end
pucch = sixgr.util.structGet(strictControl, "PUCCH", struct());
if isstruct(pucch) && isfield(pucch, "ArtifactTables")
    T = sixgr.util.structGet(pucch.ArtifactTables, "pucch_trials", table());
    if istable(T) && ~isempty(T)
        supplemental = sixgr.util.structGet(canon, "SupplementalStrictRawTrials", struct());
        supplemental.PUCCH = T;
        canon.SupplementalStrictRawTrials = supplemental;
    end
end
end

function kpi = localAppendStrictControlKPI(kpi, strictControl)
strictSummaryT = sixgr.util.structGet(strictControl, "SummaryTable", table());
if ~(istable(strictSummaryT) && ~isempty(strictSummaryT))
    return;
end
if all(ismember(["Case","Ok"], string(strictSummaryT.Properties.VariableNames)))
    strictKPI = strictSummaryT;
    strictKPI.Case = string(strictKPI.Case);
    strictKPI.Ok = logical(strictKPI.Ok);
    if ~ismember("Skipped", string(strictKPI.Properties.VariableNames))
        strictKPI.Skipped = false(height(strictKPI), 1);
    else
        strictKPI.Skipped = logical(strictKPI.Skipped);
    end
    if ~ismember("Notes", string(strictKPI.Properties.VariableNames))
        strictKPI.Notes = strings(height(strictKPI), 1);
    else
        strictKPI.Notes = string(strictKPI.Notes);
    end
    strictKPI = strictKPI(:, {'Case','Ok','Skipped','Notes'});
else
    strictCases = "strict_" + lower(string(strictSummaryT.SignalFamily)) + "_waveform_control";
    strictNotes = string(strictSummaryT.FailureReason);
    strictNotes(strlength(strtrim(strictNotes)) == 0) = "strict waveform-backed control evidence completed";
    strictKPI = table(strictCases(:), logical(strictSummaryT.StrictOk(:)), false(height(strictSummaryT), 1), strictNotes(:), ...
        'VariableNames', {'Case','Ok','Skipped','Notes'});
end
if ~(istable(kpi) && ~isempty(kpi))
    kpi = strictKPI;
    return;
end
kpi.Case = string(kpi.Case);
kpi.Ok = logical(kpi.Ok);
kpi.Skipped = logical(kpi.Skipped);
if ismember("Notes", string(kpi.Properties.VariableNames))
    kpi.Notes = string(kpi.Notes);
end
strictKPI = localAlignKPIColumns(strictKPI, kpi);
kpi = localAlignKPIColumns(kpi, strictKPI);
strictKPI = strictKPI(:, kpi.Properties.VariableNames);
kpi = [kpi; strictKPI];
end

function T = localAlignKPIColumns(T, referenceT)
refVars = string(referenceT.Properties.VariableNames);
for i = 1:numel(refVars)
    name = refVars(i);
    if ~ismember(name, string(T.Properties.VariableNames))
        T.(name) = localDefaultKPIColumn(referenceT.(name), height(T));
    end
end
T = T(:, refVars);
end

function col = localDefaultKPIColumn(referenceCol, n)
if islogical(referenceCol)
    col = false(n, 1);
elseif isnumeric(referenceCol)
    col = nan(n, 1);
elseif isstring(referenceCol)
    col = strings(n, 1);
elseif iscellstr(referenceCol)
    col = repmat({''}, n, 1);
else
    col = strings(n, 1);
end
end

function result = localRunPDCCHBlindDecodeSweep(cfg, scfg, runFolder)
configuredBlindSearch = logical(sixgr.util.structGet(cfg, ...
    "phy.pdcch.blindSearch", false));
sixgr.config.assertRuntimeFeatureUse(cfg, "pdcch_blind_search", ...
    configuredBlindSearch, "localRunPDCCHBlindDecodeSweep");
if ~configuredBlindSearch
    error("sixgr:phy:pdcch:BlindSearchDisabledByYAML", ...
        "The pdcch_blind_decode_sweep runner requires control.blind_search_enabled=true.");
end
aggLevels = double(scfg.get("control.aggregation_levels"));
nTrials = max(1, round(double(scfg.get("simulation.monte_carlo_iterations"))));
snr_dB = double(scfg.get("simulation.snr_db"));
pdcchPayloadBits = double(sixgr.util.structGet(cfg, "phy.pdcch.dciPayloadBits", NaN));
if ~(isscalar(pdcchPayloadBits) && isfinite(pdcchPayloadBits) && ...
        pdcchPayloadBits >= 1 && pdcchPayloadBits == fix(pdcchPayloadBits))
    error("sixgr:phy:pdcch:missing_dci_context", ...
        "PDCCH blind sweep requires a context-derived exact payload size.");
end
listLength = max(1, round(double(scfg.get("control.blind_decode_list_length"))));

trialRows = repmat(struct("AggregationLevel", NaN, "Trial", NaN, "SNR_dB", NaN, ...
    "BitErrors", NaN, "BitsCompared", NaN, "Pass", false, "DetectionMetric", NaN, ...
    "BlindDecodeCount", NaN, "ComputeLatency_ms", NaN, "AppliedAWGNSNR_dB", NaN, ...
    "NoiseVariance", NaN, "NoiseVarStatus", "", "NoiseVarSource", "", ...
    "ReceiverHestSINR_dB", NaN, "ReceiverHestSINRSource", "", ...
    "FalseAlarmFlag", false, "ChannelModelApplied", "", "ChannelFadingApplied", false, ...
    "AppliedLargeScaleGain_dB", NaN, "AppliedLargeScaleLoss_dB", NaN, ...
    "AppliedPathloss_dB", NaN, "AppliedShadowFading_dB", NaN, "AppliedO2I_dB", NaN, ...
    "InjectedCFO_Hz", NaN, "InjectedTimingOffset_samples", NaN), 0, 1);
summaryRows = repmat(struct("AggregationLevel", NaN, "PassRate", NaN, "MeanBitErrors", NaN), 0, 1);

for i = 1:numel(aggLevels)
    lvl = aggLevels(i);
    pass = false(nTrials,1);
    bitErr = NaN(nTrials,1);
    detMet = NaN(nTrials,1);
    for k = 1:nTrials
        trialTimer = tic;
        cfgK = cfg;
        cfgK.phy.pdcch.aggregationLevel = lvl;
        cfgK.phy.pdcch.blindSearch = configuredBlindSearch;
        [tx, txInfo] = sixgr.phy.dl.PDCCH_Tx(cfgK, "K", pdcchPayloadBits);
        [rxWave, noiseVar, replay, noiseOnlyWave] = localRunnerApplyPDCCHChannelAndNoise(tx.Waveform, cfgK, tx, txInfo, snr_dB);
        noiseVarArgs = localRunnerNoiseVarArgs(noiseVar);
        [rx, rxInfo] = sixgr.phy.dl.PDCCH_Rx(rxWave, cfgK, ...
            "Carrier", tx.Carrier, "PDCCH", tx.PDCCH, "K", numel(tx.DCIBits), ...
            "ListLength", listLength, noiseVarArgs{:}, "NoiseOnlyWaveform", noiseOnlyWave);
        [rxNoise, ~] = sixgr.phy.dl.PDCCH_Rx(noiseOnlyWave, cfgK, ...
            "Carrier", tx.Carrier, "PDCCH", tx.PDCCH, "K", numel(tx.DCIBits), ...
            "ListLength", listLength, noiseVarArgs{:});
        computeLatency_ms = toc(trialTimer) * 1e3;
        [be, bt] = localBitErrors(tx.DCIBits, rx.DCIBits);
        ok = logical(sixgr.util.structGet(rx, "Ok", false)) && be == 0;
        pass(k) = ok;
        bitErr(k) = be;
        detMet(k) = 1 - (double(be) / max(double(bt), 1));
        trialRows(end+1,1) = struct( ... %#ok<AGROW>
            "AggregationLevel", lvl, ...
            "Trial", k, ...
            "SNR_dB", snr_dB, ...
            "BitErrors", be, ...
            "BitsCompared", bt, ...
            "Pass", ok, ...
            "DetectionMetric", detMet(k), ...
            "BlindDecodeCount", double(sixgr.util.structGet(rxInfo, "NumCandidatesTried", NaN)), ...
            "ComputeLatency_ms", computeLatency_ms, ...
            "AppliedAWGNSNR_dB", double(sixgr.util.structGet(replay, "AppliedAWGNSNR_dB", NaN)), ...
            "NoiseVariance", double(noiseVar), ...
            "NoiseVarStatus", string(sixgr.util.structGet(rx, "NoiseVarStatus", "")), ...
            "NoiseVarSource", string(sixgr.util.structGet(rx, "NoiseVarSource", "")), ...
            "ReceiverHestSINR_dB", double(sixgr.util.structGet(rx, "ReceiverHestSINR_dB", NaN)), ...
            "ReceiverHestSINRSource", string(sixgr.util.structGet(rx, "ReceiverHestSINRSource", "")), ...
            "FalseAlarmFlag", logical(sixgr.util.structGet(rxNoise, "Ok", false)), ...
            "ChannelModelApplied", string(sixgr.util.structGet(replay, "ChannelModelApplied", "")), ...
            "ChannelFadingApplied", logical(sixgr.util.structGet(replay, "ChannelFadingApplied", false)), ...
            "AppliedLargeScaleGain_dB", double(sixgr.util.structGet(replay, "AppliedLargeScaleGain_dB", NaN)), ...
            "AppliedLargeScaleLoss_dB", double(sixgr.util.structGet(replay, "AppliedLargeScaleLoss_dB", NaN)), ...
            "AppliedPathloss_dB", double(sixgr.util.structGet(replay, "AppliedPathloss_dB", NaN)), ...
            "AppliedShadowFading_dB", double(sixgr.util.structGet(replay, "AppliedShadowFading_dB", NaN)), ...
            "AppliedO2I_dB", double(sixgr.util.structGet(replay, "AppliedO2I_dB", NaN)), ...
            "InjectedCFO_Hz", double(sixgr.util.structGet(replay, "InjectedCFO_Hz", NaN)), ...
            "InjectedTimingOffset_samples", double(sixgr.util.structGet(replay, "InjectedTimingOffset_samples", NaN)));
    end
    summaryRows(end+1,1) = struct( ... %#ok<AGROW>
        "AggregationLevel", lvl, ...
        "PassRate", mean(pass), ...
        "MeanBitErrors", mean(bitErr, "omitnan"));
end

trialT = struct2table(trialRows);
summaryT = struct2table(summaryRows);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "control", "csv", "pdcch_blind_decode_trials.csv"), trialT);
    sixgr.util.csvWriteTable(fullfile(runFolder, "control", "csv", "pdcch_blind_decode_sweep.csv"), summaryT);
    canonicalTrialT = localCanonicalizePDCCHBlindDecodeTrials(trialT, cfg, pdcchPayloadBits, listLength);
    sixgr.util.csvWriteTable(fullfile(runFolder, "control", "csv", "pdcch_trials.csv"), canonicalTrialT);
    sixgr.util.csvWriteTable(fullfile(runFolder, "air_interface", "csv", "pdcch_trials.csv"), canonicalTrialT);
end

result = struct();
result.Ok = all(summaryT.PassRate >= 0);
result.TrialTable = trialT;
result.SummaryTable = summaryT;
end

function T = localCanonicalizePDCCHBlindDecodeTrials(T, cfg, pdcchPayloadBits, listLength)
if ~(istable(T) && ~isempty(T))
    return;
end
nRows = height(T);
pass = false(nRows, 1);
if ismember("Pass", string(T.Properties.VariableNames))
    pass = logical(T.Pass);
end
if ~ismember("Status", string(T.Properties.VariableNames))
    T.Status = repmat("FAIL", nRows, 1);
    T.Status(pass) = "PASS";
end
if ~ismember("CRCPass", string(T.Properties.VariableNames))
    T.CRCPass = pass;
end
if ~ismember("Direction", string(T.Properties.VariableNames))
    T.Direction = repmat("DL", nRows, 1);
end
if ~ismember("SignalFamily", string(T.Properties.VariableNames))
    T.SignalFamily = repmat("PDCCH", nRows, 1);
end
if ~ismember("ControlStage", string(T.Properties.VariableNames))
    T.ControlStage = repmat("PDCCH_DCI", nRows, 1);
end
if ~ismember("BlindDecodeCount", string(T.Properties.VariableNames))
    T.BlindDecodeCount = repmat(double(listLength), nRows, 1);
end
if ~ismember("DCISize_bits", string(T.Properties.VariableNames))
    T.DCISize_bits = repmat(double(pdcchPayloadBits), nRows, 1);
end
if ~ismember("FalseAlarmFlag", string(T.Properties.VariableNames))
    T.FalseAlarmFlag = false(nRows, 1);
end
if ~ismember("BlockingFlag", string(T.Properties.VariableNames))
    T.BlockingFlag = false(nRows, 1);
end
if ~ismember("NonOverlappedCCEUsage", string(T.Properties.VariableNames))
    T.NonOverlappedCCEUsage = double(localRunnerColumnOrDefault(T, "AggregationLevel", nan(nRows, 1)));
end
if ~ismember("ControlCapacityUtilization", string(T.Properties.VariableNames))
    T.ControlCapacityUtilization = double(localRunnerColumnOrDefault(T, "AggregationLevel", nan(nRows, 1))) ./ 16;
end
if ~ismember("CORESETUtilization", string(T.Properties.VariableNames))
    T.CORESETUtilization = T.ControlCapacityUtilization;
end
if ~ismember("ControlLatency_ms", string(T.Properties.VariableNames))
    numerology = localResolveConfigNumerology(cfg);
    slotDuration_ms = double(numerology.SlotDurationMilliseconds);
    T.ControlLatency_ms = repmat(slotDuration_ms, nRows, 1);
end
if ~ismember("ComputeLatency_ms", string(T.Properties.VariableNames))
    T.ComputeLatency_ms = nan(nRows, 1);
end
if ~ismember("AirInterfaceTTI_ms", string(T.Properties.VariableNames))
    T.AirInterfaceTTI_ms = T.ControlLatency_ms;
end
if ~ismember("Source", string(T.Properties.VariableNames))
    T.Source = repmat("pdcch_blind_decode_waveform_runtime", nRows, 1);
end
if ~ismember("ExecutionBackend", string(T.Properties.VariableNames))
    T.ExecutionBackend = repmat("waveform", nRows, 1);
end
if ~ismember("ApproximationMode", string(T.Properties.VariableNames))
    T.ApproximationMode = repmat("none", nRows, 1);
end
if ~ismember("Notes", string(T.Properties.VariableNames))
    T.Notes = repmat("PDCCH blind-decode sweep trial from executed Tx/Rx waveform path.", nRows, 1);
end
end

function result = localRunStrictPDCCHValidationScenario(cfg, scfg, runFolder)
pdcch = sixgr.phy.pdcch.runStrictPDCCHValidation(cfg, ...
    "RunFolder", runFolder, ...
    "RunId", string(scfg.ScenarioID), ...
    "ScenarioName", string(scfg.ScenarioID), ...
    "WriteArtifacts", true);

if logical(pdcch.StrictOk)
    note = "strict PDCCH waveform blind-decode validation completed";
else
    note = string(pdcch.FailureReason);
end
kpitable = table( ...
    string("PDCCH_StrictValidation"), ...
    logical(pdcch.StrictOk), ...
    false, ...
    note, ...
    'VariableNames', {'Case','Ok','Skipped','Notes'});
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "case_status.csv"), kpitable);
    sixgr.util.csvWriteTable(fullfile(runFolder, "air_interface", "csv", "pdcch_trials.csv"), ...
        pdcch.ArtifactTables.pdcch_trials);
end

link = struct();
link.Ok = logical(pdcch.StrictOk);
link.Result = struct("Ok", logical(pdcch.StrictOk));
link.KPITable = kpitable;
link.UnsupportedCases = table();
link.RawTrials = struct("PDCCH", pdcch.ArtifactTables.pdcch_trials);

result = struct();
result.Ok = logical(pdcch.StrictOk);
result.Link = link;
result.PDCCH = pdcch;
result.Control = struct();
result.TrialTable = pdcch.ArtifactTables.pdcch_trials;
result.SummaryTable = pdcch.ArtifactTables.pdcch_low_snr_sweep;
end

function result = localRunStrictTRSValidationScenario(cfg, scfg, runFolder)
trs = sixgr.phy.trs.runStrictTRSValidation(cfg, ...
    "RunFolder", runFolder, ...
    "RunId", string(scfg.ScenarioID), ...
    "ScenarioName", string(scfg.ScenarioID), ...
    "WriteArtifacts", true);

if logical(trs.StrictOk)
    note = "strict TRS waveform tracking validation completed";
else
    note = string(trs.FailureReason);
end
kpitable = table( ...
    string("TRS_StrictValidation"), ...
    logical(trs.StrictOk), ...
    false, ...
    note, ...
    'VariableNames', {'Case','Ok','Skipped','Notes'});
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "case_status.csv"), kpitable);
    sixgr.util.csvWriteTable(fullfile(runFolder, "air_interface", "csv", "trs_trials.csv"), ...
        trs.ArtifactTables.trs_trials);
end

link = struct();
link.Ok = logical(trs.StrictOk);
link.Result = struct("Ok", logical(trs.StrictOk));
link.KPITable = kpitable;
link.UnsupportedCases = table();
link.RawTrials = struct("TRS", trs.ArtifactTables.trs_trials);

result = struct();
result.Ok = logical(trs.StrictOk);
result.Link = link;
result.TRS = trs;
result.Control = struct();
result.TrialTable = trs.ArtifactTables.trs_trials;
result.SummaryTable = trs.ArtifactTables.trs_low_snr_sweep;
end

function result = localRunStrictSRSValidationScenario(cfg, scfg, runFolder)
srs = sixgr.phy.srs.runStrictSRSValidation(cfg, ...
    "RunFolder", runFolder, ...
    "RunId", string(scfg.ScenarioID), ...
    "ScenarioName", string(scfg.ScenarioID), ...
    "WriteArtifacts", true);

if logical(srs.StrictOk)
    note = "strict SRS waveform channel-sounding validation completed";
else
    note = string(srs.FailureReason);
end
kpitable = table( ...
    string("SRS_StrictValidation"), ...
    logical(srs.StrictOk), ...
    false, ...
    note, ...
    'VariableNames', {'Case','Ok','Skipped','Notes'});
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "case_status.csv"), kpitable);
    sixgr.util.csvWriteTable(fullfile(runFolder, "air_interface", "csv", "srs_trials.csv"), ...
        srs.ArtifactTables.srs_trials);
end

link = struct();
link.Ok = logical(srs.StrictOk);
link.Result = struct("Ok", logical(srs.StrictOk));
link.KPITable = kpitable;
link.UnsupportedCases = table();
link.RawTrials = struct("SRS", srs.ArtifactTables.srs_trials);

result = struct();
result.Ok = logical(srs.StrictOk);
result.Link = link;
result.SRS = srs;
result.Control = struct();
result.TrialTable = srs.ArtifactTables.srs_trials;
result.SummaryTable = srs.ArtifactTables.srs_low_snr_sweep;
end

function result = localRunStrictChannelRFValidationScenario(cfg, scfg, runFolder)
channelRF = sixgr.channel.runStrictChannelRFValidation(cfg, ...
    "RunFolder", runFolder, ...
    "RunId", string(scfg.ScenarioID), ...
    "ScenarioName", string(scfg.ScenarioID), ...
    "WriteArtifacts", true);

if logical(channelRF.StrictOk)
    note = "strict Channel/RF configured-vs-applied validation completed";
else
    note = string(channelRF.FailureReason);
end
kpitable = table( ...
    string("ChannelRF_StrictValidation"), ...
    logical(channelRF.StrictOk), ...
    false, ...
    note, ...
    'VariableNames', {'Case','Ok','Skipped','Notes'});
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "case_status.csv"), kpitable);
end

link = struct();
link.Ok = logical(channelRF.StrictOk);
link.Result = struct("Ok", logical(channelRF.StrictOk));
link.KPITable = kpitable;
link.UnsupportedCases = table();
link.RawTrials = struct("ChannelRF", channelRF.ConfiguredVsApplied);

result = struct();
result.Ok = logical(channelRF.StrictOk);
result.Link = link;
result.ChannelRF = channelRF;
result.Control = struct();
result.TrialTable = channelRF.ConfiguredVsApplied;
result.SummaryTable = channelRF.ChannelRealizations;
end

function result = localRun6GRPDCCHStudy(cfg, scfg, runFolder)
studyDir = fullfile(runFolder, "control", "pdcch6gr_study");
study = sixgr.ctrl.runPDCCHStudyLLS(cfg, ...
    "OutputDir", studyDir, ...
    "ScenarioID", char(string(scfg.ScenarioID)), ...
    "WriteOutputs", true, ...
    "Verbose", false);

% Bind the canonical PDCCH trial authority before its first write and before
% the immutable raw-evidence snapshot is sealed.  Component-local ScenarioID
% and ConfigHash values in the study's auxiliary matrices remain component
% provenance; the canonical air-interface table carries the outer execution
% identity used by cross-artifact reconciliation.
executionIdentity = struct( ...
    "RunID", string(sixgr.util.structGet(cfg, "run.runTag", "")), ...
    "ExecutionID", string(sixgr.util.structGet(cfg, "run.executionID", "")), ...
    "ScenarioID", string(scfg.ScenarioID), ...
    "ConfigHash", string(scfg.ConfigHash));
canonicalTrialT = sixgr.runtime.bindInPathArtifactIdentity( ...
    study.PDCCHTrials, executionIdentity, "in_path");
canonicalTrialT.RunTag = repmat(executionIdentity.RunID, ...
    height(canonicalTrialT), 1);
study.PDCCHTrials = canonicalTrialT;

% Auxiliary PDCCH study matrices describe the same execution campaign, but
% their producer-local ScenarioID denotes the individual matrix case (for
% example pdcch6gr_001), not the outer scenario execution. Preserve that
% component identifier explicitly, then bind the immutable outer identity
% before any report CSV is written. This keeps cross-artifact reconciliation
% exact without mislabelling study rows as in-path data-channel evidence.
studyAuxiliaryFields = [ ...
    "SummaryByScenario","CORESETMap","SearchSpaceMap","REGIndexMap", ...
    "CCERegMap","CandidateHashTrace","DMRSLocations", ...
    "PerCandidateResults","PerSlotResults","SummaryBySNR", ...
    "SummaryByAL","SummaryByMapping","SummaryByRepetition", ...
    "SummaryByCORESETDuration","SummaryByFrequencyAllocation", ...
    "SummaryByMRSSMode","ComplexitySummary","MRSSOverlapEvents"];
for auxiliaryField = studyAuxiliaryFields
    fieldName = char(auxiliaryField);
    if ~isfield(study, fieldName) || ~istable(study.(fieldName))
        continue;
    end
    study.(fieldName) = localBindPDCCHStudyIdentity( ...
        study.(fieldName), executionIdentity);
end

controlTrace = struct();
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "air_interface", "csv", "pdcch_trials.csv"), study.PDCCHTrials);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_summary_by_scenario.csv"), study.SummaryByScenario);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_coreset_map.csv"), study.CORESETMap);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_search_space_map.csv"), study.SearchSpaceMap);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_reg_index_map.csv"), study.REGIndexMap);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_cce_reg_map.csv"), study.CCERegMap);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_candidate_hash_trace.csv"), study.CandidateHashTrace);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_dmrs_locations.csv"), study.DMRSLocations);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_per_candidate_results.csv"), study.PerCandidateResults);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_per_slot_results.csv"), study.PerSlotResults);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_summary_by_snr.csv"), study.SummaryBySNR);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_summary_by_al.csv"), study.SummaryByAL);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_summary_by_mapping.csv"), study.SummaryByMapping);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_summary_by_repetition.csv"), study.SummaryByRepetition);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_summary_by_coreset_duration.csv"), study.SummaryByCORESETDuration);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_summary_by_frequency_allocation.csv"), study.SummaryByFrequencyAllocation);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_summary_by_mrss_mode.csv"), study.SummaryByMRSSMode);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_complexity_summary.csv"), study.ComplexitySummary);
    if ~isempty(study.MRSSOverlapEvents)
        sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdcch6gr_mrss_overlap_events.csv"), study.MRSSOverlapEvents);
    end
    sixgr.truth.exportLLSEnergyDiagnostics(cfg, fullfile(runFolder, "air_interface"), ...
        struct("PDCCH", study.PDCCHTrials));
    controlTrace = sixgr.truth.exportControlPlaneTraces(runFolder, struct(), struct("PDCCH", study.PDCCHTrials));
end

result = struct();
result.Ok = istable(study.PDCCHTrials) && ~isempty(study.PDCCHTrials);
result.Link = struct( ...
    "Ok", result.Ok, ...
    "Result", struct("Ok", result.Ok), ...
    "RawTrials", struct("PDCCH", study.PDCCHTrials), ...
    "KPITable", table("PDCCH6GR", result.Ok, false, ...
        "physical PDCCH blind-decode study completed", ...
        'VariableNames', {'Case','Ok','Skipped','Notes'}), ...
    "UnsupportedCases", table());
result.Control = controlTrace;
result.Study = study;
result.TrialTable = study.PDCCHTrials;
result.SummaryTable = study.SummaryBySNR;
end

function result = localRun6GRPDSCHStudy(cfg, scfg, runFolder)
studyDir = fullfile(runFolder, "air_interface", "pdsch6gr_truth");
study = sixgr.pdsch.runPDSCHStudyLLS(cfg, ...
    "OutputDir", studyDir, ...
    "ScenarioID", char(string(scfg.ScenarioID)), ...
    "WriteOutputs", true, ...
    "Verbose", false);

if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "air_interface", "csv", "dl_pdsch_trials.csv"), study.DLTrialTable);
    sixgr.util.csvWriteTable(fullfile(runFolder, "packet_flow", "csv", "live_dl_scheduler_grants.csv"), study.DLGrantTrace);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_trial_level_results.csv"), study.TrialLevelResults);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_tb_level_results.csv"), study.TBLevelResults);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_codeword_level_results.csv"), study.CodewordLevelResults);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_layer_mapping_trace.csv"), study.LayerMappingTrace);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_fdra_allocations.csv"), study.FDRAAllocations);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_tdra_allocations.csv"), study.TDRAAllocations);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_dmrs_mapping.csv"), study.DMRSMapping);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_ptrs_mapping.csv"), study.PTRSMapping);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_channel_estimation_metrics.csv"), study.ChannelEstimationMetrics);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_parameter_estimation_metrics.csv"), study.ParameterEstimationMetrics);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_harq_trace.csv"), study.HARQTrace);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_summary_by_snr.csv"), study.SummaryBySNR);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_summary_by_band.csv"), study.SummaryByBand);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_summary_by_fdra_type.csv"), study.SummaryByFDRAType);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_summary_by_tdra_mode.csv"), study.SummaryByTDRAMode);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_summary_by_dmrs_setting.csv"), study.SummaryByDMRSSetting);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_summary_by_ptrs_setting.csv"), study.SummaryByPTRSSetting);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_summary_by_rank.csv"), study.SummaryByRank);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_summary_by_repetition.csv"), study.SummaryByRepetition);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_complexity_summary.csv"), study.ComplexitySummary);
    if ~isempty(study.MRSSOverlapEvents)
        sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "pdsch6gr_mrss_overlap_events.csv"), study.MRSSOverlapEvents);
    end
end

result = struct();
result.Ok = istable(study.DLTrialTable) && ~isempty(study.DLTrialTable);
result.Study = study;
result.TrialTable = study.DLTrialTable;
result.SummaryTable = study.SummaryBySNR;
end

function result = localRunPRACHDetectionScenario(cfg, scfg, runFolder)
study = sixgr.rach.runPRACHLLS(cfg, ...
    "ScenarioMatrix", struct("ScenarioName", char(string(scfg.ScenarioID))), ...
    "WriteOutputs", false, ...
    "Verbose", false);

[controlTrialT, initialAccessT, correlationTraceT] = localBuildPRACHRunnerTables(study, cfg);
executionIdentity = struct( ...
    "RunID", string(sixgr.util.structGet(cfg, "run.runTag", "")), ...
    "ExecutionID", string(sixgr.util.structGet(cfg, "run.executionID", "")), ...
    "ScenarioID", string(scfg.ScenarioID), ...
    "ConfigHash", string(scfg.ConfigHash));
controlTrialT = localBindCanonicalRuntimeIdentity( ...
    controlTrialT, executionIdentity, "in_path");
probabilitySweepT = localBuildPRACHProbabilitySweepTable(study);
controlTrace = struct();
if localShouldWriteCSV(scfg)
    % Publish native occupancy retained from actual transmitted preambles.
    % The reference template and noise-only detector do not create TX rows.
    nativeLayout=sixgr.report.resultLayout(runFolder);
    sixgr.truth.writeObservedREAllocationArtifacts(study.ObservedREAllocationTable,cfg,nativeLayout);
    sixgr.util.csvWriteTable(fullfile(runFolder, "control", "csv", "prach_detection_trials.csv"), controlTrialT);
    sixgr.util.csvWriteTable(fullfile(runFolder, "control", "csv", "prach_detection_summary.csv"), study.SummaryBySNR);
    sixgr.util.csvWriteTable(fullfile(runFolder, "air_interface", "csv", "prach_trials.csv"), controlTrialT);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "initial_access_random_access_outputs.csv"), initialAccessT);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "prach_correlation_trace.csv"), correlationTraceT);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "prach_correlation_traces.csv"), correlationTraceT);
    if istable(probabilitySweepT) && ~isempty(probabilitySweepT)
        sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "prach_probability_sweeps.csv"), probabilitySweepT);
    end
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "prach_summary_by_snr.csv"), study.SummaryBySNR);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "prach_summary_by_scenario.csv"), study.SummaryByScenario);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "prach_confusion_detection_types.csv"), study.Confusion);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "prach_timing_error_samples.csv"), study.TimingErrorSamples);
    if ~isempty(study.FrequencyErrorSamples)
        sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "prach_frequency_error_samples.csv"), study.FrequencyErrorSamples);
    end
    z = sixgr.util.structGet(study, "ZCDPEMetrics", struct());
    if isstruct(z)
        localWriteOptionalTable(fullfile(runFolder, "reports", "csv", "zcdpe_dpi_confusion_matrix.csv"), sixgr.util.structGet(z, "DPIConfusionMatrix", table()));
        localWriteOptionalTable(fullfile(runFolder, "reports", "csv", "zcdpe_dpi_error_probability_by_snr.csv"), sixgr.util.structGet(z, "DPIErrorBySnr", table()));
        localWriteOptionalTable(fullfile(runFolder, "reports", "csv", "zcdpe_doppler_rmse_by_snr.csv"), sixgr.util.structGet(z, "DopplerRMSEBySnr", table()));
        localWriteOptionalTable(fullfile(runFolder, "reports", "csv", "zcdpe_pool_analysis.csv"), sixgr.util.structGet(z, "PoolAnalysis", table()));
    end
    controlTrace = sixgr.truth.exportControlPlaneTraces(runFolder, struct(), struct("PRACH", controlTrialT));
end

result = struct();
result.Ok = istable(controlTrialT) && ~isempty(controlTrialT);
result.Control = controlTrace;
result.Study = study;
result.ObservedREAllocationTable = study.ObservedREAllocationTable;
result.TrialTable = controlTrialT;
result.SummaryTable = study.SummaryBySNR;
end

function result = localRunStrictPRACHValidationScenario(cfg, scfg, runFolder)
prachExecutionIdentity = struct( ...
    "RunID", string(sixgr.util.structGet(cfg, "run.runTag", "")), ...
    "ExecutionID", string(sixgr.util.structGet(cfg, "run.executionID", "")), ...
    "ScenarioID", string(scfg.ScenarioID), ...
    "ConfigHash", string(scfg.ConfigHash));
prach = sixgr.phy.prach.runStrictPRACHValidation(cfg, ...
    "RunFolder", runFolder, ...
    "RunId", prachExecutionIdentity.RunID, ...
    "ScenarioName", string(scfg.ScenarioID), ...
    "ExecutionID", prachExecutionIdentity.ExecutionID, ...
    "ScenarioConfigHash", prachExecutionIdentity.ConfigHash, ...
    "EvidenceScope", "in_path", ...
    "WriteArtifacts", true);

if logical(prach.StrictOk)
    note = "strict PRACH waveform validation completed";
else
    note = string(prach.FailureReason);
end
kpitable = table( ...
    string("PRACH_StrictValidation"), ...
    logical(prach.StrictOk), ...
    false, ...
    note, ...
    'VariableNames', {'Case','Ok','Skipped','Notes'});
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "case_status.csv"), kpitable);
    sixgr.util.csvWriteTable(fullfile(runFolder, "air_interface", "csv", "prach_trials.csv"), ...
        prach.ArtifactTables.prach_trials);
end

link = struct();
link.Ok = logical(prach.StrictOk);
link.Result = struct("Ok", logical(prach.StrictOk));
link.KPITable = kpitable;
link.UnsupportedCases = table();
link.RawTrials = struct("PRACH", prach.ArtifactTables.prach_trials);

result = struct();
result.Ok = logical(prach.StrictOk);
result.Link = link;
result.PRACH = prach;
result.Control = struct();
result.TrialTable = prach.ArtifactTables.prach_trials;
result.SummaryTable = prach.ArtifactTables.prach_missed_detection_sweep;
end

function result = localRunFourStepRAScenario(cfg, scfg, runFolder)
if logical(sixgr.util.structGet(cfg, "phy.sib1.enable", false))
    ia = sixgr.phy.broadcast.runInitialAccessWithRAAnchor(runFolder, cfg, ...
        "RunId", string(scfg.ScenarioID), ...
        "ScenarioName", string(scfg.ScenarioID));
    ra = ia.RandomAccess;
    scenarioOk = logical(ia.Ok);
else
    ia = struct();
    ra = sixgr.phy.ra.runFourStepRA(cfg, ...
        "RunFolder", runFolder, ...
        "RunId", string(scfg.ScenarioID), ...
        "ScenarioName", string(scfg.ScenarioID), ...
        "UEId", 1, ...
        "CellId", sixgr.util.structGet(cfg, "phy.carrier.NCellID", 1), ...
        "AttemptId", 1, ...
        "WriteArtifacts", true);
    scenarioOk = logical(ra.StrictOk);
end

if scenarioOk
    note = "strict MSG1-MSG4 waveform RA completed";
else
    note = string(ra.FailureReason);
end
kpitable = table( ...
    string("RandomAccess_FourStep"), ...
    logical(ra.StrictOk), ...
    false, ...
    note, ...
    'VariableNames', {'Case','Ok','Skipped','Notes'});
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "case_status.csv"), kpitable);
end

link = struct();
link.Ok = logical(scenarioOk);
link.Result = struct("Ok", logical(scenarioOk));
link.KPITable = kpitable;
link.UnsupportedCases = table();
link.RawTrials = struct("RandomAccess", ra.ArtifactTables.ra_attempts);

result = struct();
result.Ok = logical(scenarioOk);
result.Link = link;
result.RandomAccess = ra;
if ~isempty(fieldnames(ia))
    result.InitialAccess = ia;
end
result.Control = struct();
end

function [controlTrialT, initialAccessT, correlationTraceT] = localBuildPRACHRunnerTables(study, cfg)
roT = sixgr.util.structGet(study, "ROTable", table());
trialT = sixgr.util.structGet(study, "TrialTable", table());
if ~(istable(roT) && ~isempty(roT))
    controlTrialT = table();
    initialAccessT = table();
    correlationTraceT = table();
    return;
end

numerology = localResolveConfigNumerology(cfg);
slotsPerFrame = double(numerology.SlotsPerFrame);
nRows = height(roT);
frameCol = floor((double(roT.slot_id) - 1) / slotsPerFrame) + 1;
slotCol = round(double(roT.slot_id));
ueCount = localRunnerGroupedPRACHValue(trialT, roT, "preamble_tx_present", @sum, 0);
txPreamble = localRunnerGroupedPRACHValue(trialT, roT, "transmitted_preamble_index", @localFirstFiniteOrNaN, NaN);
snrCol = double(localRunnerColumnOrDefault(roT, "SNR_dB", localRunnerColumnOrDefault(roT, "snr_db", nan(nRows, 1))));
detectedPreamble = double(localRunnerColumnOrDefault(roT, "detected_preamble_index", nan(nRows, 1)));
peakMetric = double(localRunnerColumnOrDefault(roT, "peak_metric", nan(nRows, 1)));
thresholdCol = double(localRunnerColumnOrDefault(roT, "threshold", nan(nRows, 1)));
thresholdModeCol = string(localRunnerColumnOrDefault(roT, "threshold_mode", repmat("", nRows, 1)));
noiseOnlyMetric = double(localRunnerColumnOrDefault(roT, "noise_only_peak_metric", nan(nRows, 1)));
noiseVariance = double(localRunnerColumnOrDefault(roT, "noise_variance", nan(nRows, 1)));
noiseFloor = double(localRunnerColumnOrDefault(roT, "detector_noise_floor", noiseVariance));
missedDetection = double(localRunnerColumnOrDefault(roT, "missed_detection_flag", localRunnerColumnOrDefault(roT, "missed_detection", zeros(nRows, 1))));
falseAlarm = double(localRunnerColumnOrDefault(roT, "false_alarm_flag", localRunnerColumnOrDefault(roT, "FalseAlarmFlag", zeros(nRows, 1))));
timingEstSamples = double(localRunnerColumnOrDefault(roT, "EstimatedTimingOffset_samples", nan(nRows, 1)));
timingErrorSamples = double(localRunnerColumnOrDefault(roT, "TimingError_samples", nan(nRows, 1)));
timingAdvanceUs = double(localRunnerColumnOrDefault(roT, "timing_offset_est_us", nan(nRows, 1)));
channelModelApplied = string(localRunnerColumnOrDefault(roT, "channel_model", repmat("", nRows, 1)));
channelFadingApplied = double(channelModelApplied ~= "" & upper(channelModelApplied) ~= "AWGN");
rootSeq = repmat(double(sixgr.util.structGet(cfg, "phy.prach.rootSeqIndex", ...
    sixgr.util.structGet(cfg, "random_access.root_sequence_index", NaN))), nRows, 1);
zeroCorr = repmat(double(sixgr.util.structGet(cfg, "phy.prach.zeroCorrelationZone", ...
    sixgr.util.structGet(cfg, "random_access.zero_correlation_zone", NaN))), nRows, 1);
cfgIndex = repmat(double(sixgr.util.structGet(cfg, "phy.prach.configurationIndex", ...
    sixgr.util.structGet(cfg, "random_access.configuration_index", NaN))), nRows, 1);
prachDesign = string(localRunnerColumnOrDefault(roT, "prach_design", repmat("nr_baseline", nRows, 1)));
zcdpeEnabled = double(localRunnerColumnOrDefault(roT, "zcdpe_enabled", zeros(nRows, 1)));
dpiD = double(localRunnerColumnOrDefault(roT, "dpi_D", nan(nRows, 1)));
dpiTrue = double(localRunnerColumnOrDefault(roT, "dpi_d_true", nan(nRows, 1)));
dpiDetected = double(localRunnerColumnOrDefault(roT, "dpi_d_detected", nan(nRows, 1)));
dpiCorrect = double(localRunnerColumnOrDefault(roT, "dpi_correct_flag", nan(nRows, 1)));
dpiConfusion = double(localRunnerColumnOrDefault(roT, "dpi_confusion_score", nan(nRows, 1)));
dopplerEst = double(localRunnerColumnOrDefault(roT, "doppler_est_hz", nan(nRows, 1)));
dopplerError = double(localRunnerColumnOrDefault(roT, "doppler_error_hz", nan(nRows, 1)));
poolGain = double(localRunnerColumnOrDefault(roT, "pool_gain_factor", nan(nRows, 1)));

controlTrialT = table( ...
    string(localRunnerColumnOrDefault(roT, "Status", repmat("FAIL", nRows, 1))), ...
    frameCol, ...
    slotCol, ...
    ones(nRows, 1), ...
    ones(nRows, 1), ...
    double(localRunnerColumnOrDefault(roT, "CRCPass", nan(nRows, 1))), ...
    double(localRunnerColumnOrDefault(roT, "ComputeLatency_ms", nan(nRows, 1))), ...
    double(localRunnerColumnOrDefault(roT, "ProcedureDelay_ms", nan(nRows, 1))), ...
    double(localRunnerColumnOrDefault(roT, "AirInterfaceObservation_ms", nan(nRows, 1))), ...
    double(localRunnerColumnOrDefault(roT, "AcquisitionTime_ms", nan(nRows, 1))), ...
    double(localRunnerColumnOrDefault(roT, "TrueTimingOffset_samples", nan(nRows, 1))), ...
    timingEstSamples, ...
    timingErrorSamples, ...
    peakMetric, ...
    thresholdCol, ...
    thresholdModeCol, ...
    falseAlarm, ...
    double(localRunnerColumnOrDefault(roT, "wrong_preamble_flag", localRunnerColumnOrDefault(roT, "wrong_preamble_flag", zeros(nRows, 1)))), ...
    missedDetection, ...
    detectedPreamble, ...
    txPreamble, ...
    ueCount, ...
    double(localRunnerColumnOrDefault(roT, "CollisionFlag", zeros(nRows, 1))), ...
    snrCol, ...
    string(localRunnerColumnOrDefault(roT, "Notes", localRunnerColumnOrDefault(roT, "detection_type", repmat("", nRows, 1)))), ...
    string(localRunnerColumnOrDefault(roT, "scenario_id", repmat("", nRows, 1))), ...
    double(localRunnerColumnOrDefault(roT, "seed", nan(nRows, 1))), ...
    double(localRunnerColumnOrDefault(roT, "ro_id", nan(nRows, 1))), ...
    snrCol, ...
    peakMetric, ...
    thresholdCol, ...
    thresholdModeCol, ...
    noiseFloor, ...
    noiseOnlyMetric, ...
    noiseVariance, ...
    falseAlarm, ...
    missedDetection, ...
    txPreamble, ...
    detectedPreamble, ...
    double(localRunnerColumnOrDefault(roT, "preamble_index_from_peak", nan(nRows, 1))), ...
    rootSeq, ...
    zeroCorr, ...
    cfgIndex, ...
    double(localRunnerColumnOrDefault(roT, "ro_id", nan(nRows, 1))), ...
    slotCol - 1, ...
    timingEstSamples, ...
    timingAdvanceUs, ...
    channelModelApplied, ...
    channelFadingApplied, ...
    prachDesign, ...
    zcdpeEnabled, ...
    dpiD, ...
    dpiTrue, ...
    dpiDetected, ...
    dpiCorrect, ...
    dpiConfusion, ...
    dopplerEst, ...
    dopplerError, ...
    poolGain, ...
    true(nRows, 1), ...
    isfinite(peakMetric), ...
    true(nRows, 1), ...
    isfinite(noiseVariance), ...
    'VariableNames', {'Status','Frame','Slot','UEIndex','RNTI','CRCPass','ComputeLatency_ms','ProcedureDelay_ms', ...
    'AirInterfaceObservation_ms','AcquisitionTime_ms','TrueTimingOffset_samples','EstimatedTimingOffset_samples', ...
    'TimingError_samples','DetectionMetric','Threshold','ThresholdMode','FalseAlarmFlag','WrongPreambleFlag', ...
    'MissDetectionFlag','PreambleIndex','TransmittedPreambleIndex','ActiveUECount','CollisionFlag','SNR_dB','Notes', ...
    'ScenarioID','Seed','ROID','AppliedAWGNSNR_dB','CorrelationPeak','DetectionThreshold','DetectionThresholdMode', ...
    'DetectorNoiseFloor','NoiseOnlyDetectionMetric','NoiseVariance','FalseAlarm','MissedDetection', ...
    'RequestedPreambleIndex','DetectedPreambleIndex','PreambleIndexFromPeak', ...
    'PRACHRootSequenceIndex','PRACHZeroCorrelationZone','PRACHConfigurationIndex','PRACHOccasionIndex','PRACHCarrierSlot', ...
    'TimingAdvance_samples','TimingAdvance_us','ChannelModelApplied','ChannelFadingApplied', ...
    'PRACHDesign','ZCDPEEnabled','DPI_D','DPI_d_true','DPI_d_detected','DPICorrect', ...
    'DPIConfusionScore','DopplerEstimate_Hz','DopplerError_Hz','PoolGainFactor', ...
    'DetectionAttempted','DetectionUsable','MeasurementAttempted','MeasurementUsable'});
% Preserve measured preamble outcome separately from CRC applicability.
% Do not coerce a missing legacy outcome into a successful detection.
controlTrialT.CRCApplicable = false(nRows, 1);
controlTrialT.DetectionSuccess = double(localRunnerColumnOrDefault( ...
    roT, "DetectionSuccess", localRunnerColumnOrDefault( ...
    roT, "correct_detection", nan(nRows, 1))));
assert(all(isnan(controlTrialT.CRCPass)), ...
    'sixgr:lls6g:PRACHCRCNotApplicable', ...
    'PRACH preamble detection must not be exported as a CRC result.');

initialAccessT = study.SummaryBySNR;
if istable(initialAccessT) && ~isempty(initialAccessT)
    initialAccessT.ConfiguredUEsPerRO = repmat(max(double(ueCount), [], "omitnan"), height(initialAccessT), 1);
    initialAccessT.CollisionModeEnabled = repmat(any(double(controlTrialT.CollisionFlag) ~= 0), height(initialAccessT), 1);
    initialAccessT.ChannelModel = repmat(string(sixgr.util.structGet(cfg, "prach_lls.ChannelModel", "")), height(initialAccessT), 1);
end

correlationTraceT = sixgr.util.structGet(study, "CorrelationTraceTable", table());
if istable(correlationTraceT) && ~isempty(correlationTraceT)
    correlationTraceT = localNormalizePRACHCorrelationTraceTable(correlationTraceT);
else
    correlationTraceT = table();
end
end

function T = localNormalizePRACHCorrelationTraceTable(T)
requiredNames = ["trial_id","preamble_index","root_sequence_index","restricted_set_type","n_cs", ...
    "zero_correlation_zone_config","lag_samples","lag_us","correlation_abs","threshold", ...
    "noise_floor","peak_lag_samples","timing_advance_samples","detection_result", ...
    "false_alarm","missed_detection","snr_db","cfo_hz","seed","truth_status"];
for i = 1:numel(requiredNames)
    name = requiredNames(i);
    if ismember(name, string(T.Properties.VariableNames))
        continue;
    end
    if any(name == ["restricted_set_type","detection_result","truth_status"])
        T.(name) = strings(height(T), 1);
    elseif any(name == ["false_alarm","missed_detection"])
        T.(name) = false(height(T), 1);
    else
        T.(name) = nan(height(T), 1);
    end
end
T = T(:, requiredNames);
end

function T = localBuildPRACHProbabilitySweepTable(study)
roT = sixgr.util.structGet(study, "ROTable", table());
if ~(istable(roT) && ~isempty(roT))
    T = table();
    return;
end
parts = { ...
    localPRACHProbabilitySweepAxis(roT, "snr_db", "SNR_dB"), ...
    localPRACHProbabilitySweepAxis(roT, "cfo_true_hz", "CFO_Hz"), ...
    localPRACHProbabilitySweepAxis(roT, "timing_error_us", "TimingError_us")};
T = localVertcatTables(parts);
end

function T = localPRACHProbabilitySweepAxis(roT, sourceColumn, axisName)
T = table();
if ~ismember(sourceColumn, string(roT.Properties.VariableNames))
    return;
end
x = double(roT.(sourceColumn));
valid = isfinite(x);
if numel(unique(x(valid))) < 2
    return;
end
detected = localRunnerColumnOrDefault(roT, "detected_flag", zeros(height(roT), 1));
missed = localRunnerColumnOrDefault(roT, "missed_detection_flag", zeros(height(roT), 1));
falseAlarm = localRunnerColumnOrDefault(roT, "false_alarm_flag", zeros(height(roT), 1));
vals = unique(x(valid));
rows = repmat(struct("sweep_axis", "", "x_value", NaN, "n_trials", 0, ...
    "detection_probability", NaN, "miss_detection_probability", NaN, ...
    "false_alarm_probability", NaN, "truth_status", "real_lls_evidence"), numel(vals), 1);
for i = 1:numel(vals)
    mask = valid & x == vals(i);
    rows(i).sweep_axis = string(axisName);
    rows(i).x_value = double(vals(i));
    rows(i).n_trials = double(sum(mask));
    rows(i).detection_probability = mean(double(detected(mask)), "omitnan");
    rows(i).miss_detection_probability = mean(double(missed(mask)), "omitnan");
    rows(i).false_alarm_probability = mean(double(falseAlarm(mask)), "omitnan");
end
T = struct2table(rows);
end

function T = localVertcatTables(parts)
T = table();
for i = 1:numel(parts)
    Ti = parts{i};
    if ~(istable(Ti) && ~isempty(Ti))
        continue;
    end
    if isempty(T)
        T = Ti;
    else
        T = [T; Ti]; %#ok<AGROW>
    end
end
end

function values = localRunnerColumnOrDefault(T, varName, defaultValues)
if istable(T) && ismember(varName, string(T.Properties.VariableNames))
    values = T.(varName);
else
    values = defaultValues;
end
end

function values = localRunnerGroupedPRACHValue(trialT, roT, varName, reducer, defaultValue)
nRows = height(roT);
values = repmat(defaultValue, nRows, 1);
if ~(istable(trialT) && ~isempty(trialT) && ismember(varName, string(trialT.Properties.VariableNames)))
    return;
end
for iRow = 1:nRows
    mask = string(localRunnerColumnOrDefault(trialT, "scenario_id", repmat("", height(trialT), 1))) == string(roT.scenario_id(iRow)) & ...
        double(localRunnerColumnOrDefault(trialT, "seed", nan(height(trialT), 1))) == double(roT.seed(iRow)) & ...
        double(localRunnerColumnOrDefault(trialT, "ro_id", nan(height(trialT), 1))) == double(roT.ro_id(iRow)) & ...
        double(localRunnerColumnOrDefault(trialT, "slot_id", nan(height(trialT), 1))) == double(roT.slot_id(iRow));
    if ~any(mask)
        continue;
    end
    values(iRow, 1) = reducer(trialT.(varName)(mask));
end
end

function value = localFirstFiniteOrNaN(raw)
vals = double(raw(:));
vals = vals(isfinite(vals));
if isempty(vals)
    value = NaN;
else
    value = vals(1);
end
end

function result = localRunGenericSweep(cfg, scfg, runFolder, parentRunTag)
sweepCfg = scfg.get("scenario.sweep", struct());
baseProfile = lower(string(sixgr.util.structGet(sweepCfg, "base_profile")));
overrides = sixgr.util.structGet(sweepCfg, "overrides", struct([]));
if isempty(overrides)
    error("sixgr:lls6g:runner:EmptySweep", ...
        "Scenario '%s' uses generic_sweep without scenario.sweep.overrides.", scfg.ScenarioID);
end

rows = repmat(struct("Label","", "PointScenarioID","", "RunFolder","", "Ok", false, ...
    "RunID","", "ConfigHash","", "ResearchClass","", "StudyBucket",""), 0, 1);
folderTokens = strings(numel(overrides), 1);
for i = 1:numel(overrides)
    label = string(sixgr.util.structGet(overrides(i), "label", "case_" + i));
    folderTokens(i) = string(localSanitizeToken(label, "case"));
    if nnz(folderTokens(1:i) == folderTokens(i)) > 1
        error("sixgr:lls6g:runner:DuplicateSweepPointFolder", ...
            "Sweep label '%s' normalizes to duplicate folder token '%s'.", ...
            label, folderTokens(i));
    end
    subFolder = fullfile(runFolder, "sweeps", folderTokens(i));
    sixgr.util.ensureFolder(subFolder);
    overrideConfig = sixgr.util.structGet(overrides(i), "config", struct());
    subScenario = sixgr.util.mergeStruct(scfg.toStruct(), overrideConfig);
    subScenario = sixgr.lls6g.config.normalizeScenarioAliases(subScenario, ...
        "SourceFiles", scfg.SourceFiles, "ConfigPath", scfg.ConfigPath, ...
        "Authority", overrideConfig);
    sixgr.lls6g.config.validateScenarioConfig(subScenario, "Kind", "scenario", "AllowPartial", false, ...
        "Context", scfg.ConfigPath + "::sweep::" + label);
    if baseProfile == "waveform_bundle"
        subScenario.scenario.runner_profile = "waveform_bundle";
    elseif baseProfile == "ai_benchmark"
        subScenario.scenario.runner_profile = "ai_benchmark";
    else
        error("sixgr:lls6g:runner:UnsupportedSweepBaseProfile", ...
            "Unsupported scenario.sweep.base_profile '%s'.", baseProfile);
    end
    subScfg = sixgr.lls6g.config.ScenarioConfig(subScenario, ...
        "SourceFiles", scfg.SourceFiles, "ConfigPath", scfg.ConfigPath, ...
        "ConfigHash", sixgr.lls6g.config.hashResolvedScenario(subScenario), ...
        "Kind", "scenario");
    childRunID = sixgr.runtime.deriveChildRunID( ...
        parentRunTag, "sweep_point", i, label);
    % A sweep point is a new waveform execution.  Parent resume/finalize
    % options and ExecutionID must never be inherited by the child.
    subExec = localExecutePreparedScenario(subScfg, subFolder, ...
        childRunID, subFolder, struct());
    researchClass = string(subScfg.get("meta.research_class", ""));
    rows(end+1,1) = struct( ... %#ok<AGROW>
        "Label", label, ...
        "PointScenarioID", string(subScfg.ScenarioID), ...
        "RunFolder", string(subFolder), ...
        "Ok", logical(subExec.Ok), ...
        "RunID", childRunID, ...
        "ConfigHash", string(subScfg.ConfigHash), ...
        "ResearchClass", researchClass, ...
        "StudyBucket", localStudyBucketFromClass(researchClass));
end

summaryT = struct2table(rows);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "sweep_summary.csv"), summaryT);
    artifactIndexT = localBuildSweepArtifactIndex( ...
        runFolder, summaryT, baseProfile, scfg);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", ...
        "sweep_artifact_index.csv"), artifactIndexT);
    if baseProfile == "ai_benchmark"
        localAggregateAISweepEvidence(runFolder, summaryT, scfg);
    end
else
    artifactIndexT = table();
end
result = struct();
result.Ok = all(summaryT.Ok);
result.SummaryTable = summaryT;
result.ArtifactIndexTable = artifactIndexT;
end

function indexT = localBuildSweepArtifactIndex(runFolder, summaryT, baseProfile, scfg)
% Index exact child evidence without promoting child PHY rows to parent truth.
rows = repmat(struct( ...
    "Label", "", "PointRunID", "", "PointConfigHash", "", ...
    "ArtifactRole", "", "RelativePath", "", "Bytes", 0, ...
    "SHA256", "", "EvidenceClass", "measured_child_run_artifact", ...
    "ParentPrimaryWaveformRowsCopied", false), 0, 1);
for idx = 1:height(summaryT)
    childFolder = char(string(summaryT.RunFolder(idx)));
    roles = ["scenario_identity", "resolved_configuration", "scenario_summary"];
    paths = [ ...
        "meta/scenario_config_identity.json", ...
        "meta/scenario_config_resolved.json", ...
        "reports/csv/scenario_summary.csv"];
    if baseProfile == "ai_benchmark"
        roles(end+1:end+2) = ["ai_metadata", "ai_use_case_measurement"];
        paths(end+1:end+2) = ["reports/csv/ai_benchmark_metadata.csv", ...
            localAIBenchmarkRelativePath(scfg)];
    else
        direction = lower(strtrim(string(scfg.get("simulation.link_direction"))));
        if any(direction == ["", "all", "both", "dl", "downlink"])
            roles(end+1) = "dl_waveform_trials";
            paths(end+1) = "air_interface/csv/dl_pdsch_trials.csv";
        end
        if any(direction == ["", "all", "both", "ul", "uplink"])
            roles(end+1) = "ul_waveform_trials";
            paths(end+1) = "air_interface/csv/ul_pusch_trials.csv";
        end
    end
    for artifactIndex = 1:numel(paths)
        relativeToChild = paths(artifactIndex);
        fullPath = fullfile(childFolder, char(replace(relativeToChild, "/", filesep)));
        if ~isfile(fullPath)
            error("sixgr:lls6g:runner:SweepChildEvidenceMissing", ...
                "Sweep point '%s' did not persist required measured child artifact %s.", ...
                string(summaryT.Label(idx)), relativeToChild);
        end
        info = dir(fullPath);
        relativeToParent = replace(string(fullPath), string(runFolder) + filesep, "");
        relativeToParent = replace(relativeToParent, "\", "/");
        rows(end+1,1) = struct( ... %#ok<AGROW>
            "Label", string(summaryT.Label(idx)), ...
            "PointRunID", string(summaryT.RunID(idx)), ...
            "PointConfigHash", string(summaryT.ConfigHash(idx)), ...
            "ArtifactRole", roles(artifactIndex), ...
            "RelativePath", relativeToParent, ...
            "Bytes", double(info(1).bytes), ...
            "SHA256", localFileSHA256ForSnapshot(fullPath), ...
            "EvidenceClass", "measured_child_run_artifact", ...
            "ParentPrimaryWaveformRowsCopied", false);
    end
end
indexT = struct2table(rows);
end

function localAggregateAISweepEvidence(runFolder, summaryT, scfg)
relativePath = localAIBenchmarkRelativePath(scfg);
aggregate = table();
metadataAggregate = table();
for idx = 1:height(summaryT)
    childFolder = char(string(summaryT.RunFolder(idx)));
    childPath = fullfile(childFolder, char(replace(relativePath, "/", filesep)));
    childT = readtable(childPath, "VariableNamingRule", "preserve", ...
        "TextType", "string");
    if height(childT) == 0
        error("sixgr:lls6g:runner:EmptySweepChildEvidence", ...
            "AI sweep point '%s' produced a header-only benchmark table.", ...
            string(summaryT.Label(idx)));
    end
    childT.SweepLabel = repmat(string(summaryT.Label(idx)), height(childT), 1);
    childT.SweepPointRunID = repmat(string(summaryT.RunID(idx)), height(childT), 1);
    childT.SweepPointConfigHash = repmat(string(summaryT.ConfigHash(idx)), height(childT), 1);
    childT.SweepPointSourceRelativePath = repmat( ...
        replace(string(childPath), string(runFolder) + filesep, ""), height(childT), 1);
    childT.SweepPointSourceSHA256 = repmat( ...
        localFileSHA256ForSnapshot(childPath), height(childT), 1);
    aggregate = [aggregate; childT]; %#ok<AGROW>

    metadataPath = fullfile(childFolder, "reports", "csv", "ai_benchmark_metadata.csv");
    metadataT = readtable(metadataPath, "VariableNamingRule", "preserve", ...
        "TextType", "string");
    metadataT.SweepLabel = repmat(string(summaryT.Label(idx)), height(metadataT), 1);
    metadataT.SweepPointRunID = repmat(string(summaryT.RunID(idx)), height(metadataT), 1);
    metadataT.SweepPointConfigHash = repmat(string(summaryT.ConfigHash(idx)), height(metadataT), 1);
    metadataT.SweepPointSourceSHA256 = repmat( ...
        localFileSHA256ForSnapshot(metadataPath), height(metadataT), 1);
    metadataAggregate = [metadataAggregate; metadataT]; %#ok<AGROW>
end
targetPath = fullfile(runFolder, char(replace(relativePath, "/", filesep)));
sixgr.util.csvWriteTable(targetPath, aggregate);
sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", ...
    "ai_benchmark_metadata.csv"), metadataAggregate);
end

function relativePath = localAIBenchmarkRelativePath(scfg)
useCase = lower(strtrim(string(scfg.get("ai_ml.use_case"))));
switch useCase
    case "channel_estimation_enhancement"
        relativePath = "reports/csv/ai_channel_estimation_benchmark.csv";
    case "csi_compression_reconstruction"
        relativePath = "reports/csv/ai_csi_compression_benchmark.csv";
    case "link_adaptation_mcs_selection"
        relativePath = "reports/csv/ai_link_adaptation_benchmark.csv";
    case "interference_classification"
        relativePath = "reports/csv/ai_interference_classification_benchmark.csv";
    case "detector_selection"
        relativePath = "reports/csv/ai_detector_selection_benchmark.csv";
    case "impairment_mitigation"
        relativePath = "reports/csv/ai_impairment_mitigation_benchmark.csv";
    case "beam_prediction"
        relativePath = "beamforming/csv/ai_beam_prediction_benchmark.csv";
    case "energy_aware_mode_selection"
        relativePath = "reports/csv/ai_energy_mode_selection.csv";
    otherwise
        error("sixgr:lls6g:runner:UnsupportedAIUseCase", ...
            "Unsupported ai_ml.use_case '%s' for sweep evidence aggregation.", useCase);
end
end

function result = localRunAIBenchmark(cfg, scfg, runFolder)
useCase = lower(string(scfg.get("ai_ml.use_case")));
aiEnabled = logical(scfg.get("ai_ml.enabled"));
descriptor = localLoadAIDescriptor(scfg.get("ai_ml.model_path"));
if aiEnabled && isempty(fieldnames(descriptor))
    error("sixgr:lls6g:runner:MissingAIDescriptor", ...
        "AI-enabled benchmark '%s' requires a readable ai_ml.model_path descriptor.", useCase);
end
switch useCase
    case "channel_estimation_enhancement"
        result = localRunAIChannelEstimationBenchmark(cfg, scfg, runFolder, descriptor, aiEnabled);
    case "csi_compression_reconstruction"
        result = localRunAICSICompressionBenchmark(scfg, runFolder, descriptor, aiEnabled);
    case "link_adaptation_mcs_selection"
        result = localRunAILinkAdaptationBenchmark(scfg, runFolder, descriptor, aiEnabled);
    case "beam_prediction"
        result = localRunAIBeamPredictionBenchmark(scfg, runFolder, descriptor);
    case "interference_classification"
        result = localRunAIInterferenceClassificationBenchmark(scfg, runFolder, descriptor, aiEnabled);
    case "detector_selection"
        result = localRunAIDetectorSelectionBenchmark(scfg, runFolder, descriptor, aiEnabled);
    case "impairment_mitigation"
        result = localRunAIImpairmentMitigationBenchmark(scfg, runFolder, descriptor, aiEnabled);
    case "energy_aware_mode_selection"
        result = localRunAIEnergyModeSelection(scfg, runFolder, descriptor);
    otherwise
        error("sixgr:lls6g:runner:UnsupportedAIUseCase", ...
            "Unsupported ai_ml.use_case '%s'.", useCase);
end
end

function result = localRunAIChannelEstimationBenchmark(cfg, scfg, runFolder, descriptor, aiEnabled)
nObs = max(1, round(double(scfg.get("ai_ml.benchmark_observations"))));
snr_dB = double(scfg.get("simulation.snr_db"));
baselineNmse = NaN(nObs,1);
pluginNmse = NaN(nObs,1);
metadata = localBenchmarkMetadata(scfg, descriptor, aiEnabled);
confidenceValue = localBenchmarkConfidence(descriptor, scfg);

for k = 1:nObs
    [tx, ~] = sixgr.phy.ul.SRS_Tx(cfg);
    [rxWave, nVar] = localAddAwgnOnly(tx.Waveform, snr_dB);
    noiseVarArgs = localRunnerNoiseVarArgs(nVar);
    rx = sixgr.phy.ul.SRS_Rx(rxWave, cfg, "Carrier", tx.Carrier, "SRS", tx.SRS, noiseVarArgs{:});
    Hbase = rx.Hest;
    baselineNmse(k) = localUnitChannelNMSE(Hbase);
    if aiEnabled
        Hplug = localApplyCEPlugin(Hbase, descriptor);
        pluginNmse(k) = localUnitChannelNMSE(Hplug);
    end
end

if aiEnabled
    T = table([repmat("classical", nObs, 1); repmat("ai_plugin", nObs, 1)], ...
        [baselineNmse; pluginNmse], 'VariableNames', {'Method','NMSE_dB'});
else
    T = table(repmat("classical", nObs, 1), baselineNmse, ...
        'VariableNames', {'Method','NMSE_dB'});
end
T = localAppendBenchmarkColumns(T, metadata, confidenceValue);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_channel_estimation_benchmark.csv"), T);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_benchmark_metadata.csv"), struct2table(metadata));
end
result = struct("Ok", true, "BenchmarkTable", T);
end

function result = localRunAICSICompressionBenchmark(scfg, runFolder, descriptor, aiEnabled)
nObs = max(1, round(double(scfg.get("ai_ml.benchmark_observations"))));
nTx = double(scfg.get("mimo.n_tx_ant"));
nRx = double(scfg.get("mimo.n_rx_ant"));
metadata = localBenchmarkMetadata(scfg, descriptor, aiEnabled);
confidenceValue = localBenchmarkConfidence(descriptor, scfg);
if aiEnabled
    latentDim = double(localRequireDescriptorField(descriptor, "latent_dim"));
    quantBits = double(localRequireDescriptorField(descriptor, "quant_bits"));
else
    latentDim = NaN;
    quantBits = NaN;
end
rows = repmat(struct("Observation", NaN, "BaselineNMSE_dB", NaN, "PluginNMSE_dB", NaN, ...
    "CompressionRatio", NaN, "QuantBits", NaN), 0, 1);

for k = 1:nObs
    H = (randn(nRx, nTx) + 1i*randn(nRx, nTx)) / sqrt(2);
    Hvec = [real(H(:)); imag(H(:))];
    if aiEnabled
        [Hhat, ratio] = localApplyCSICompressionPlugin(Hvec, descriptor, latentDim, quantBits);
        pluginNmse = 10 * log10(max(mean(abs(Hvec - Hhat).^2) / max(mean(abs(Hvec).^2), eps), eps));
    else
        ratio = 1;
        pluginNmse = NaN;
    end
    rows(end+1,1) = struct("Observation", k, "BaselineNMSE_dB", 0, ... %#ok<AGROW>
        "PluginNMSE_dB", pluginNmse, "CompressionRatio", ratio, "QuantBits", quantBits);
end

T = struct2table(rows);
T = localAppendBenchmarkColumns(T, metadata, confidenceValue);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_csi_compression_benchmark.csv"), T);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_benchmark_metadata.csv"), struct2table(metadata));
end
result = struct("Ok", true, "BenchmarkTable", T);
end

function result = localRunAILinkAdaptationBenchmark(scfg, runFolder, descriptor, aiEnabled)
nObs = max(1, round(double(scfg.get("ai_ml.benchmark_observations"))));
snr0 = double(scfg.get("simulation.snr_db"));
metadata = localBenchmarkMetadata(scfg, descriptor, aiEnabled);
confidenceValue = localBenchmarkConfidence(descriptor, scfg);
mcsBias = double(localOptionalDescriptorValue(descriptor, "mcs_bias", 0));
snrStep = double(localOptionalDescriptorValue(descriptor, "snr_step_db", 2));
rows = repmat(struct("Observation", NaN, "SNR_dB", NaN, "BaselineMCS", NaN, ...
    "PluginMCS", NaN, "OracleMCS", NaN, "BaselineThroughputScore", NaN, ...
    "PluginThroughputScore", NaN, "PluginMatchesOracle", false), 0, 1);

for k = 1:nObs
    snr = snr0 + (-0.5 + (k-1)/max(nObs-1,1)) * 12;
    oracleMCS = localClampMCS(round((snr + 8) / max(snrStep, eps)));
    baselineMCS = localClampMCS(round((snr + 6) / max(snrStep, eps)));
    if aiEnabled
        pluginMCS = localClampMCS(baselineMCS + mcsBias);
    else
        pluginMCS = baselineMCS;
    end
    rows(end+1,1) = struct( ... %#ok<AGROW>
        "Observation", k, ...
        "SNR_dB", snr, ...
        "BaselineMCS", baselineMCS, ...
        "PluginMCS", pluginMCS, ...
        "OracleMCS", oracleMCS, ...
        "BaselineThroughputScore", localMCSScore(baselineMCS), ...
        "PluginThroughputScore", localMCSScore(pluginMCS), ...
        "PluginMatchesOracle", pluginMCS == oracleMCS);
end

T = struct2table(rows);
T = localAppendBenchmarkColumns(T, metadata, confidenceValue);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_link_adaptation_benchmark.csv"), T);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_benchmark_metadata.csv"), struct2table(metadata));
end
result = struct("Ok", true, "BenchmarkTable", T);
end

function result = localRunAIInterferenceClassificationBenchmark(scfg, runFolder, descriptor, aiEnabled)
nObs = max(1, round(double(scfg.get("ai_ml.benchmark_observations"))));
metadata = localBenchmarkMetadata(scfg, descriptor, aiEnabled);
confidenceValue = localBenchmarkConfidence(descriptor, scfg);
thresholds = double(localOptionalDescriptorValue(descriptor, "classification_thresholds_db", [3 10]));
rows = repmat(struct("Observation", NaN, "InterferenceLevel_dB", NaN, "BaselineClass", "", ...
    "PluginClass", "", "OracleClass", "", "PluginCorrect", false), 0, 1);

for k = 1:nObs
    interf = -3 + 18 * (k-1) / max(nObs-1, 1);
    oracle = localInterferenceClass(interf, thresholds);
    baseline = localInterferenceClass(interf + 1, thresholds);
    if aiEnabled
        plugin = localInterferenceClass(interf, thresholds);
    else
        plugin = baseline;
    end
    rows(end+1,1) = struct( ... %#ok<AGROW>
        "Observation", k, ...
        "InterferenceLevel_dB", interf, ...
        "BaselineClass", baseline, ...
        "PluginClass", plugin, ...
        "OracleClass", oracle, ...
        "PluginCorrect", plugin == oracle);
end

T = struct2table(rows);
T = localAppendBenchmarkColumns(T, metadata, confidenceValue);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_interference_classification_benchmark.csv"), T);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_benchmark_metadata.csv"), struct2table(metadata));
end
result = struct("Ok", true, "BenchmarkTable", T);
end

function result = localRunAIDetectorSelectionBenchmark(scfg, runFolder, descriptor, aiEnabled)
nObs = max(1, round(double(scfg.get("ai_ml.benchmark_observations"))));
metadata = localBenchmarkMetadata(scfg, descriptor, aiEnabled);
confidenceValue = localBenchmarkConfidence(descriptor, scfg);
conditionThreshold = double(localOptionalDescriptorValue(descriptor, "condition_threshold", 12));
rows = repmat(struct("Observation", NaN, "ConditionNumber", NaN, "BaselineDetector", "", ...
    "PluginDetector", "", "OracleDetector", "", "PluginCorrect", false), 0, 1);

for k = 1:nObs
    condNumber = 4 + 18 * (k-1) / max(nObs-1, 1);
    oracle = localDetectorChoice(condNumber, conditionThreshold);
    baseline = localDetectorChoice(condNumber, conditionThreshold + 3);
    if aiEnabled
        plugin = localDetectorChoice(condNumber, conditionThreshold);
    else
        plugin = baseline;
    end
    rows(end+1,1) = struct( ... %#ok<AGROW>
        "Observation", k, ...
        "ConditionNumber", condNumber, ...
        "BaselineDetector", baseline, ...
        "PluginDetector", plugin, ...
        "OracleDetector", oracle, ...
        "PluginCorrect", plugin == oracle);
end

T = struct2table(rows);
T = localAppendBenchmarkColumns(T, metadata, confidenceValue);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_detector_selection_benchmark.csv"), T);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_benchmark_metadata.csv"), struct2table(metadata));
end
result = struct("Ok", true, "BenchmarkTable", T);
end

function result = localRunAIImpairmentMitigationBenchmark(scfg, runFolder, descriptor, aiEnabled)
nObs = max(1, round(double(scfg.get("ai_ml.benchmark_observations"))));
metadata = localBenchmarkMetadata(scfg, descriptor, aiEnabled);
confidenceValue = localBenchmarkConfidence(descriptor, scfg);
evmGain = double(localOptionalDescriptorValue(descriptor, "evm_improvement_db", 0.5));
rows = repmat(struct("Observation", NaN, "BaselineEVM_dB", NaN, "PluginEVM_dB", NaN, ...
    "Improvement_dB", NaN, "MitigationApplied", false), 0, 1);

for k = 1:nObs
    baseline = -18 + 6 * (k-1) / max(nObs-1, 1);
    if aiEnabled
        plugin = baseline - evmGain;
    else
        plugin = baseline;
    end
    rows(end+1,1) = struct( ... %#ok<AGROW>
        "Observation", k, ...
        "BaselineEVM_dB", baseline, ...
        "PluginEVM_dB", plugin, ...
        "Improvement_dB", baseline - plugin, ...
        "MitigationApplied", aiEnabled);
end

T = struct2table(rows);
T = localAppendBenchmarkColumns(T, metadata, confidenceValue);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_impairment_mitigation_benchmark.csv"), T);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_benchmark_metadata.csv"), struct2table(metadata));
end
result = struct("Ok", true, "BenchmarkTable", T);
end

function result = localRunAIBeamPredictionBenchmark(scfg, runFolder, descriptor)
nObs = max(1, round(double(scfg.get("ai_ml.benchmark_observations"))));
nTx = double(scfg.get("mimo.n_tx_ant"));
arr = struct("Nant", nTx, "nRow", 1, "nCol", nTx);
numBeams = double(localRequireDescriptorField(descriptor, "num_beams"));
W = sixgr.rf.BeamRefinementCSIRS.makeCodebookFromArray(arr, 1, numBeams);
rows = repmat(struct("Observation", NaN, "OracleBeam", NaN, "PredictedBeam", NaN, "Correct", false), 0, 1);
metadata = localBenchmarkMetadata(scfg, descriptor, true);
confidenceValue = localBenchmarkConfidence(descriptor, scfg);

for k = 1:nObs
    H = (randn(1, nTx) + 1i*randn(1, nTx)) / sqrt(2);
    [~, oracleIdx, metric] = sixgr.rf.BeamRefinementCSIRS.selectBestBeam(H, W);
    predIdx = localApplyBeamPlugin(metric, descriptor);
    rows(end+1,1) = struct("Observation", k, "OracleBeam", oracleIdx, ... %#ok<AGROW>
        "PredictedBeam", predIdx, "Correct", predIdx == oracleIdx);
end

T = struct2table(rows);
T = localAppendBenchmarkColumns(T, metadata, confidenceValue);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "beamforming", "csv", "ai_beam_prediction_benchmark.csv"), T);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_benchmark_metadata.csv"), struct2table(metadata));
end
result = struct("Ok", true, "BenchmarkTable", T);
end

function result = localRunAIEnergyModeSelection(scfg, runFolder, descriptor)
txPower = double(scfg.get("energy_efficiency.tx_power_dbm"));
rfChains = double(scfg.get("energy_efficiency.rf_chain_count"));
aiBudget = double(scfg.get("ai_ml.flops_budget"));
pluginBias = double(localRequireDescriptorField(descriptor, "energy_bias"));
perFlopScore = double(scfg.get("energy_efficiency.ai_compute_energy_per_flop_score"));
metadata = localBenchmarkMetadata(scfg, descriptor, true);
confidenceValue = localBenchmarkConfidence(descriptor, scfg);
classicalEnergy = txPower * rfChains;
aiEnergy = classicalEnergy * (1 + pluginBias) + perFlopScore * aiBudget;
selected = "classical";
if aiEnergy <= classicalEnergy
    selected = "ai_plugin";
end
T = table(classicalEnergy, aiEnergy, string(selected), ...
    'VariableNames', {'ClassicalEnergyScore','AIPluginEnergyScore','SelectedMode'});
T = localAppendBenchmarkColumns(T, metadata, confidenceValue);
if localShouldWriteCSV(scfg)
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_energy_mode_selection.csv"), T);
    sixgr.util.csvWriteTable(fullfile(runFolder, "reports", "csv", "ai_benchmark_metadata.csv"), struct2table(metadata));
end
result = struct("Ok", true, "DecisionTable", T);
end

function T = localBindCanonicalRuntimeIdentity(T, identity, evidenceScope)
% Bind the immutable execution identity before a primary CSV is written.
% ScenarioConfigHash is the binder's unambiguous cross-artifact authority;
% ConfigHash and RunTag are retained as canonical compatibility columns used
% by the browser and semantic auditors. All values originate from the same
% resolved execution identity, so contradictory producer rows fail closed.
T = sixgr.runtime.bindInPathArtifactIdentity(T, identity, evidenceScope);
n = height(T);
T.RunTag = repmat(string(identity.RunID), n, 1);
T.ConfigHash = repmat(lower(string(identity.ConfigHash)), n, 1);
end

function T = localBindPDCCHStudyIdentity(T, identity)
% Keep the component matrix identity separate from the scenario identity.
names = string(T.Properties.VariableNames);
scenarioColumn = names(strcmpi(names, "ScenarioID"));
if ~isempty(scenarioColumn)
    if any(strcmpi(names, "ComponentScenarioID"))
        error("sixgr:lls6g:PDCCHStudyIdentityCollision", ...
            "PDCCH study table contains both ScenarioID and ComponentScenarioID.");
    end
    T.Properties.VariableNames{char(scenarioColumn(1))} = ...
        "ComponentScenarioID";
end
T = localBindCanonicalRuntimeIdentity(T, identity, ...
    "same_execution_campaign");
end

function execOut = localExecutePreparedScenario(scfg, runFolder, runTag, publicRunFolder, executionOptions)
if nargin < 3
    runTag = "";
end
if nargin < 4 || strlength(string(publicRunFolder)) == 0
    publicRunFolder = runFolder;
end
if nargin < 5 || ~isstruct(executionOptions)
    executionOptions = struct();
end
runStartUTC = localUTCStamp();
runTimer = tic;
% Raster artifacts must be independent of the MATLAB desktop theme.  Keep
% these defaults scoped to this execution so every report/contract figure
% starts with a readable light canvas under R2024a through R2026a.
rasterDefaults = sixgr.visual.RasterFigureStyle.installDefaults();
rasterDefaultsCleanup = onCleanup(@() ...
    sixgr.visual.RasterFigureStyle.restoreDefaults(rasterDefaults)); %#ok<NASGU>
layout = sixgr.report.resultLayout(runFolder);
localEnsureScenarioDirs(layout);
localApplyRunRandomness(scfg);
localDBLog("INFO", "Preparing LLS run: scenario=%s runTag=%s runFolder=%s", ...
    char(string(scfg.ScenarioID)), char(string(runTag)), char(string(runFolder)));

cfg = sixgr.lls6g.buildInternalConfig(scfg, runFolder);
% The contract registry is intentionally per execution and memory-only.
% Production subsystems may register only tables/renderers they generated
% during this run; no finalizer is allowed to ingest stale files.
artifactEvidence = sixgr.artifact.EvidenceRegistry();
cfg.run.runTag = char(string(runTag));
executionIdentity = sixgr.runtime.resolveExecutionIdentity( ...
    runFolder, string(runTag), string(scfg.ConfigHash), executionOptions);
    cfg.run.executionID = char(executionIdentity.ExecutionID);
    cfg.meta.executionID = char(executionIdentity.ExecutionID);
    sixgr.runtime.RuntimeCallLedger.configure(runFolder, struct( ...
        "RunId", string(runTag), ...
        "ExecutionID", string(executionIdentity.ExecutionID), ...
        "ConfigHash", string(executionIdentity.ConfigHash), ...
        "PreserveExisting", logical(executionIdentity.ResumeRequested)));
    runtimeCallLedgerCleanup = onCleanup(@() ...
        sixgr.runtime.RuntimeCallLedger.flush()); %#ok<NASGU>
configuredProfile = lower(strtrim(string(scfg.get("scenario.runner_profile"))));
cfg.run.configuredRunnerProfile = char(configuredProfile);
cfg.run.runnerProfile = char(configuredProfile);
cfg.run.scenarioID = char(string(scfg.ScenarioID));
cfg.meta.scenarioID = char(string(scfg.ScenarioID));
cfg.meta.configHash = char(string(scfg.ConfigHash));
cfg = localEnsureExactMexAcceleration(cfg);
if localIsSmokePublicationRun(scfg)
    cfg = localForceSerialSmokeExecution(cfg);
end
cfg = localEnsureParallelExecution(cfg);
sixgr.perf.TimeProfiler.configure(cfg);
profilerCfg = localResolveProfilerConfig(scfg);
profilerState = localStartProfilerIfEnabled(profilerCfg);
storeInfo = sixgr.db.activateArtifactStore(runFolder, cfg, struct( ...
    "ScenarioID", scfg.ScenarioID, ...
    "RunTag", runTag, ...
    "Bucket", scfg.get("output.bucket"), ...
    "Profile", localResolveRunRowProfileName(scfg), ...
    "LogicalRunFolder", publicRunFolder, ...
    "ScenarioConfigStruct", scfg.toStruct(), ...
    "ScenarioSourceFiles", string(scfg.SourceFiles(:)), ...
    "ScenarioConfigSourceKind", localResolveScenarioSourceKind(scfg)));
cleanupStore = onCleanup(@() sixgr.db.deactivateArtifactStore()); %#ok<NASGU>
sixgr.config.publishConfigApplicationEvidence("reset", struct( ...
    "RunId", string(runTag), ...
    "ScenarioID", string(scfg.ScenarioID), ...
    "RunTag", string(runTag)));
localPublishMappedRuntimeConfigEvidence(scfg, cfg);
if logical(sixgr.util.structGet(storeInfo, "Active", false))
    sixgr.db.markRunStatus("running", struct("started_utc", runStartUTC));
end
localDBLog("INFO", "Artifact store active=%d backend=%s schema=%s", ...
    double(logical(sixgr.util.structGet(storeInfo, "Active", false))), ...
    char(string(sixgr.util.structGet(storeInfo, "Backend", ""))), ...
    char(string(sixgr.util.structGet(storeInfo, "DatabaseSchema", ""))));

profile = localResolveEffectiveRunnerProfile(scfg, cfg, configuredProfile);
cfg.run.runnerProfile = char(profile);
result = struct();
manifest = struct();
runtimeSummary = struct();
environmentSummary = struct();
sourceProvenance = struct();
reportBundle = struct();
configOwnership = struct();
scenarioStatus = struct();
truthArtifactScan = struct();
artifactContractResult = struct();
optionalArtifactIssues = strings(0, 1);
profilerArtifacts = struct();
phase7ExecutionEvidence = struct();
fixedSNRSweepAudit = struct();
geometryScenarioAudit = struct();
geometryScenarioPlots = struct();
causalPHYChainAudit = struct();
profilerArtifactsExported = false;
truthGatedCompletionPublished = false;
evidenceFinalizationAttempt = struct();
evidenceLifecycle = struct();

try
    localDBLog("INFO", "Writing resolved snapshots.");
    localWriteResolvedSnapshots(layout, scfg);
    localDBLog("INFO", "Resolving exact DL/UL resource allocations before slot zero.");
    allocationTargets = localAllocationPreflightTargets(profile, scfg);
    [plannedAllocationT, allocationCheckT] = ...
        sixgr.truth.buildPlannedREAllocation(cfg, ...
        "TargetChannels", allocationTargets);
    frameCSVDir = layout.ComponentCSVDirs.frame_grid;
    [plannedAllocationT,plannedPRACHNativeT]=sixgr.truth.splitREAllocationDomains(plannedAllocationT);
    if ~isempty(plannedPRACHNativeT)
        sixgr.util.csvWriteTable(fullfile(frameCSVDir, ...
            'planned_prach_native_allocation.csv'),plannedPRACHNativeT,'PreserveSchema',true);
    end
    sixgr.util.csvWriteTable(fullfile(frameCSVDir, ...
        "planned_re_allocation.csv"), plannedAllocationT, ...
        "PreserveSchema", true);
    sixgr.util.csvWriteTable(fullfile(frameCSVDir, ...
        "allocation_resolution_preflight.csv"), allocationCheckT, ...
        "PreserveSchema", true);
    sixgr.truth.assertAllocationPreflight(allocationCheckT);
    localDBLog("INFO", "Exporting live geometry artifacts.");
    sixgr.truth.exportLiveGeometryArtifacts(layout, scfg, cfg);

    localDBLog("INFO", "Executing runner profile=%s.", char(profile));
    switch profile
        case "waveform_bundle"
            result = localRunWaveformBundleScenario(cfg, scfg, runFolder, executionOptions);
        case "system_level_lls"
            result = localRunSystemLevelScenario(cfg, scfg, runFolder);
        case "pdcch_blind_decode_sweep"
            result = localRunPDCCHBlindDecodeSweep(cfg, scfg, runFolder);
        case "pdcch_strict_validation"
            result = localRunStrictPDCCHValidationScenario(cfg, scfg, runFolder);
        case "trs_strict_validation"
            result = localRunStrictTRSValidationScenario(cfg, scfg, runFolder);
        case "srs_strict_validation"
            result = localRunStrictSRSValidationScenario(cfg, scfg, runFolder);
        case "channel_rf_strict_validation"
            result = localRunStrictChannelRFValidationScenario(cfg, scfg, runFolder);
        case "ctrl6gr_pdcch_study"
            result = localRun6GRPDCCHStudy(cfg, scfg, runFolder);
        case "pdsch6gr_truth_study"
            result = localRun6GRPDSCHStudy(cfg, scfg, runFolder);
        case "prach_detection"
            result = localRunPRACHDetectionScenario(cfg, scfg, runFolder);
        case "prach_strict_validation"
            result = localRunStrictPRACHValidationScenario(cfg, scfg, runFolder);
        case "random_access_four_step"
            result = localRunFourStepRAScenario(cfg, scfg, runFolder);
        case "generic_sweep"
            result = localRunGenericSweep(cfg, scfg, runFolder, runTag);
        case "ai_benchmark"
            result = localRunAIBenchmark(cfg, scfg, runFolder);
        case "full_stack_qualification"
            result = sixgr.integration.qualification. ...
                FullStackQualificationRunner.run(cfg, scfg, ...
                string(runFolder));
        otherwise
            error("sixgr:lls6g:runner:UnknownProfile", ...
                "Unsupported scenario.runner_profile '%s' for '%s'.", profile, scfg.ScenarioID);
    end
    localDBLog("INFO", "Runner profile completed. result.Ok=%d", ...
        double(logical(sixgr.util.structGet(result, "Ok", false))));
    if logical(sixgr.util.structGet(cfg, "perf.exportTimeProfile", false))
        localDBLog("INFO", "Exporting TX/RX chain time-profile and complexity coverage artifacts.");
        sixgr.perf.TimeProfiler.export(runFolder, cfg);
    end

    scenarioStatus = localAggregateScenarioStatus(result);
    result = localApplyScenarioStatus(result, scenarioStatus);
    localDBLog("INFO", "Scenario status aggregated: completion=%s resultOk=%d requiredFailures=%d optionalPruned=%d", ...
        char(string(scenarioStatus.RunCompletion)), double(logical(scenarioStatus.ResultOk)), ...
        double(scenarioStatus.RequiredFailureCount), double(scenarioStatus.OptionalPrunedCount));

    localDBLog("INFO", "Annotating CSV artifacts.");
    localAnnotateAllCSV(runFolder, scfg, profile);
    summaryT = localBuildScenarioSummaryTable(scfg, cfg, profile, result, scenarioStatus);
    if logical(scfg.get("output.save_csv"))
        localDBLog("INFO", "Writing scenario summary CSV.");
        sixgr.util.csvWriteTable(fullfile(layout.ReportCSVDir, "scenario_summary.csv"), summaryT);
    end
    runtimeSummary = localBuildRuntimeSummary(runStartUTC, runTimer, profile, publicRunFolder, cfg);
    environmentSummary = localBuildEnvironmentSummary(cfg);
    % Source provenance is immutable for this MATLAB process.  Capturing it
    % once avoids repeatedly rebuilding a potentially large dirty-tree patch
    % bundle each time terminal status requires a manifest rewrite.
    sourceProvenance = localDetectGitProvenance( ...
        logical(scfg.get("logging.include_git_hash")));
    localDBLog("INFO", "Writing runtime and environment summaries.");
    sixgr.util.jsonWrite(fullfile(layout.MetaDir, "runtime_summary.json"), runtimeSummary);
    sixgr.util.jsonWrite(fullfile(layout.MetaDir, "environment.json"), environmentSummary);
    manifest = localBuildManifest(scfg, publicRunFolder, profile, result, runtimeSummary, environmentSummary, scenarioStatus, sourceProvenance);
    localDBLog("INFO", "Writing scenario manifest.");
    localWriteScenarioManifest(layout, manifest);
    if logical(sixgr.util.structGet(sixgr.util.structGet(result, "Link", struct()), "ProfileStoppedEarly", false))
        profileStopReason = string(sixgr.util.structGet(sixgr.util.structGet(result, "Link", struct()), "ProfileStopReason", ""));
        manifest.ProfileStoppedEarly = true;
        manifest.ProfileStopReason = char(profileStopReason);
        manifest.PublicationMode = "profile_debug";
        manifest.PublicationModeNotes = "Profile debug run stopped early and intentionally skipped publication-grade truth-contract/report bundle exports.";
        localDBLog("WARN", "Profile debug stop active; skipping publication-grade ownership/report/truth-contract exports: %s", ...
            char(profileStopReason));
        localWriteScenarioManifest(layout, manifest);
        localMarkRunStatusSafe(string(scenarioStatus.RunCompletion), ...
            localBuildTerminalStatusPayload(scenarioStatus, "profile_debug_stop_complete", optionalArtifactIssues));
        execOut = localBuildExecOut(profile, result, manifest, runtimeSummary, environmentSummary, ...
            reportBundle, configOwnership, scenarioStatus, profilerArtifacts, optionalArtifactIssues);
        return;
    end
    if localIsSmokePublicationRun(scfg)
        scenarioStatus = localApplySmokePublicationStatus(scenarioStatus);
        result = localApplyScenarioStatus(result, scenarioStatus);
        manifest = localBuildManifest(scfg, publicRunFolder, profile, result, runtimeSummary, environmentSummary, scenarioStatus, sourceProvenance);
        manifest.PublicationMode = "smoke";
        manifest.PublicationModeNotes = "Runner smoke publication: profile artifacts were written, release truth-contract/report bundle publication was intentionally skipped.";
        localDBLog("INFO", "Smoke publication mode active; skipping release truth-contract/report bundle publication.");
        localWriteScenarioManifest(layout, manifest);
        localMarkRunStatusSafe(string(scenarioStatus.RunCompletion), ...
            localBuildTerminalStatusPayload(scenarioStatus, "run_smoke_publication_complete", optionalArtifactIssues));
        execOut = localBuildExecOut(profile, result, manifest, runtimeSummary, environmentSummary, ...
            reportBundle, configOwnership, scenarioStatus, profilerArtifacts, optionalArtifactIssues);
        return;
    end
    if profile == "full_stack_qualification"
        % Phase-18 owns a selected-preset artifact, value, publication and
        % acceptance truth contract spanning all canonical domain runners.
        % Applying the ordinary single-link report contract here would
        % incorrectly demand one flat radio environment and duplicate the
        % qualification authority.
        manifest.PublicationMode = "full_stack_qualification";
        manifest.PublicationModeNotes = ...
            "Qualification-owned immutable multi-subcase truth and artifact contract.";
        localWriteScenarioManifest(layout, manifest);
        localMarkRunStatusSafe(string(scenarioStatus.RunCompletion), ...
            localBuildTerminalStatusPayload(scenarioStatus, ...
            "full_stack_qualification_complete", optionalArtifactIssues));
        execOut = localBuildExecOut(profile, result, manifest, ...
            runtimeSummary, environmentSummary, reportBundle, ...
            configOwnership, scenarioStatus, profilerArtifacts, ...
            optionalArtifactIssues);
        return;
    end
    localDBLog("INFO", ...
        "Sealing immutable raw execution identity before report finalization.");
    executionLink = sixgr.util.structGet(result, "Link", struct());
    rawEvidenceSnapshot = struct();
    rawTrialContainer = sixgr.util.structGet(executionLink, "RawTrials", []);
    if isstruct(executionLink) && isscalar(executionLink) && ...
            isstruct(rawTrialContainer) && isscalar(rawTrialContainer) && ...
            ~isempty(fieldnames(rawTrialContainer))
        rawEvidenceSnapshot = sixgr.runtime.snapshotRawExecutionEvidence( ...
            runFolder, executionLink, struct( ...
            "RunID", executionIdentity.RunID, ...
            "ExecutionID", executionIdentity.ExecutionID, ...
            "ScenarioID", string(scfg.ScenarioID), ...
            "ConfigHash", executionIdentity.ConfigHash));
    end
    rawMetadata = struct( ...
        "RunID", executionIdentity.RunID, ...
        "ExecutionID", executionIdentity.ExecutionID, ...
        "ConfigHash", executionIdentity.ConfigHash, ...
        "ExecutionStartUTC", string(runtimeSummary.StartedUTC), ...
        "ExecutionEndUTC", string(runtimeSummary.CompletedUTC), ...
        "GitCommit", sourceProvenance.Commit, ...
        "GitDirty", logical(sourceProvenance.Dirty), ...
        "PatchBundleContent", string(sixgr.util.structGet( ...
        sourceProvenance, "PatchBundleContent", "")));
    if isstruct(rawEvidenceSnapshot) && ...
            ~isempty(fieldnames(rawEvidenceSnapshot))
        rawMetadata.RawEvidenceIndexRelativePath = ...
            rawEvidenceSnapshot.IndexRelativePath;
        rawMetadata.RawEvidenceIndexSHA256 = rawEvidenceSnapshot.IndexSHA256;
        rawMetadata.RawEvidenceTableCount = rawEvidenceSnapshot.TableCount;
        rawMetadata.RawEvidenceRowCount = rawEvidenceSnapshot.RowCount;
    end
    evidenceLifecycle.RawExecution = ...
        sixgr.runtime.RunEvidenceLifecycle.sealExecution( ...
        runFolder, rawMetadata);
    evidenceFinalizationAttempt = ...
        sixgr.runtime.RunEvidenceLifecycle.beginFinalization( ...
        runFolder, struct("ExecutionID", executionIdentity.ExecutionID));
    evidenceLifecycle.FinalizationAttempt = evidenceFinalizationAttempt;
    localDBLog("INFO", "Exporting initial config-ownership and hardcoding audit artifacts.");
    configOwnership = sixgr.truth.exportLLSConfigOwnershipArtifacts(runFolder, scfg, cfg);
    preTruthScenarioStatus = scenarioStatus;
    scenarioStatus = localApplyRuntimeTruthContract(scenarioStatus, result, scfg, cfg, runFolder);
    result = localApplyScenarioStatus(result, scenarioStatus);
    localDBLog("INFO", "Runtime truth contract evaluated: ok=%d roundtripMismatch=%d evidenceMissing=%d strictFailures=%d", ...
        double(logical(scenarioStatus.RuntimeTruthContractOk)), double(scenarioStatus.RoundtripMismatchCount), ...
        double(scenarioStatus.RequiredRuntimeEvidenceMissingCount), double(scenarioStatus.StrictTruthFailureCount));
    fixedSNRSweepAudit = localRunFixedSNRSweepAuditIfNeeded(runFolder, scfg, cfg);
    preTruthScenarioStatus = localApplyFixedSNRSweepAuditStatus(preTruthScenarioStatus, fixedSNRSweepAudit);
    scenarioStatus = localApplyFixedSNRSweepAuditStatus(scenarioStatus, fixedSNRSweepAudit);
    result = localApplyScenarioStatus(result, scenarioStatus);
    if logical(sixgr.util.structGet(fixedSNRSweepAudit, "Required", false))
        localDBLog("INFO", "Fixed SNR sweep audit evaluated: required=1 ok=%d failures=%d warnings=%d", ...
            double(logical(sixgr.util.structGet(fixedSNRSweepAudit, "Ok", true))), ...
            double(sixgr.util.structGet(fixedSNRSweepAudit, "FailureCount", 0)), ...
            double(sixgr.util.structGet(fixedSNRSweepAudit, "WarningCount", 0)));
    end
    summaryT = localBuildScenarioSummaryTable(scfg, cfg, profile, result, scenarioStatus);
    if logical(scfg.get("output.save_csv"))
        localDBLog("INFO", "Rewriting scenario summary CSV with final truth-gated status.");
        sixgr.util.csvWriteTable(fullfile(layout.ReportCSVDir, "scenario_summary.csv"), summaryT);
    end
    manifest = localBuildManifest(scfg, publicRunFolder, profile, result, runtimeSummary, environmentSummary, scenarioStatus, sourceProvenance);
    localDBLog("INFO", "Rewriting scenario manifest with final truth-gated status.");
    localWriteScenarioManifest(layout, manifest);
    try
        if logical(sixgr.util.structGet(profilerCfg, "Enabled", false)) && ...
                logical(sixgr.util.structGet(profilerState, "OwnsSession", false))
            localDBLog("INFO", "Exporting MATLAB profiler artifacts before implementation validation.");
            profilerArtifacts = localExportProfilerArtifacts(layout, profilerCfg, profilerState, ...
                "Run captured through runner execution before implementation validation.");
            profilerArtifactsExported = true;
            profilerState.OwnsSession = false;
        end
    catch profilerME
        optionalArtifactIssues(end+1, 1) = "profiler_export_before_validation:" + string(profilerME.identifier);
        localDBLog("WARN", "Profiler export before implementation validation did not complete: %s | %s", ...
            char(string(profilerME.identifier)), char(string(profilerME.message)));
        localStopProfilerSession(profilerState);
        profilerState.OwnsSession = false;
        profilerArtifacts = struct();
    end
    localDBLog("INFO", "Evaluating YAML-selected independent FRC reference qualification.");
    referenceQualification = localRunIndependentReferenceQualification( ...
        runFolder, scfg, cfg);
    localDBLog("INFO", ...
        "Independent FRC qualification: enabled=%d profile=%s passed=%d artifact=%s", ...
        double(logical(sixgr.util.structGet(referenceQualification, "Enabled", false))), ...
        char(string(sixgr.util.structGet(referenceQualification, "Profile", "disabled"))), ...
        double(logical(sixgr.util.structGet(referenceQualification, "AllPassed", false))), ...
        char(string(sixgr.util.structGet(referenceQualification, "OutputPath", ""))));
    phase7ExecutionEnabled = logical(localRunnerScenarioGetBool(scfg, cfg, ...
        "validation.phase7_execution_validation.enabled", false));
    if phase7ExecutionEnabled
        localDBLog("INFO", [ ...
            "Executing actual fixed-link checkpoint/resume and FRC " ...
            "serial/parallel equivalence validation."]);
    else
        localDBLog("INFO", [ ...
            "Writing fail-closed NOT_EVALUATED receipts for disabled " ...
            "checkpoint/resume and serial/parallel validation."]);
    end
    phase7ExecutionEvidence = ...
        sixgr.validation.runPhase7ExecutionEvidence(cfg, runFolder, ...
        "WriteArtifacts", true);
    localDBLog("INFO", ...
        "Phase-7 execution equivalence: enabled=%d checkpoint=%d determinism=%d.", ...
        double(phase7ExecutionEnabled), ...
        double(logical(sixgr.util.structGet(phase7ExecutionEvidence, ...
        "CheckpointResumeEquivalenceOk", false))), ...
        double(logical(sixgr.util.structGet(phase7ExecutionEvidence, ...
        "SerialParallelDeterminismOk", false))));
    % Rebuild every derived live/KPI projection from the just-sealed primary
    % DL/UL trial tables before any report or browser-contract reduction.
    % Recovery already uses this exact persisted-truth path; invoking it in
    % normal completion prevents the online runtime writers and recovery
    % writers from leaving different schemas for the same canonical files.
    % No waveform is replayed and missing directions remain missing.
    requiresPrimaryLinkTrials = localRequiresSealedPrimaryLinkTrials(profile);
    if requiresPrimaryLinkTrials || ...
            (isstruct(rawEvidenceSnapshot) && ~isempty(fieldnames(rawEvidenceSnapshot)))
        localDBLog("INFO", ...
            "Canonicalizing derived runtime evidence from sealed primary trial rows.");
        runtimeEvidenceRefinalization = ...
            sixgr.truth.refinalizePersistedLLSRuntimeEvidence(cfg, runFolder, ...
            "RunTag", runTag, "RefreshBrowserContract", false);
        if requiresPrimaryLinkTrials && ...
                ~logical(sixgr.util.structGet(runtimeEvidenceRefinalization, ...
                "RawEvidencePresent", false))
            error("sixgr:lls6g:runner:MissingSealedPrimaryTrialEvidence", ...
                "Runner profile '%s' requires persisted primary DL or UL trial evidence.", ...
                profile);
        end
    else
        % Control/reference-signal profiles own their measured waveform
        % artifacts and must not be rejected for lacking unrelated PDSCH or
        % PUSCH transport-block rows.  This is an explicit N/A result, not a
        % synthetic primary-link replacement.
        runtimeEvidenceRefinalization = struct( ...
            "Applicable", false, ...
            "RawEvidencePresent", false, ...
            "Profile", string(profile), ...
            "Reason", "runner_profile_does_not_claim_primary_dl_ul_trials", ...
            "ProxyUsed", false, ...
            "FallbackUsed", false);
        localDBLog("INFO", ...
            "Primary DL/UL trial refinalization is not applicable to runner profile=%s.", ...
            char(profile));
    end

    % The reporting bundle evaluates required runtime wiring evidence. The
    % identity-bound ledger must exist before that reduction, not only
    % before the later output-coverage pass.
    sixgr.runtime.RuntimeCallLedger.flush();
    localDBLog("INFO", "Exporting LLS reporting bundle.");
    reportBundle = sixgr.truth.exportLLSReportingBundle(runFolder, scfg, cfg, result, manifest, runtimeSummary, scenarioStatus);
    reportBundle.RuntimeEvidenceRefinalization = runtimeEvidenceRefinalization;
    reportBundle.ConfigOwnershipArtifacts = configOwnership;
    reportBundle.FixedSNRSweepAudit = fixedSNRSweepAudit;
    reportBundle.ReferenceQualification = referenceQualification;
    reportBundle.Phase7ExecutionEvidence = phase7ExecutionEvidence;
    localDBLog("INFO", "Scanning truth primary artifacts for active proxy/fallback markers.");
    truthArtifactScan = sixgr.truth.scanTruthArtifacts(runFolder, struct());
    reportBundle.TruthArtifactScan = truthArtifactScan;
    localDBLog("INFO", "Registering fresh in-memory waveform evidence with the contract publisher.");
    runtimeArtifactIdentity = struct( ...
        "RunID", executionIdentity.RunID, ...
        "ExecutionID", executionIdentity.ExecutionID, ...
        "ConfigHash", executionIdentity.ConfigHash);
    artifactEvidenceCoverage = sixgr.artifact.registerWaveformLinkEvidence( ...
        artifactEvidence, result, scfg, cfg, runtimeArtifactIdentity);
    localDBLog("INFO", "Registering fresh in-memory initial-access evidence with the contract publisher.");
    initialAccessEvidenceCoverage = sixgr.artifact.registerInitialAccessEvidence( ...
        artifactEvidence, result, scfg, cfg, runtimeArtifactIdentity);
    artifactEvidenceCoverage = [artifactEvidenceCoverage; initialAccessEvidenceCoverage];
    reportBundle.ArtifactEvidenceCoverage = artifactEvidenceCoverage;
    localDBLog("INFO", "Finalizing YAML-selected runtime-only artifact contracts.");
    artifactContractResult = sixgr.artifact.finalizeRunFailClosed( ...
        runFolder, artifactEvidence, scfg, runtimeArtifactIdentity);
    reportBundle.ArtifactContract = artifactContractResult;
    if logical(sixgr.util.structGet(artifactContractResult, "Executed", false))
        localDBLog("INFO", ...
            "Artifact contract finalization: status=%s contracts=%d failures=%d requiredFailures=%d.", ...
            char(string(sixgr.util.structGet(artifactContractResult, "Status", "NOT_EVALUATED"))), ...
            double(sixgr.util.structGet(artifactContractResult, "ContractCount", 0)), ...
            double(sixgr.util.structGet(artifactContractResult, "FailureCount", 0)), ...
            double(sixgr.util.structGet(artifactContractResult, "RequiredFailureCount", 0)));
    end
    % ISAC images are rendered during the coupled PHY execution, before the
    % global CSV provenance annotator runs.  Rebind their lineage only after
    % all source-table annotations and artifact-contract sanitization are
    % complete so the strict visual audit compares stable final bytes.
    sixgr.lls.refreshISACPlotLineage(runFolder, cfg);
    localDBLog("INFO", "Binding YAML causal-chain declarations to exact runtime calls and measured artifacts.");
    sixgr.runtime.RuntimeCallLedger.flush();
    causalPHYChainAudit = sixgr.truth.exportCausalPHYChainAudit( ...
        runFolder, scfg, cfg, "RunId", string(runTag));
    reportBundle.CausalPHYChainAudit = causalPHYChainAudit;
    localDBLog("INFO", "Exporting output-coverage and honest-unavailable artifacts.");
    % The output-coverage exporter also evaluates the Top-50 visual source
    % inventory.  The causal audit must therefore exist before this call;
    % otherwise the inventory is permanently stale and falsely reports the
    % end-to-end chain-status source as missing even though the same run
    % writes it a few statements later.
    outputCoverage = sixgr.truth.exportLLSOutputCoverageArtifacts(runFolder, scfg, cfg);
    reportBundle.OutputCoverageArtifacts = outputCoverage;
    reportBundle.Inventory = sixgr.util.structGet(outputCoverage, "UpdatedArtifactInventory", sixgr.util.structGet(reportBundle, "Inventory", table()));
    localDBLog("INFO", "Refreshing config-ownership artifacts after final runtime/report exports.");
    configOwnership = sixgr.truth.exportLLSConfigOwnershipArtifacts(runFolder, scfg, cfg);
    reportBundle.ConfigOwnershipArtifacts = configOwnership;
    geometryScenarioAudit = localRunGeometryScenarioAuditIfNeeded(runFolder, scfg, cfg);
    geometryScenarioPlots = localRunGeometryScenarioPlotsIfNeeded(runFolder, geometryScenarioAudit, scfg, cfg);
    reportBundle.GeometryScenarioAudit = geometryScenarioAudit;
    reportBundle.GeometryScenarioPlots = geometryScenarioPlots;
    if logical(sixgr.util.structGet(geometryScenarioAudit, "Required", false))
        localDBLog("INFO", "Geometry scenario audit evaluated: required=1 ok=%d failures=%d warnings=%d", ...
            double(logical(sixgr.util.structGet(geometryScenarioAudit, "Ok", true))), ...
            double(sixgr.util.structGet(geometryScenarioAudit, "FailureCount", 0)), ...
            double(sixgr.util.structGet(geometryScenarioAudit, "WarningCount", 0)));
    end
    % Browser chart production consumes the canonical coverage tables above.
    % Every raster is paired with its exact generated chart-dataset CSV.
    localDBLog("INFO", "Materializing strict browser contract artifacts before final visual and terminal status reduction.");
    contractMaterialization = localMaterializeBrowserContractArtifacts(runFolder);
    % Root status uses the logical run tag as RunId; retain the database
    % primary key separately so the receipt cannot conflate the two IDs.
    contractMaterialization.RunID = string(runTag);
    contractMaterialization.GeneratedAtUTC = string(sixgr.util.structGet( ...
        runtimeSummary, "CompletedUTC", ""));
    browserReceipt = sixgr.artifact.writeBrowserPublicationReceipt( ...
        runFolder, contractMaterialization);
    reportBundle.BrowserContractMaterialization = contractMaterialization;
    reportBundle.BrowserPublicationReceipt = browserReceipt;
    if logical(sixgr.util.structGet(contractMaterialization, "Ok", false))
        localDBLog("INFO", "Browser contract artifacts materialized: created=%d missingTables=%d missingCharts=%d", ...
            double(sixgr.util.structGet(contractMaterialization, "CreatedCount", 0)), ...
            double(sixgr.util.structGet(contractMaterialization, "MissingTableCount", 0)), ...
            double(sixgr.util.structGet(contractMaterialization, "MissingChartCount", 0)));
    else
        optionalArtifactIssues(end+1, 1) = "browser_contract_materialization:" + ...
            string(sixgr.util.structGet(contractMaterialization, "Identifier", "failed"));
        localDBLog("WARN", "Browser contract artifact materialization did not complete: %s | %s", ...
            char(string(sixgr.util.structGet(contractMaterialization, "Identifier", "failed"))), ...
            char(string(sixgr.util.structGet(contractMaterialization, "Message", ""))));
    end
    % Fixed-sweep plot lineage is owned by the CSV contract materializer.
    % Re-evaluate its audit only after that authority has rendered and
    % hash-bound the figures; carrying the pre-render audit forward creates
    % a false required-output failure and a circular finalization result.
    fixedSNRSweepAudit = localRunFixedSNRSweepAuditIfNeeded(runFolder, scfg, cfg);
    reportBundle.FixedSNRSweepAudit = fixedSNRSweepAudit;
    localDBLog("INFO", "Auditing the exact post-materialization raster tree.");
    finalVisualAudit = sixgr.visual.finalizeRunVisualAudit(runFolder);
    outputCoverage.VisualArtifactIntegrity = finalVisualAudit.Integrity;
    outputCoverage.VisualArtifactAudit = finalVisualAudit.Audit;
    reportBundle.OutputCoverageArtifacts = outputCoverage;
    scenarioStatus = localApplyRuntimeTruthContract(preTruthScenarioStatus, result, scfg, cfg, runFolder);
    scenarioStatus = localApplyCausalPHYChainAuditStatus(scenarioStatus, causalPHYChainAudit);
    scenarioStatus = localApplyVisualArtifactIntegrityStatus(scenarioStatus, ...
        sixgr.util.structGet(outputCoverage, "VisualArtifactIntegrity", table()));
    scenarioStatus = localApplyFixedSNRSweepAuditStatus(scenarioStatus, fixedSNRSweepAudit);
    scenarioStatus = localApplyGeometryScenarioAuditStatus(scenarioStatus, geometryScenarioAudit);
    scenarioStatus = sixgr.artifact.applyFinalizationGate( ...
        scenarioStatus, artifactContractResult);
    sixgr.artifact.updateRootStatusArtifacts(runFolder, scenarioStatus);
    result = localApplyScenarioStatus(result, scenarioStatus);
    localDBLog("INFO", "Runtime truth contract re-evaluated after final artifact exports: ok=%d roundtripMismatch=%d evidenceMissing=%d strictFailures=%d", ...
        double(logical(scenarioStatus.RuntimeTruthContractOk)), double(scenarioStatus.RoundtripMismatchCount), ...
        double(scenarioStatus.RequiredRuntimeEvidenceMissingCount), double(scenarioStatus.StrictTruthFailureCount));
    localAppendLinkRunStatusLog(layout, scenarioStatus);
    summaryT = localBuildScenarioSummaryTable(scfg, cfg, profile, result, scenarioStatus);
    if logical(scfg.get("output.save_csv"))
        localDBLog("INFO", "Rewriting scenario summary CSV with final artifact truth-gated status.");
        sixgr.util.csvWriteTable(fullfile(layout.ReportCSVDir, "scenario_summary.csv"), summaryT);
    end
    manifest = localBuildManifest(scfg, publicRunFolder, profile, result, runtimeSummary, environmentSummary, scenarioStatus, sourceProvenance);
    localDBLog("INFO", "Rewriting scenario manifest with final artifact truth-gated status.");
    localWriteScenarioManifest(layout, manifest);
    truthGatedCompletionPublished = true;
    localDBLog("INFO", "Writing artifact manifest.");
    manifest.ArtifactManifestPath = char(localWriteArtifactManifest(runFolder, scfg, profile, manifest, reportBundle, scenarioStatus));
    localWriteScenarioManifest(layout, manifest);
    localDBLog("INFO", "Writing scenario markdown report.");
    localWriteMarkdownReport(fullfile(layout.ReportDir, "scenario_report.md"), scfg, cfg, profile, runFolder, result, manifest, reportBundle, scenarioStatus);
    componentViewsEnabled = logical(scfg.get( ...
        "output.component_artifact_views.enabled", false));
    componentViewsRequired = logical(scfg.get( ...
        "output.component_artifact_views.required", false));
    componentViewsRequiredComponents = string(scfg.get( ...
        "output.component_artifact_views.required_components", strings(0, 1)));
    localDBLog("INFO", ...
        "Publishing component artifact views: enabled=%d required=%d.", ...
        double(componentViewsEnabled), double(componentViewsRequired));
    componentViews = sixgr.truth.publishComponentArtifactViews(runFolder, ...
        "Enabled", componentViewsEnabled, ...
        "Required", componentViewsRequired, ...
        "RequiredComponents", componentViewsRequiredComponents(:));
    reportBundle.ComponentArtifactViews = componentViews;
    if componentViewsEnabled
        localDBLog("INFO", ...
            "Component artifact views published: files=%d componentsWithoutEvidence=%d skippedLegacySVG=%d manifest=%s", ...
            double(componentViews.PublishedCount), ...
            double(componentViews.MissingComponentCount), ...
            double(componentViews.SkippedLegacySVGCount), ...
            char(string(componentViews.ManifestPath)));
        localDBLog("INFO", ...
            "Refreshing artifact manifest after component view publication.");
        manifest.ArtifactManifestPath = char(localWriteArtifactManifest( ...
            runFolder, scfg, profile, manifest, reportBundle, scenarioStatus));
        localWriteScenarioManifest(layout, manifest);
    end
    % Component images are byte-identical mirrors. Audit them transitively
    % through their hash-verified canonical lineage before publishing the
    % required terminal status.
    finalVisualAudit = sixgr.visual.finalizeRunVisualAudit(runFolder);
    outputCoverage.VisualArtifactIntegrity = finalVisualAudit.Integrity;
    outputCoverage.VisualArtifactAudit = finalVisualAudit.Audit;
    reportBundle.OutputCoverageArtifacts = outputCoverage;
    scenarioStatus = localApplyRuntimeTruthContract( ...
        preTruthScenarioStatus, result, scfg, cfg, runFolder);
    scenarioStatus = localApplyCausalPHYChainAuditStatus( ...
        scenarioStatus, causalPHYChainAudit);
    scenarioStatus = localApplyVisualArtifactIntegrityStatus( ...
        scenarioStatus, finalVisualAudit.Integrity);
    scenarioStatus = localApplyFixedSNRSweepAuditStatus( ...
        scenarioStatus, fixedSNRSweepAudit);
    scenarioStatus = localApplyGeometryScenarioAuditStatus( ...
        scenarioStatus, geometryScenarioAudit);
    scenarioStatus = sixgr.artifact.applyFinalizationGate( ...
        scenarioStatus, artifactContractResult);
    artifactAudit = localRunArtifactAuditIfNeeded(runFolder, scfg, cfg);
    reportBundle.ArtifactAudit = artifactAudit;
    scenarioStatus = localApplyArtifactAuditStatus(scenarioStatus, artifactAudit);
    finalQualificationEvidence = localRefreshFinalQualificationEvidence( ...
        runFolder, scfg, cfg);
    reportBundle.FinalQualificationEvidence = finalQualificationEvidence;
    % The terminal Phase-7 reducer rewrites its canonical CSV/JSON files.
    % Republish component mirrors immediately so every declared mirror hash
    % still binds to the exact canonical bytes consumed by the production
    % qualification reducer.  Do not defer this until after root status:
    % that leaves a stale validation mirror in otherwise successful runs.
    if componentViewsEnabled
        componentViews = sixgr.truth.publishComponentArtifactViews(runFolder, ...
            "Enabled", true, ...
            "Required", componentViewsRequired, ...
            "RequiredComponents", componentViewsRequiredComponents(:));
        reportBundle.ComponentArtifactViews = componentViews;
    end
    scenarioStatus = sixgr.truth.applyProductionQualificationGate( ...
        scenarioStatus, runFolder);
    sixgr.artifact.updateRootStatusArtifacts(runFolder, scenarioStatus);
    result = localApplyScenarioStatus(result, scenarioStatus);
    if logical(sixgr.util.structGet(artifactAudit, "Required", false))
        localDBLog("INFO", "Recursive artifact audit evaluated: required=1 ok=%d failures=%d warnings=%d", ...
            double(logical(sixgr.util.structGet(artifactAudit, "Ok", true))), ...
            double(sixgr.util.structGet(artifactAudit, "FailureCount", 0)), ...
            double(sixgr.util.structGet(artifactAudit, "WarningCount", 0)));
        localAppendLinkRunStatusLog(layout, scenarioStatus);
        summaryT = localBuildScenarioSummaryTable(scfg, cfg, profile, result, scenarioStatus);
        if logical(scfg.get("output.save_csv"))
            localDBLog("INFO", "Rewriting scenario summary CSV with final artifact-audit status.");
            sixgr.util.csvWriteTable(fullfile(layout.ReportCSVDir, "scenario_summary.csv"), summaryT);
        end
        manifest = localBuildManifest(scfg, publicRunFolder, profile, result, runtimeSummary, environmentSummary, scenarioStatus, sourceProvenance);
        localDBLog("INFO", "Rewriting scenario manifest with final artifact-audit status.");
        localWriteScenarioManifest(layout, manifest);
        localDBLog("INFO", "Refreshing artifact manifest after recursive artifact audit.");
        manifest.ArtifactManifestPath = char(localWriteArtifactManifest(runFolder, scfg, profile, manifest, reportBundle, scenarioStatus));
        localWriteScenarioManifest(layout, manifest);
        localDBLog("INFO", "Rewriting scenario markdown report after recursive artifact audit.");
        localWriteMarkdownReport(fullfile(layout.ReportDir, "scenario_report.md"), scfg, cfg, profile, runFolder, result, manifest, reportBundle, scenarioStatus);
    end
    localDBLog("INFO", "Required final artifacts published; marking terminal run status before optional artifacts.");
    localMarkRunStatusSafe(string(scenarioStatus.RunCompletion), ...
        localBuildTerminalStatusPayload(scenarioStatus, "run_required_artifacts_published", optionalArtifactIssues));
    if logical(scfg.get("output.save_mat"))
        try
            localDBLog("INFO", "Writing MAT result bundle.");
            localMarkRunStatusSafe(string(scenarioStatus.RunCompletion), ...
                localBuildTerminalStatusPayload(scenarioStatus, "run_optional_mat_bundle", optionalArtifactIssues));
            sixgr.util.matSave(fullfile(layout.ReportMATDir, "scenario_result.mat"), ...
                struct("ScenarioConfig", scfg.toStruct(), "Result", result, "Manifest", manifest, ...
                "RuntimeSummary", runtimeSummary, "EnvironmentSummary", environmentSummary, "ReportBundle", reportBundle, ...
                "ScenarioStatus", scenarioStatus));
        catch matME
            optionalArtifactIssues(end+1, 1) = "mat_result_bundle:" + string(matME.identifier);
            localDBLog("WARN", "Optional MAT result bundle did not complete: %s | %s", ...
                char(string(matME.identifier)), char(string(matME.message)));
        end
    end
    try
        localDBLog("INFO", "Pruning empty result directories.");
        localPruneEmptyDirs(runFolder);
    catch pruneME
        optionalArtifactIssues(end+1, 1) = "prune_empty_directories:" + string(pruneME.identifier);
        localDBLog("WARN", "Optional empty-directory prune did not complete: %s | %s", ...
            char(string(pruneME.identifier)), char(string(pruneME.message)));
    end
    if ~profilerArtifactsExported
        try
            profilerArtifacts = localExportProfilerArtifacts(layout, profilerCfg, profilerState, "Run completed successfully.");
            profilerArtifactsExported = true;
            profilerState.OwnsSession = false;
        catch profilerME
            optionalArtifactIssues(end+1, 1) = "profiler_export:" + string(profilerME.identifier);
            localDBLog("WARN", "Optional profiler export did not complete: %s | %s", ...
                char(string(profilerME.identifier)), char(string(profilerME.message)));
            localStopProfilerSession(profilerState);
            profilerState.OwnsSession = false;
            profilerArtifacts = struct();
        end
    end
    if componentViewsEnabled
        localDBLog("INFO", ...
            "Finalizing component artifact views after all canonical report and profiler writes.");
        componentViews = sixgr.truth.publishComponentArtifactViews(runFolder, ...
            "Enabled", true, ...
            "Required", componentViewsRequired, ...
            "RequiredComponents", componentViewsRequiredComponents(:));
        reportBundle.ComponentArtifactViews = componentViews;
        manifest.ArtifactManifestPath = char(localWriteArtifactManifest( ...
            runFolder, scfg, profile, manifest, reportBundle, scenarioStatus));
        localWriteScenarioManifest(layout, manifest);
    end
    % The final component publication can add raster mirrors after the
    % earlier visual audit.  Re-audit the exact terminal raster tree, then
    % refresh component mirrors once more so the newly written audit tables
    % are hash-identical to their canonical sources.  The second publication
    % does not create new scientific plots; it only replaces declared
    % byte-identical mirrors at the same paths.
    localDBLog("INFO", ...
        "Running terminal visual/status reduction after optional and component artifact writes.");
    finalVisualAudit = sixgr.visual.finalizeRunVisualAudit(runFolder);
    outputCoverage.VisualArtifactIntegrity = finalVisualAudit.Integrity;
    outputCoverage.VisualArtifactAudit = finalVisualAudit.Audit;
    reportBundle.OutputCoverageArtifacts = outputCoverage;
    if componentViewsEnabled
        componentViews = sixgr.truth.publishComponentArtifactViews(runFolder, ...
            "Enabled", true, ...
            "Required", componentViewsRequired, ...
            "RequiredComponents", componentViewsRequiredComponents(:));
        reportBundle.ComponentArtifactViews = componentViews;
    end
    scenarioStatus = localApplyRuntimeTruthContract( ...
        preTruthScenarioStatus, result, scfg, cfg, runFolder);
    scenarioStatus = localApplyCausalPHYChainAuditStatus( ...
        scenarioStatus, causalPHYChainAudit);
    scenarioStatus = localApplyVisualArtifactIntegrityStatus( ...
        scenarioStatus, finalVisualAudit.Integrity);
    scenarioStatus = localApplyFixedSNRSweepAuditStatus( ...
        scenarioStatus, fixedSNRSweepAudit);
    scenarioStatus = localApplyGeometryScenarioAuditStatus( ...
        scenarioStatus, geometryScenarioAudit);
    scenarioStatus = sixgr.artifact.applyFinalizationGate( ...
        scenarioStatus, artifactContractResult);
    % The first browser materialization deliberately precedes the truth
    % evaluator because artifact completeness is one of the truth gates.
    % That means direct contract aliases such as
    % analytics/csv/truth_policy_analytics.csv initially contain the
    % pre-materialization verdict. Rebuild the browser-owned tables and
    % charts now, from the just-written terminal truth summary, before the
    % final recursive filesystem audit and Phase-7 reducers consume them.
    % This is a deterministic derived-view refresh only; primary waveform
    % evidence is never regenerated, filled, or relabelled.
    localDBLog("INFO", ...
        "Refreshing browser truth/status mirrors from the terminal truth verdict.");
    browserPublicationRequired = logical(sixgr.util.structGet( ...
        scenarioStatus, "BrowserPublicationRequired", false));
    visualClosureRequired = logical(sixgr.util.structGet( ...
        scenarioStatus, "VisualArtifactGateRequired", false));
    terminalContractRefresh = sixgr.artifact.materializeBrowserContractArtifacts( ...
        runFolder, "Force", true, ...
        "ReplaceExistingRastersFromCSV", false);
    reportBundle.TerminalBrowserContractRefresh = terminalContractRefresh;
    if ~logical(sixgr.util.structGet(terminalContractRefresh, "Ok", false))
        refreshIdentifier = char(string(sixgr.util.structGet( ...
            terminalContractRefresh, "Identifier", "unknown")));
        refreshMessage = char(string(sixgr.util.structGet( ...
            terminalContractRefresh, "Message", "")));
        refreshFailureMessage = sprintf([ ...
            'Terminal browser contract refresh failed after the final ' ...
            'truth verdict: %s | %s'], refreshIdentifier, refreshMessage);
        if browserPublicationRequired
            % Pass the rendered message as data. A traceback or Windows path
            % can contain percent/backslash tokens and must never be
            % reinterpreted as an error() format string, which would mask the
            % original terminal materialization failure.
            error("sixgr:lls6g:TerminalContractRefreshFailed", "%s", ...
                refreshFailureMessage);
        end
        % Browser publication is outside this run's mandatory claim. Retain
        % the exact failure as an optional artifact issue without converting
        % a completed, truth-gated waveform execution into a failed run.
        optionalArtifactIssues(end+1, 1) = ...
            "terminal_browser_contract_refresh:" + string(refreshIdentifier);
        localDBLog("WARN", "%s Browser publication is not required; " + ...
            "continuing terminal LLS reduction.", refreshFailureMessage);
    end
    artifactAudit = localRunArtifactAuditIfNeeded(runFolder, scfg, cfg);
    reportBundle.ArtifactAudit = artifactAudit;
    scenarioStatus = localApplyArtifactAuditStatus(scenarioStatus, artifactAudit);
    finalQualificationEvidence = localRefreshFinalQualificationEvidence( ...
        runFolder, scfg, cfg);
    reportBundle.FinalQualificationEvidence = finalQualificationEvidence;
    % This is the final scientific-evidence refresh.  It must be followed by
    % a final byte-identical component publication before any root status is
    % reduced from those files.  Otherwise phase7_truth_gates.{csv,json}
    % change after their mirror hashes were sealed.
    if componentViewsEnabled
        componentViews = sixgr.truth.publishComponentArtifactViews(runFolder, ...
            "Enabled", true, ...
            "Required", componentViewsRequired, ...
            "RequiredComponents", componentViewsRequiredComponents(:));
        reportBundle.ComponentArtifactViews = componentViews;
    end
    scenarioStatus = sixgr.truth.applyProductionQualificationGate( ...
        scenarioStatus, runFolder);
    sixgr.artifact.updateRootStatusArtifacts(runFolder, scenarioStatus);
    result = localApplyScenarioStatus(result, scenarioStatus);
    localAppendLinkRunStatusLog(layout, scenarioStatus);
    summaryT = localBuildScenarioSummaryTable(scfg, cfg, profile, result, scenarioStatus);
    if logical(scfg.get("output.save_csv"))
        sixgr.util.csvWriteTable(fullfile(layout.ReportCSVDir, ...
            "scenario_summary.csv"), summaryT);
    end
    manifest = localBuildManifest(scfg, publicRunFolder, profile, result, ...
        runtimeSummary, environmentSummary, scenarioStatus, sourceProvenance);
    manifest.ArtifactManifestPath = char(localWriteArtifactManifest( ...
        runFolder, scfg, profile, manifest, reportBundle, scenarioStatus));
    localWriteScenarioManifest(layout, manifest);
    localWriteMarkdownReport(fullfile(layout.ReportDir, ...
        "scenario_report.md"), scfg, cfg, profile, runFolder, result, ...
        manifest, reportBundle, scenarioStatus);
    % The root status/summary above are themselves browser-chart sources.
    % Seal terminal artifacts as a fixed point so normal TDD and FDD runs
    % cannot finish with chart hashes describing an earlier status tree.
    terminalGeneratedAt = string(localUTCStamp());
    terminalPreviousSignature = "";
    terminalArtifactConverged = false;
    for terminalArtifactPass = 1:3
        if componentViewsEnabled
            componentViews = sixgr.truth.publishComponentArtifactViews(runFolder, ...
                "Enabled", true, ...
                "Required", componentViewsRequired, ...
                "RequiredComponents", componentViewsRequiredComponents(:));
            reportBundle.ComponentArtifactViews = componentViews;
        end
        terminalClosure = sixgr.artifact.sealBrowserArtifactClosure( ...
            string(runFolder), "RunID", string(runTag), ...
            "GeneratedAtUTC", terminalGeneratedAt, ...
            "MaxPasses", 1 + 2*double(browserPublicationRequired || ...
                visualClosureRequired), ...
            "Required", browserPublicationRequired || visualClosureRequired);
        reportBundle.TerminalArtifactClosure = terminalClosure;
        outputCoverage.VisualArtifactIntegrity = ...
            terminalClosure.VisualAudit.Integrity;
        outputCoverage.VisualArtifactAudit = terminalClosure.VisualAudit.Audit;
        reportBundle.OutputCoverageArtifacts = outputCoverage;

        scenarioStatus = localApplyRuntimeTruthContract( ...
            preTruthScenarioStatus, result, scfg, cfg, runFolder);
        scenarioStatus = localApplyCausalPHYChainAuditStatus( ...
            scenarioStatus, causalPHYChainAudit);
        scenarioStatus = localApplyVisualArtifactIntegrityStatus( ...
            scenarioStatus, terminalClosure.VisualAudit.Integrity);
        scenarioStatus = localApplyFixedSNRSweepAuditStatus( ...
            scenarioStatus, fixedSNRSweepAudit);
        scenarioStatus = localApplyGeometryScenarioAuditStatus( ...
            scenarioStatus, geometryScenarioAudit);
        scenarioStatus = sixgr.artifact.applyFinalizationGate( ...
            scenarioStatus, artifactContractResult);
        artifactAudit = localRunArtifactAuditIfNeeded(runFolder, scfg, cfg);
        reportBundle.ArtifactAudit = artifactAudit;
        scenarioStatus = localApplyArtifactAuditStatus( ...
            scenarioStatus, artifactAudit);
        finalQualificationEvidence = localRefreshFinalQualificationEvidence( ...
            runFolder, scfg, cfg);
        reportBundle.FinalQualificationEvidence = finalQualificationEvidence;
        % The closure pass rewrites the canonical Phase-7/publication
        % evidence.  Republish its byte-identical component mirrors before
        % reducing root qualification; otherwise the sealed browser tree
        % can describe the preceding closure pass rather than these exact
        % scientific-evidence bytes.
        if componentViewsEnabled
            componentViews = sixgr.truth.publishComponentArtifactViews(runFolder, ...
                "Enabled", true, ...
                "Required", componentViewsRequired, ...
                "RequiredComponents", componentViewsRequiredComponents(:));
            reportBundle.ComponentArtifactViews = componentViews;
        end
        scenarioStatus = sixgr.truth.applyProductionQualificationGate( ...
            scenarioStatus, runFolder);
        sixgr.artifact.updateRootStatusArtifacts(runFolder, scenarioStatus);
        result = localApplyScenarioStatus(result, scenarioStatus);
        summaryT = localBuildScenarioSummaryTable( ...
            scfg, cfg, profile, result, scenarioStatus);
        if logical(scfg.get("output.save_csv"))
            sixgr.util.csvWriteTable(fullfile(layout.ReportCSVDir, ...
                "scenario_summary.csv"), summaryT);
        end
        manifest = localBuildManifest(scfg, publicRunFolder, profile, ...
            result, runtimeSummary, environmentSummary, scenarioStatus, ...
            sourceProvenance);
        manifest.ArtifactManifestPath = char(localWriteArtifactManifest( ...
            runFolder, scfg, profile, manifest, reportBundle, scenarioStatus));
        localWriteScenarioManifest(layout, manifest);
        localWriteMarkdownReport(fullfile(layout.ReportDir, ...
            "scenario_report.md"), scfg, cfg, profile, runFolder, result, ...
            manifest, reportBundle, scenarioStatus);

        terminalSignature = localTerminalArtifactStatusSignature( ...
            scenarioStatus);
        terminalLineageClosure = ...
            sixgr.artifact.verifyContractPlotLineageSources( ...
                string(runFolder));
        if terminalArtifactPass >= 2 && ...
                terminalSignature == terminalPreviousSignature && ...
                logical(terminalLineageClosure.Ok) && ...
                logical(sixgr.util.structGet(scenarioStatus, ...
                    "VisualArtifactGateOk", false))
            terminalArtifactConverged = true;
            break;
        end
        terminalPreviousSignature = terminalSignature;
    end
    if ~terminalArtifactConverged
        error("sixgr:lls6g:TerminalArtifactFixedPointFailed", "%s", ...
            ["Terminal status and exact plot-source hashes did not " ...
            "converge within three publication passes."]);
    end
    truthGatedCompletionPublished = true;
    hydration = localHydratePublicRunFolderIfNeeded(runFolder, publicRunFolder);
    hydrationNotes = string(sixgr.util.structGet(hydration, "Notes", ""));
    if hydrationNotes == "artifact_store_inactive_or_same_folder"
        % Filesystem runs already write directly to the public folder.
    elseif logical(sixgr.util.structGet(hydration, "Ok", true))
        localDBLog("INFO", "Public run folder hydrated from DB artifacts: files=%d bytes=%d skipped=%d target=%s", ...
            double(sixgr.util.structGet(hydration, "FileCount", 0)), ...
            double(sixgr.util.structGet(hydration, "ByteCount", 0)), ...
            double(sixgr.util.structGet(hydration, "SkippedCount", 0)), ...
            char(string(sixgr.util.structGet(hydration, "TargetRoot", publicRunFolder))));
    else
        optionalArtifactIssues(end+1, 1) = "public_run_folder_hydration:" + string(sixgr.util.structGet(hydration, "Notes", "failed"));
        localDBLog("WARN", "Public run folder hydration did not complete: %s", ...
            char(string(sixgr.util.structGet(hydration, "Notes", ""))));
    end

    localMarkRunStatusSafe(string(scenarioStatus.RunCompletion), ...
        localBuildTerminalStatusPayload(scenarioStatus, "run_terminal_optional_artifacts_complete", optionalArtifactIssues));
    evidenceLifecycle = localCompleteEvidenceFinalization( ...
        evidenceLifecycle, evidenceFinalizationAttempt, runFolder, ...
        manifest, scenarioStatus, artifactContractResult);
    reportBundle.EvidenceLifecycle = evidenceLifecycle;
    if logical(scenarioStatus.ResultOk)
        localDBLog("INFO", "Run completed successfully in %.3f seconds.", toc(runTimer));
    else
        localDBLog("WARN", "Run completed with truth/status failures in %.3f seconds: requiredFailures=%d strictTruthFailures=%d", ...
            toc(runTimer), double(scenarioStatus.RequiredFailureCount), double(scenarioStatus.StrictTruthFailureCount));
    end

    execOut = localBuildExecOut(profile, result, manifest, runtimeSummary, environmentSummary, ...
        reportBundle, configOwnership, scenarioStatus, profilerArtifacts, optionalArtifactIssues);
catch ME
    localDBLog("ERROR", "Run failed: %s | %s", char(string(ME.identifier)), char(string(ME.message)));
    if isstruct(evidenceFinalizationAttempt) && ...
            ~isempty(fieldnames(evidenceFinalizationAttempt))
        try
            evidenceLifecycle.Terminal = ...
                sixgr.runtime.RunEvidenceLifecycle.failFinalization( ...
                evidenceFinalizationAttempt, ME);
        catch lifecycleME
            localDBLog("WARN", ...
                "Finalization-attempt failure receipt could not be written: %s | %s", ...
                char(string(lifecycleME.identifier)), ...
                char(string(lifecycleME.message)));
        end
    end
    try
        if logical(sixgr.util.structGet(cfg, "perf.exportTimeProfile", false))
            sixgr.perf.TimeProfiler.export(runFolder, cfg);
        end
    catch timeProfileME
        localDBLog("WARN", "Time-profile export after failure did not complete: %s", ...
            char(string(timeProfileME.message)));
    end
    try
        localExportProfilerArtifacts(layout, profilerCfg, profilerState, ...
            "Run failed before completion; partial MATLAB profiler capture exported.");
    catch profilerME
        localDBLog("WARN", "Profiler export after failure did not complete: %s", ...
            char(string(profilerME.message)));
        localStopProfilerSession(profilerState);
    end
    try
        sixgr.runtime.RuntimeCallLedger.flush();
        causalPHYChainAudit = sixgr.truth.exportCausalPHYChainAudit( ...
            runFolder, scfg, cfg, "RunId", string(runTag));
        localDBLog("INFO", ...
            "Partial causal PHY-chain audit exported after failure: ok=%d failures=%d.", ...
            double(logical(sixgr.util.structGet(causalPHYChainAudit, "Ok", false))), ...
            double(sixgr.util.structGet(causalPHYChainAudit, "FailureCount", 0)));
    catch causalAuditME
        localDBLog("WARN", ...
            "Partial causal PHY-chain audit after failure did not complete: %s | %s", ...
            char(string(causalAuditME.identifier)), ...
            char(string(causalAuditME.message)));
    end
    try
        liveFailureStage = localReadCurrentRuntimeStage(layout);
        sixgr.runtime.writeFailureHistoryArtifact(layout.MetaDir, ME, ...
            "Stage", liveFailureStage);
    catch
    end
    if truthGatedCompletionPublished && ...
            sixgr.lls6g.runners.shouldPreserveCompletedRunOnPostRunFailure(scenarioStatus)
        lateIssue = "late_postrun_exception:" + string(ME.identifier);
        combinedIssues = [optionalArtifactIssues(:); lateIssue];
        localDBLog("WARN", ...
            "Late post-run failure occurred after truthful completion; preserving completed run and skipping failed-run recovery: %s | %s", ...
            char(string(ME.identifier)), char(string(ME.message)));
        payload = localBuildTerminalStatusPayload(scenarioStatus, ...
            "postrun_optional_failure_after_completed_truth", combinedIssues);
        payload.postrun_optional_failure = true;
        payload.postrun_optional_failure_identifier = string(ME.identifier);
        payload.postrun_optional_failure_message = string(ME.message);
        payload.postrun_optional_failure_recovery_skipped = true;
        localMarkRunStatusSafe(string(scenarioStatus.RunCompletion), payload);
        execOut = localBuildExecOut(profile, result, manifest, runtimeSummary, environmentSummary, ...
            reportBundle, configOwnership, scenarioStatus, profilerArtifacts, combinedIssues);
        return;
    end
    % Publish the truthful terminal failure before potentially expensive
    % recovery/materialization. This prevents the WebGUI stale-run
    % reconciler from misclassifying a finished MATLAB process as aborted
    % while recovery is still rebuilding derived artifacts.
    localMarkRunStatusSafe("failed", struct( ...
        "stage", "run_failed_recovery_pending", ...
        "identifier", string(ME.identifier), ...
        "message", string(ME.message), ...
        "recovery_pending", true, ...
        "timestamp_utc", string(localUTCStamp())));
    try
        localDBLog("INFO", "Recovering truthful report artifacts from persisted raw evidence after failure.");
        recovery = sixgr.truth.recoverLLSRunArtifacts(runFolder, scfg.toStruct(), ...
            "RunTag", runTag, ...
            "PublicRunFolder", publicRunFolder, ...
            "StatusText", "failed", ...
            "ErrorIdentifier", string(ME.identifier), ...
            "ErrorMessage", string(ME.message), ...
            "SourceFiles", string(scfg.SourceFiles(:)), ...
            "ConfigPath", string(scfg.ConfigPath), ...
            "ConfigHash", string(scfg.ConfigHash));
        sixgr.truth.exportLLSConfigOwnershipArtifacts(runFolder, scfg, cfg);
        localDBLog("INFO", "Recovered failed-run artifacts: scenario=%s profile=%s truthOk=%d", ...
            char(string(sixgr.util.structGet(recovery, "ScenarioID", scfg.ScenarioID))), ...
            char(string(sixgr.util.structGet(recovery, "RunnerProfile", ""))), ...
            double(logical(sixgr.util.structGet(recovery, "ScenarioStatus.RuntimeTruthContractOk", false))));
        contractMaterialization = localMaterializeBrowserContractArtifacts(runFolder);
        if logical(sixgr.util.structGet(contractMaterialization, "Ok", false))
            localDBLog("INFO", "Browser contract artifacts materialized after failure recovery: created=%d missingTables=%d missingCharts=%d", ...
                double(sixgr.util.structGet(contractMaterialization, "CreatedCount", 0)), ...
                double(sixgr.util.structGet(contractMaterialization, "MissingTableCount", NaN)), ...
                double(sixgr.util.structGet(contractMaterialization, "MissingChartCount", NaN)));
        else
            localDBLog("WARN", "Browser contract materialization after failure recovery did not complete: %s | %s", ...
                char(string(sixgr.util.structGet(contractMaterialization, "Identifier", ""))), ...
                char(string(sixgr.util.structGet(contractMaterialization, "Message", ""))));
        end
        localHydratePublicRunFolderIfNeeded(runFolder, publicRunFolder);
    catch recoveryME
        localDBLog("WARN", "Failed-run artifact recovery did not complete: %s | %s", ...
            char(string(recoveryME.identifier)), char(string(recoveryME.message)));
    end
    localMarkRunStatusSafe("failed", struct( ...
        "stage", "run_failed", ...
        "identifier", string(ME.identifier), ...
        "message", string(ME.message), ...
        "timestamp_utc", string(localUTCStamp())));
    try
        localPruneEmptyDirs(runFolder);
    catch
    end
    rethrow(ME);
end
end

function lifecycle = localCompleteEvidenceFinalization(lifecycle, attempt, ...
        runFolder, manifest, scenarioStatus, artifactContractResult)
if ~(isstruct(attempt) && isscalar(attempt) && ...
        ~isempty(fieldnames(attempt)))
    error("sixgr:runtime:FinalizationAttemptMissing", ...
        "Publication reduction requires an active finalization attempt.");
end
canonicalRelativePath = string(sixgr.util.structGet( ...
    manifest, "ArtifactManifestPath", ""));
canonicalPath = fullfile(runFolder, char(canonicalRelativePath));
if strlength(canonicalRelativePath) == 0 || ~isfile(canonicalPath)
    error("sixgr:runtime:CanonicalArtifactManifestMissing", ...
        "Canonical artifact manifest is missing from finalization: %s", ...
        canonicalPath);
end
fid = fopen(canonicalPath, "rb");
if fid < 0
    error("sixgr:runtime:CanonicalArtifactManifestUnreadable", ...
        "Cannot read canonical artifact manifest: %s", canonicalPath);
end
fileCleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
canonicalHash = sixgr.util.sha256Hex(fread(fid, Inf, "*uint8"));
clear fileCleanup;

% A functionally completed run may still fail numerical, independent
% reference, statistical, browser or terminal publication gates.  Advancing
% published/current.json on ResultOk alone contradicts the canonical
% production gate.  Only the post-finalization publication verdict may
% publish an attempt.
qualified = logical(sixgr.util.structGet( ...
    scenarioStatus, "PublicationQualified", false));
attemptManifest = struct( ...
    "SchemaName", "sixgr.finalized_artifact_manifest", ...
    "SchemaVersion", "1.0.0", ...
    "RunID", string(attempt.RunID), ...
    "ExecutionID", string(attempt.ExecutionID), ...
    "FinalizationID", string(attempt.FinalizationID), ...
    "AttemptID", string(attempt.AttemptID), ...
    "CanonicalArtifactManifestRelativePath", ...
    replace(canonicalRelativePath, "\", "/"), ...
    "CanonicalArtifactManifestSHA256", canonicalHash, ...
    "RunCompletion", string(sixgr.util.structGet( ...
    scenarioStatus, "RunCompletion", "")), ...
    "ResultOk", logical(sixgr.util.structGet( ...
        scenarioStatus, "ResultOk", false)), ...
    "ArtifactContractStatus", string(sixgr.util.structGet( ...
    artifactContractResult, "Status", "NOT_EVALUATED")), ...
    "ArtifactContractRequiredFailureCount", double(sixgr.util.structGet( ...
    artifactContractResult, "RequiredFailureCount", 0)), ...
    "PublicationQualified", qualified, ...
    "GeneratedUTC", string(localUTCStamp()));
attemptManifestPath = fullfile(attempt.OutputsRoot, "artifact_manifest.json");
sixgr.util.jsonWrite(attemptManifestPath, attemptManifest);
lifecycle.AttemptArtifactManifestPath = string(attemptManifestPath);
lifecycle.AttemptArtifactManifest = attemptManifest;
if qualified
    lifecycle.Terminal = sixgr.runtime.RunEvidenceLifecycle.publish( ...
        attempt, attemptManifestPath);
    lifecycle.Published = true;
elseif attemptManifest.ResultOk && attemptManifest.ArtifactContractStatus == "PASS" && ...
        attemptManifest.ArtifactContractRequiredFailureCount == 0
    lifecycle.Terminal = sixgr.runtime.RunEvidenceLifecycle.completeUnpublished( ...
        attempt, attemptManifestPath);
    lifecycle.Published = false;
else
    failure = struct( ...
        "Identifier", "sixgr:runtime:FunctionalFinalizationFailed", ...
        "Message", "Functional result or required artifact contract failed; published/current.json was not advanced.", ...
        "Stack", strings(0, 1));
    lifecycle.Terminal = ...
        sixgr.runtime.RunEvidenceLifecycle.failFinalization( ...
        attempt, failure);
    lifecycle.Published = false;
end
end

function execOut = localBuildExecOut(profile, result, manifest, runtimeSummary, environmentSummary, ...
    reportBundle, configOwnership, scenarioStatus, profilerArtifacts, optionalArtifactIssues)
execOut = struct();
execOut.Ok = logical(sixgr.util.structGet(scenarioStatus, "ResultOk", sixgr.util.structGet(result, "Ok", false)));
execOut.Result = result;
execOut.Profile = string(profile);
execOut.Manifest = manifest;
execOut.RuntimeSummary = runtimeSummary;
execOut.EnvironmentSummary = environmentSummary;
execOut.ReportBundle = reportBundle;
execOut.ConfigOwnershipArtifacts = configOwnership;
execOut.ScenarioStatus = scenarioStatus;
execOut.ProfilerArtifacts = profilerArtifacts;
execOut.OptionalArtifactIssues = optionalArtifactIssues;
end

function profilerCfg = localResolveProfilerConfig(scfg)
enabled = logical(scfg.get("output.profiler_enabled", false)) || ...
    logical(scfg.get("run_control.time_profiling_enable", false)) || ...
    logical(scfg.get("analytics.export_time_profile", false));
profilerCfg = struct( ...
    "Enabled", enabled, ...
    "TopFunctions", max(1, round(double(scfg.get("output.profiler_top_functions", 160)))), ...
    "TopEdges", max(1, round(double(scfg.get("output.profiler_top_edges", 320)))));
end

function tf = localIsSmokePublicationRun(scfg)
studyMode = lower(strtrim(string(scfg.get("scenario.study_mode", ""))));
publicationMode = lower(strtrim(string(scfg.get("output.publication_mode", ""))));
tf = any(studyMode == ["smoke", "runner_smoke"]) || ...
    any(publicationMode == ["smoke", "minimal", "runner_smoke"]);
end

function cfg = localForceSerialSmokeExecution(cfg)
cfg = sixgr.util.structSet(cfg, "run.useParallel", false);
cfg = sixgr.util.structSet(cfg, "run.numWorkers", 1);
cfg = sixgr.util.structSet(cfg, "run.parallelRequestedWorkers", 1);
cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", "smoke_publication_serial_execution");
end

function status = localApplySmokePublicationStatus(status)
profileOk = logical(sixgr.util.structGet(status, "ProfileReportedOk", status.ResultOk));
caseOk = logical(sixgr.util.structGet(status, "CaseOk", profileOk));
requiredFailures = double(sixgr.util.structGet(status, "RequiredFailureCount", double(~caseOk)));
status.ResultOk = profileOk && caseOk && requiredFailures == 0;
status.CaseOk = caseOk;
status.PartialOk = false;
status.RunCompletion = "completed";
status.RunCompleted = true;
status.StatusAuthority = "runner_smoke_publication_v1";
status.AuthoritativeStatusSource = "runner_profile_result_smoke";
status.RuntimeTruthContractOk = false;
status.TruthContractOk = false;
status.StandardsConformanceOk = false;
status.ScenarioObjectiveOk = status.ResultOk;
status.ResultStatusReason = "runner_smoke_profile_completed_release_truth_contract_not_evaluated";
status.StatusNotes = localJoinStatusNotes(status.StatusNotes, ...
    "Smoke publication mode writes runner profile artifacts only; release truth contract, browser contract materialization, and full reporting bundle are not evaluated for this run.");
status.RequiredRuntimeEvidenceMissingCount = 0;
status.StrictTruthFailureCount = 0;
status.StrictProxyGuardFailureCount = 0;
status.CanonicalArtifactGapCount = 0;
status.RuntimeTruthContractFailures = strings(0, 1);
status.FailingCaseCount = double(numel(string(status.RequiredFailedCases(:))));
if ~status.ResultOk && status.FailingCaseCount == 0
    status.FailingCaseCount = 1;
end
end

function profilerState = localStartProfilerIfEnabled(profilerCfg)
profilerState = sixgr.lls6g.runners.acquireMATLABProfilerSession( ...
    logical(sixgr.util.structGet(profilerCfg, "Enabled", false)));
if profilerState.OwnsSession
    localDBLog("INFO", "MATLAB profiler enabled for this run.");
end
end

function tf = localRequiresSealedPrimaryLinkTrials(profile)
% Only profiles that claim a data-link waveform/system truth product must
% persist primary DL or UL transport-block trials.  Control-channel,
% PRACH, reference-signal, RF, and AI profiles have their own primary
% evidence contracts and are not allowed to fabricate data-link rows.
tf = ismember(lower(strtrim(string(profile))), [ ...
    "waveform_bundle", ...
    "system_level_lls", ...
    "pdsch6gr_truth_study"]);
end

function profilerArtifacts = localExportProfilerArtifacts(layout, profilerCfg, profilerState, statusNote)
profilerArtifacts = struct( ...
    "SummaryTable", table(), ...
    "FunctionTable", table(), ...
    "EdgeTable", table());
if nargin < 4
    statusNote = "";
end
if ~logical(sixgr.util.structGet(profilerCfg, "Enabled", false)) || ...
        ~logical(sixgr.util.structGet(profilerState, "OwnsSession", false))
    localStopProfilerSession(profilerState);
    return;
end

info = localStopAndCollectProfilerInfo();
summaryT = localBuildProfilerSummaryTable(info, profilerCfg, statusNote);
funcT = localBuildProfilerFunctionTable(info, profilerCfg);
edgeT = localBuildProfilerEdgeTable(info, profilerCfg);

localDBLog("INFO", "Writing MATLAB profiler CSV artifacts: functions=%d edges=%d", ...
    double(height(funcT)), double(height(edgeT)));
sixgr.util.csvWriteTable(fullfile(layout.ReportCSVDir, "runtime_profiler_summary.csv"), summaryT);
sixgr.util.csvWriteTable(fullfile(layout.ReportCSVDir, "runtime_function_profile.csv"), funcT);
sixgr.util.csvWriteTable(fullfile(layout.ReportCSVDir, "runtime_function_call_edges.csv"), edgeT);

profilerArtifacts.SummaryTable = summaryT;
profilerArtifacts.FunctionTable = funcT;
profilerArtifacts.EdgeTable = edgeT;
end

function info = localStopAndCollectProfilerInfo()
try
    profile off;
catch
end
try
    info = profile("info");
catch
    info = struct();
end
try
    profile clear;
catch
end
end

function localStopProfilerSession(profilerState)
if ~logical(sixgr.util.structGet(profilerState, "OwnsSession", false))
    return;
end
try
    profile off;
catch
end
try
    profile clear;
catch
end
end

function T = localBuildProfilerSummaryTable(info, profilerCfg, statusNote)
ft = localProfileGetField(info, "FunctionTable", struct([]));
functionCount = double(numel(ft));
edgeCount = 0;
for i = 1:numel(ft)
    edgeCount = edgeCount + numel(localProfileGetField(ft(i), "Children", struct([])));
end
T = table( ...
    string(localProfileGetField(info, "Name", "MATLAB profile")), ...
    double(localProfileGetField(info, "ClockPrecision", NaN)), ...
    double(localProfileGetField(info, "ClockSpeed", NaN)), ...
    double(localProfileGetField(info, "Overhead", NaN)), ...
    functionCount, ...
    min(functionCount, double(sixgr.util.structGet(profilerCfg, "TopFunctions", functionCount))), ...
    double(edgeCount), ...
    min(double(edgeCount), double(sixgr.util.structGet(profilerCfg, "TopEdges", edgeCount))), ...
    string(localUTCStamp()), ...
    string(statusNote), ...
    'VariableNames', { ...
        'ProfilerName', ...
        'ClockPrecision_s', ...
        'ClockSpeed_Hz', ...
        'Overhead_s', ...
        'FunctionCount', ...
        'ExportedFunctionCount', ...
        'EdgeCount', ...
        'ExportedEdgeCount', ...
        'CapturedUTC', ...
        'Notes'});
end

function T = localBuildProfilerFunctionTable(info, profilerCfg)
ft = localProfileGetField(info, "FunctionTable", struct([]));
if isempty(ft)
    T = table('Size', [0 13], ...
        'VariableTypes', {'double','double','string','string','string','string','double','double','double','double','double','double','logical'}, ...
        'VariableNames', {'ProfileRank','FunctionIndex','FunctionName','CompleteName','FileName','FunctionType','NumCalls','TotalTime_s','SelfTimeApprox_s','ChildTime_s','TotalRecursiveTime_s','ParentCount','IsRecursive'});
    return;
end

rows = repmat(struct( ...
    "FunctionIndex", NaN, ...
    "FunctionName", "", ...
    "CompleteName", "", ...
    "FileName", "", ...
    "FunctionType", "", ...
    "NumCalls", NaN, ...
    "TotalTime_s", NaN, ...
    "SelfTimeApprox_s", NaN, ...
    "ChildTime_s", NaN, ...
    "TotalRecursiveTime_s", NaN, ...
    "ParentCount", NaN, ...
    "ChildCount", NaN, ...
    "IsRecursive", false), numel(ft), 1);
for i = 1:numel(ft)
    childTime = localProfileChildTime(localProfileGetField(ft(i), "Children", struct([])));
    totalTime = double(localProfileGetField(ft(i), "TotalTime", NaN));
    rows(i) = struct( ...
        "FunctionIndex", double(i), ...
        "FunctionName", string(localProfileGetField(ft(i), "FunctionName", "")), ...
        "CompleteName", string(localProfileGetField(ft(i), "CompleteName", "")), ...
        "FileName", string(localProfileGetField(ft(i), "FileName", "")), ...
        "FunctionType", string(localProfileGetField(ft(i), "Type", "")), ...
        "NumCalls", double(localProfileGetField(ft(i), "NumCalls", NaN)), ...
        "TotalTime_s", totalTime, ...
        "SelfTimeApprox_s", max(totalTime - childTime, 0), ...
        "ChildTime_s", childTime, ...
        "TotalRecursiveTime_s", double(localProfileGetField(ft(i), "TotalRecursiveTime", NaN)), ...
        "ParentCount", double(numel(localProfileGetField(ft(i), "Parents", struct([])))), ...
        "ChildCount", double(numel(localProfileGetField(ft(i), "Children", struct([])))), ...
        "IsRecursive", logical(localProfileGetField(ft(i), "IsRecursive", false)));
    if strlength(strtrim(rows(i).FunctionName)) == 0
        rows(i).FunctionName = localProfileFallbackName(rows(i).CompleteName, rows(i).FileName);
    end
end

T = struct2table(rows);
T = sortrows(T, {'TotalTime_s', 'SelfTimeApprox_s', 'NumCalls'}, {'descend', 'descend', 'descend'});
limitRows = min(height(T), double(sixgr.util.structGet(profilerCfg, "TopFunctions", height(T))));
T = T(1:limitRows, :);
T = addvars(T, transpose((1:height(T))), 'Before', 1, 'NewVariableNames', 'ProfileRank');
end

function T = localBuildProfilerEdgeTable(info, profilerCfg)
ft = localProfileGetField(info, "FunctionTable", struct([]));
rows = repmat(struct( ...
    "CallerFunctionIndex", NaN, ...
    "CallerFunctionName", "", ...
    "CallerCompleteName", "", ...
    "CalleeFunctionIndex", NaN, ...
    "CalleeFunctionName", "", ...
    "CalleeCompleteName", "", ...
    "NumCalls", NaN, ...
    "TotalTime_s", NaN), 0, 1);
for i = 1:numel(ft)
    callerName = string(localProfileGetField(ft(i), "FunctionName", ""));
    callerComplete = string(localProfileGetField(ft(i), "CompleteName", ""));
    if strlength(strtrim(callerName)) == 0
        callerName = localProfileFallbackName(callerComplete, string(localProfileGetField(ft(i), "FileName", "")));
    end
    children = localProfileGetField(ft(i), "Children", struct([]));
    for k = 1:numel(children)
        childIndex = round(double(localProfileGetField(children(k), "Index", NaN)));
        if ~(isfinite(childIndex) && childIndex >= 1 && childIndex <= numel(ft))
            continue;
        end
        calleeName = string(localProfileGetField(ft(childIndex), "FunctionName", ""));
        calleeComplete = string(localProfileGetField(ft(childIndex), "CompleteName", ""));
        if strlength(strtrim(calleeName)) == 0
            calleeName = localProfileFallbackName(calleeComplete, string(localProfileGetField(ft(childIndex), "FileName", "")));
        end
        rows(end+1,1) = struct( ... %#ok<AGROW>
            "CallerFunctionIndex", double(i), ...
            "CallerFunctionName", callerName, ...
            "CallerCompleteName", callerComplete, ...
            "CalleeFunctionIndex", double(childIndex), ...
            "CalleeFunctionName", calleeName, ...
            "CalleeCompleteName", calleeComplete, ...
            "NumCalls", double(localProfileGetField(children(k), "NumCalls", NaN)), ...
            "TotalTime_s", double(localProfileGetField(children(k), "TotalTime", NaN)));
    end
end

if isempty(rows)
    T = table('Size', [0 9], ...
        'VariableTypes', {'double','double','string','string','double','string','string','double','double'}, ...
        'VariableNames', {'EdgeRank','CallerFunctionIndex','CallerFunctionName','CallerCompleteName','CalleeFunctionIndex','CalleeFunctionName','CalleeCompleteName','NumCalls','TotalTime_s'});
    return;
end

T = struct2table(rows);
T = sortrows(T, {'TotalTime_s', 'NumCalls'}, {'descend', 'descend'});
limitRows = min(height(T), double(sixgr.util.structGet(profilerCfg, "TopEdges", height(T))));
T = T(1:limitRows, :);
T = addvars(T, transpose((1:height(T))), 'Before', 1, 'NewVariableNames', 'EdgeRank');
end

function value = localProfileGetField(s, fieldName, defaultValue)
value = defaultValue;
if builtin("isstruct", s) && isfield(s, fieldName)
    value = s.(fieldName);
end
end

function childTime = localProfileChildTime(children)
childTime = 0;
if ~(builtin("isstruct", children) && ~isempty(children) && isfield(children, "TotalTime"))
    return;
end
childTime = sum(double([children.TotalTime]), "omitnan");
end

function name = localProfileFallbackName(completeName, fileName)
name = string(completeName);
if strlength(strtrim(name)) == 0
    name = string(fileName);
end
if contains(name, filesep)
    [~, stem, ext] = fileparts(char(name));
    name = string(stem + ext);
end
end

function localWriteResolvedSnapshots(layout, scfg)
metaDir = layout.MetaDir;
% The resolved snapshot is immutable executable input.  Report-only
% reductions must not be added to it because recovery validates this file
% with the same strict schema used before execution.
resolvedStruct = scfg.toStruct();
runtimeViewStruct = localResolvedSnapshotStruct(scfg);
jsonPath = fullfile(metaDir, "scenario_config_resolved.json");
yamlPath = fullfile(metaDir, "scenario_config_resolved.yaml");
runtimeViewJSONPath = fullfile(metaDir, "scenario_runtime_view.json");
runtimeViewYAMLPath = fullfile(metaDir, "scenario_runtime_view.yaml");
if logical(scfg.get("output.save_json_snapshot"))
    sixgr.util.jsonWrite(jsonPath, resolvedStruct);
    sixgr.util.jsonWrite(runtimeViewJSONPath, runtimeViewStruct);
end
if logical(scfg.get("output.save_yaml_snapshot"))
    sixgr.lls6g.config.writeYAML(yamlPath, resolvedStruct);
    sixgr.lls6g.config.writeYAML(runtimeViewYAMLPath, runtimeViewStruct);
end
srcFiles = arrayfun(@(p)localPortablePath(p), string(scfg.SourceFiles(:)));
srcT = table(srcFiles, 'VariableNames', {'SourceConfigFile'});
sixgr.util.csvWriteTable(fullfile(metaDir, "scenario_source_chain.csv"), srcT);
if exist(jsonPath, "file") == 2
    identity = struct( ...
        "SchemaVersion", "sixgr_resolved_config_identity/v1", ...
        "ScenarioID", string(scfg.ScenarioID), ...
        "ConfigHash", string(scfg.ConfigHash), ...
        "ResolvedJSONSHA256", localFileSHA256ForSnapshot(jsonPath), ...
        "ResolvedYAMLSHA256", "", ...
        "RuntimeViewJSONSHA256", "", ...
        "RuntimeViewYAMLSHA256", "", ...
        "GeneratedUTC", string(sixgr.util.utcNowISO8601()));
    if exist(yamlPath, "file") == 2
        identity.ResolvedYAMLSHA256 = localFileSHA256ForSnapshot(yamlPath);
    end
    if exist(runtimeViewJSONPath, "file") == 2
        identity.RuntimeViewJSONSHA256 = ...
            localFileSHA256ForSnapshot(runtimeViewJSONPath);
    end
    if exist(runtimeViewYAMLPath, "file") == 2
        identity.RuntimeViewYAMLSHA256 = ...
            localFileSHA256ForSnapshot(runtimeViewYAMLPath);
    end
    sixgr.util.jsonWrite(fullfile(metaDir, "scenario_config_identity.json"), identity);
end
end

function hash = localFileSHA256ForSnapshot(path)
fid = fopen(path, "r");
if fid < 0
    error("sixgr:lls6g:runner:ResolvedSnapshotUnreadable", ...
        "Cannot read resolved configuration snapshot %s.", path);
end
cleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
hash = string(sixgr.util.sha256Hex(fread(fid, Inf, "*uint8")));
end

function kind = localResolveScenarioSourceKind(scfg)
resolved = scfg.toStruct();
kind = string(sixgr.util.structGet(resolved, "SourceKind", ""));
if strlength(strtrim(kind)) == 0
    kind = string(sixgr.util.structGet(resolved, "meta.SourceKind", ""));
end
if strlength(strtrim(kind)) == 0
    kind = string(sixgr.util.structGet(resolved, "config_inheritance.provenance.source_kind", ""));
end
if strlength(strtrim(kind)) == 0
    kind = "scenario_config_file";
end
end

function tf = localShouldWriteCSV(scfg)
tf = logical(scfg.get("output.save_csv"));
end

function manifest = localBuildManifest(scfg, runFolder, profile, result, runtimeSummary, environmentSummary, scenarioStatus, gitInfo)
includeGitHash = logical(scfg.get("logging.include_git_hash"));
[codeVersion, codeDetail] = localDetectCodeVersion(includeGitHash);
[configOverlay, configOverlayPath] = localDetectConfigOverlay(scfg);
manifest = struct();
manifest.GeneratedUTC = localUTCStamp();
manifest.ScenarioID = char(string(scfg.ScenarioID));
manifest.ConfigHash = char(string(scfg.ConfigHash));
manifest.ConfigPath = char(string(scfg.ConfigPath));
manifest.ScenarioYAML = char(string(scfg.ConfigPath));
manifest.ConfigOverlay = char(string(configOverlay));
manifest.ConfigOverlayPath = char(string(configOverlayPath));
manifest.RunFolder = char(string(runFolder));
manifest.RunID = char(string(sixgr.util.structGet(runtimeSummary, "RunID", "")));
manifest.ExecutionID = char(string(sixgr.util.structGet(runtimeSummary, "ExecutionID", "")));
manifest.SourceFiles = cellstr(localPortablePath(scfg.SourceFiles));
manifest.SourceFileCount = numel(scfg.SourceFiles);
manifest.RunnerProfile = char(string(profile));
manifest.RandomSeed = double(scfg.get("simulation.random_seed"));
manifest.DeterministicMode = logical(scfg.get("simulation.deterministic_mode"));
manifest.StrictValidation = logical(scfg.get("logging.strict_validation"));
manifest.LinkDirection = char(string(scfg.get("simulation.link_direction")));
manifest.ConfiguredUsers = double(scfg.get("users.n_users", 1));
manifest.UserExecutionModel = char(string(scfg.get("users.execution_model", "independent_link_sweep")));
manifest.BeamSelectionStrategy = char(string(scfg.get("users.beam_selection_strategy")));
manifest.ConfiguredLayers = double(scfg.get("mimo.n_layers"));
manifest.ConfiguredTxAntennas = double(scfg.get("mimo.n_tx_ant"));
manifest.ConfiguredRxAntennas = double(scfg.get("mimo.n_rx_ant"));
manifest.OutputBucket = char(string(scfg.get("output.bucket")));
manifest.OutputProfile = char(string(scfg.get("output.profile")));
manifest.OutputBackend = char(string(scfg.get("output.backend", "filesystem")));
manifest.OutputDatabaseHost = char(string(scfg.get("output.database_host", "localhost")));
manifest.OutputDatabasePort = double(scfg.get("output.database_port", 3306));
manifest.OutputDatabaseSchema = char(string(scfg.get("output.database_schema", "sixgr_results")));
manifest.SaveCSV = logical(scfg.get("output.save_csv"));
manifest.SaveMAT = logical(scfg.get("output.save_mat"));
manifest.SaveFigures = logical(scfg.get("output.save_figures"));
manifest.SavePNG = logical(scfg.get("output.save_png"));
manifest.SaveJSONSnapshot = logical(scfg.get("output.save_json_snapshot"));
manifest.SaveYAMLSnapshot = logical(scfg.get("output.save_yaml_snapshot"));
manifest.GenerateSummaryPlots = logical(scfg.get("output.generate_summary_plots"));
manifest.UseMex = logical(sixgr.util.structGet(runtimeSummary, "UseMex", false));
manifest.UseMexAutoEnabled = logical(sixgr.util.structGet(runtimeSummary, "UseMexAutoEnabled", false));
manifest.UseParallel = logical(sixgr.util.structGet(runtimeSummary, "UseParallel", false));
manifest.RequestedWorkers = double(sixgr.util.structGet(runtimeSummary, "RequestedWorkers", 0));
manifest.EffectiveWorkers = double(sixgr.util.structGet(runtimeSummary, "EffectiveWorkers", 0));
manifest.ParallelDisabledReason = char(string(sixgr.util.structGet(runtimeSummary, "ParallelDisabledReason", "")));
manifest.MaxNumCompThreads = double(sixgr.util.structGet(runtimeSummary, "MaxNumCompThreads", NaN));
manifest.IncludeGitHash = includeGitHash;
manifest.CodeVersion = char(string(codeVersion));
manifest.CodeDetail = char(string(codeDetail));
manifest.GitCommit = char(string(gitInfo.Commit));
manifest.GitBranch = char(string(gitInfo.Branch));
manifest.GitDirty = logical(gitInfo.Dirty);
manifest.GitStatusSource = char(string(gitInfo.StatusSource));
manifest.MetaManifestPath = "meta/scenario_manifest.json";
manifest.ProvenanceManifestPath = "reports/json/scenario_manifest.json";
manifest.ExecutionStartedUTC = char(string(sixgr.util.structGet(runtimeSummary, "StartedUTC", "")));
manifest.ExecutionCompletedUTC = char(string(sixgr.util.structGet(runtimeSummary, "CompletedUTC", "")));
manifest.ElapsedSeconds = double(sixgr.util.structGet(runtimeSummary, "ElapsedSeconds", NaN));
manifest.WarningCount = double(sixgr.util.structGet(runtimeSummary, "WarningCount", 0));
manifest.EnvironmentSummaryPath = "meta/environment.json";
manifest.RuntimeSummaryPath = "meta/runtime_summary.json";
manifest.HostPlatform = char(string(sixgr.util.structGet(environmentSummary, "Platform", "")));
manifest.RunScope = "6G_PHY_LLS_SINGLE_SCENARIO";
manifest.RunCompletion = char(string(scenarioStatus.RunCompletion));
manifest.RunCompleted = logical(sixgr.util.structGet(scenarioStatus, "RunCompleted", false));
manifest.ResultOk = logical(scenarioStatus.ResultOk);
manifest.PartialOk = logical(scenarioStatus.PartialOk);
manifest.ArtifactsGenerated = logical(scenarioStatus.ArtifactsGenerated);
manifest.ArtifactsWritten = logical(sixgr.util.structGet(scenarioStatus, "ArtifactsWritten", scenarioStatus.ArtifactsGenerated));
manifest.RequiredCaseCount = double(scenarioStatus.RequiredCaseCount);
manifest.RequiredFailureCount = double(scenarioStatus.RequiredFailureCount);
manifest.OptionalPrunedCount = double(scenarioStatus.OptionalPrunedCount);
manifest.RequiredFailedCases = cellstr(string(scenarioStatus.RequiredFailedCases(:)));
manifest.OptionalPrunedCases = cellstr(string(scenarioStatus.OptionalPrunedCases(:)));
manifest.StatusAuthority = char(string(scenarioStatus.StatusAuthority));
manifest.StatusNotes = char(string(scenarioStatus.StatusNotes));
manifest.RuntimeTruthContractOk = logical(scenarioStatus.RuntimeTruthContractOk);
manifest.TruthContractOk = logical(sixgr.util.structGet(scenarioStatus, "TruthContractOk", scenarioStatus.RuntimeTruthContractOk));
manifest.StandardsConformanceOk = logical(sixgr.util.structGet(scenarioStatus, "StandardsConformanceOk", scenarioStatus.RuntimeTruthContractOk));
manifest.ScenarioObjectiveOk = logical(sixgr.util.structGet(scenarioStatus, "ScenarioObjectiveOk", scenarioStatus.ResultOk));
manifest.ConfiguredEffectiveOk = logical(sixgr.util.structGet(scenarioStatus, "ConfiguredEffectiveOk", false));
manifest.ConfiguredEffectivePolicyOk = logical(sixgr.util.structGet( ...
    scenarioStatus, "ConfiguredEffectivePolicyOk", false));
manifest.MandatorySubsystemsOk = logical(sixgr.util.structGet(scenarioStatus, "MandatorySubsystemsOk", false));
manifest.ActiveIssueGateOk = logical(sixgr.util.structGet(scenarioStatus, "ActiveIssueGateOk", false));
manifest.KpiConsistencyOk = logical(sixgr.util.structGet(scenarioStatus, "KpiConsistencyOk", false));
manifest.StrictAnchorEligible = logical(sixgr.util.structGet(scenarioStatus, "StrictAnchorEligible", false));
manifest.StrictAnchorPass = logical(sixgr.util.structGet(scenarioStatus, "StrictAnchorPass", false));
manifest.ResultStatusReason = char(string(sixgr.util.structGet(scenarioStatus, "ResultStatusReason", "")));
manifest.ActiveMandatoryIssueCount = double(sixgr.util.structGet(scenarioStatus, "ActiveMandatoryIssueCount", 0));
manifest.ActiveCriticalIssueCount = double(sixgr.util.structGet(scenarioStatus, "ActiveCriticalIssueCount", 0));
manifest.ActiveHighIssueCount = double(sixgr.util.structGet(scenarioStatus, "ActiveHighIssueCount", 0));
manifest.ActiveMediumIssueCount = double(sixgr.util.structGet(scenarioStatus, "ActiveMediumIssueCount", 0));
manifest.RoundtripMismatchCount = double(scenarioStatus.RoundtripMismatchCount);
manifest.RequiredRuntimeEvidenceMissingCount = double(scenarioStatus.RequiredRuntimeEvidenceMissingCount);
manifest.StrictTruthFailureCount = double(scenarioStatus.StrictTruthFailureCount);
manifest.StrictProxyGuardFailureCount = double(scenarioStatus.StrictProxyGuardFailureCount);
manifest.CanonicalArtifactGapCount = double(scenarioStatus.CanonicalArtifactGapCount);
manifest.RuntimeTruthContractFailures = cellstr(string(scenarioStatus.RuntimeTruthContractFailures(:)));
manifest.VisualArtifactIntegrityOk = logical(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityOk", false));
manifest.VisualArtifactIntegrityFailureCount = double(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityFailureCount", 0));
manifest.VisualArtifactIntegrityFailures = cellstr(string(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityFailures", strings(0, 1))));
manifest.VisualArtifactGateOk = logical(sixgr.util.structGet(scenarioStatus, "VisualArtifactGateOk", false));
manifest.VisualArtifactGateStatus = char(string(sixgr.util.structGet(scenarioStatus, "VisualArtifactGateStatus", "NOT_EVALUATED")));
manifest.DuplicateArtifactGateOk = logical(sixgr.util.structGet(scenarioStatus, "DuplicateArtifactGateOk", false));
manifest.DuplicateArtifactGateStatus = char(string(sixgr.util.structGet(scenarioStatus, "DuplicateArtifactGateStatus", "NOT_EVALUATED")));
manifest.PublicationQualified = logical(sixgr.util.structGet(scenarioStatus, "PublicationQualified", false));
manifest.PublicationQualificationStatus = char(string(sixgr.util.structGet(scenarioStatus, "PublicationQualificationStatus", "NOT_EVALUATED")));
manifest.BrowserPublicationRequired = logical(sixgr.util.structGet(scenarioStatus, "BrowserPublicationRequired", false));
manifest.BrowserPublished = logical(sixgr.util.structGet(scenarioStatus, "BrowserPublished", false));
manifest.BrowserPublicationStatus = char(string(sixgr.util.structGet(scenarioStatus, "BrowserPublicationStatus", "NOT_EVALUATED")));
manifest.BrowserPublicationFailureReason = char(string(sixgr.util.structGet(scenarioStatus, "BrowserPublicationFailureReason", "")));
manifest.ArtifactContractRequired = logical(sixgr.util.structGet(scenarioStatus, "ArtifactContractRequired", false));
manifest.ArtifactContractExecuted = logical(sixgr.util.structGet(scenarioStatus, "ArtifactContractExecuted", false));
manifest.ArtifactContractGateOk = logical(sixgr.util.structGet(scenarioStatus, "ArtifactContractGateOk", true));
manifest.ArtifactContractStatus = char(string(sixgr.util.structGet(scenarioStatus, "ArtifactContractStatus", "NOT_APPLICABLE")));
manifest.ArtifactContractCount = double(sixgr.util.structGet(scenarioStatus, "ArtifactContractCount", 0));
manifest.ArtifactContractFailureCount = double(sixgr.util.structGet(scenarioStatus, "ArtifactContractFailureCount", 0));
manifest.ArtifactContractRequiredFailureCount = double(sixgr.util.structGet(scenarioStatus, "ArtifactContractRequiredFailureCount", 0));
end

function localWriteScenarioManifest(layout, manifest)
sixgr.util.jsonWrite(fullfile(layout.MetaDir, "scenario_manifest.json"), manifest);
reportJsonDir = fullfile(layout.ReportDir, "json");
sixgr.util.ensureFolder(reportJsonDir);
sixgr.util.jsonWrite(fullfile(reportJsonDir, "scenario_manifest.json"), manifest);
end

function gitInfo = localDetectGitProvenance(includeGitHash)
if ~includeGitHash
    gitInfo = struct("Commit", "git_hash_omitted", "Branch", "git_hash_omitted", ...
        "Dirty", false, "StatusSource", "git_hash_omitted_by_config", ...
        "PatchBundleContent", "");
    return;
end
repoRoot = localRepoRoot();
gitInfo = struct("Commit", "unavailable", "Branch", "unavailable", ...
    "Dirty", false, "StatusSource", "git_unavailable", ...
    "PatchBundleContent", "");
[s1, out1] = system(sprintf('git -C "%s" rev-parse HEAD', repoRoot));
if s1 ~= 0
    return;
end
gitInfo.Commit = string(strtrim(out1));
[s2, out2] = system(sprintf('git -C "%s" rev-parse --abbrev-ref HEAD', repoRoot));
if s2 == 0
    gitInfo.Branch = string(strtrim(out2));
end
[s3, out3] = system(sprintf('git -C "%s" status --porcelain', repoRoot));
if s3 == 0
    gitInfo.Dirty = strlength(strtrim(string(out3))) > 0;
    gitInfo.StatusSource = "git_status_porcelain";
    if gitInfo.Dirty
        gitInfo.PatchBundleContent = localCaptureGitPatchBundle( ...
            repoRoot, string(out3));
    end
else
    gitInfo.StatusSource = "git_commit_only";
end
end

function bundle = localCaptureGitPatchBundle(repoRoot, porcelainStatus)
% Capture tracked changes and complete untracked source/config/test files.
% Generated focused audits/logs are evidence outputs, not executable source;
% record their paths and sizes honestly without embedding their often-large
% payloads into raw/source_patch.diff.
[diffStatus, trackedDiff] = system(sprintf( ...
    'git -C "%s" diff --binary --no-ext-diff HEAD -- .', repoRoot));
if diffStatus ~= 0
    error("sixgr:runtime:GitPatchCaptureFailed", ...
        "Unable to capture tracked source changes for execution provenance.");
end
bundle = "SIXGR_EXECUTION_PATCH_BUNDLE_V2" + newline + ...
    "GIT_STATUS_PORCELAIN_BEGIN" + newline + string(porcelainStatus) + ...
    "GIT_STATUS_PORCELAIN_END" + newline + ...
    "TRACKED_GIT_DIFF_BEGIN" + newline + string(trackedDiff) + ...
    "TRACKED_GIT_DIFF_END" + newline;
[listStatus, untrackedText] = system(sprintf( ...
    'git -C "%s" ls-files --others --exclude-standard', repoRoot));
if listStatus ~= 0
    error("sixgr:runtime:GitPatchCaptureFailed", ...
        "Unable to enumerate untracked source files for execution provenance.");
end
paths = splitlines(strtrim(string(untrackedText)));
paths = paths(strlength(strtrim(paths)) > 0);
for index = 1:numel(paths)
    relativePath = strtrim(paths(index));
    absolutePath = fullfile(repoRoot, char(relativePath));
    if ~isfile(absolutePath)
        continue;
    end
    normalizedPath = replace(relativePath, "\", "/");
    normalizedLower = lower(normalizedPath);
    if localIsGeneratedEvidencePath(normalizedLower)
        info = dir(absolutePath);
        byteSize = NaN;
        if ~isempty(info)
            byteSize = double(info(1).bytes);
        end
        bundle = bundle + "UNTRACKED_GENERATED_EVIDENCE_EXCLUDED_BEGIN" + newline + ...
            "Path: " + normalizedPath + newline + ...
            "ByteSize: " + string(byteSize) + newline + ...
            "Reason: generated_evidence_not_source" + newline + ...
            "ReconstructableFromPatchBundle: false" + newline + ...
            "UNTRACKED_GENERATED_EVIDENCE_EXCLUDED_END" + newline;
        continue;
    end
    fid = fopen(absolutePath, "rb");
    if fid < 0
        error("sixgr:runtime:GitPatchCaptureFailed", ...
            "Unable to read untracked source file %s.", relativePath);
    end
    fileCleanup = onCleanup(@() fclose(fid)); %#ok<NASGU>
    bytes = fread(fid, Inf, "*uint8");
    clear fileCleanup;
    encoded = sixgr.runtime.base64EncodeBytes(bytes);
    bundle = bundle + "UNTRACKED_FILE_BEGIN" + newline + ...
        "Path: " + normalizedPath + newline + ...
        "SHA256: " + sixgr.util.sha256Hex(bytes) + newline + ...
        "Encoding: base64" + newline + encoded + newline + ...
        "UNTRACKED_FILE_END" + newline;
end
end

function tf = localIsGeneratedEvidencePath(normalizedLower)
% Generated audit products describe prior executions; they are not source
% inputs and must not be base64-embedded in a dirty-tree source patch.  Keep
% this list narrow so an untracked oracle/configuration file is still
% captured and the run remains reproducible.
generatedPrefixes = [ ...
    "artifacts/focused_audits/", ...
    "artifacts/focused_logs/", ...
    "artifacts/lls_run_audits/"];
tf = any(startsWith(normalizedLower, generatedPrefixes));
end

function [overlay, overlayPath] = localDetectConfigOverlay(scfg)
overlay = "none_detected";
overlayPath = "";
paths = [string(scfg.ConfigPath); string(scfg.SourceFiles(:))];
for i = 1:numel(paths)
    p = paths(i);
    token = lower(p);
    if localIsBrowserOverlayPath(p) || ...
            (strlength(strtrim(p)) > 0 && (contains(token, "overlay") || contains(token, "browser_runtime")))
        overlay = p;
        overlayPath = p;
        return;
    end
end
end

function txt = localUTCStamp()
dt = datetime("now", "TimeZone", "UTC", "Format", "yyyy-MM-dd HH:mm:ss");
txt = char(replace(string(dt), " ", "T") + "Z");
end

function signature = localTerminalArtifactStatusSignature(status)
payload = struct( ...
    "RunCompletion", string(sixgr.util.structGet(status, "RunCompletion", "")), ...
    "ResultOk", logical(sixgr.util.structGet(status, "ResultOk", false)), ...
    "RuntimeTruthContractOk", logical(sixgr.util.structGet(status, "RuntimeTruthContractOk", false)), ...
    "RequiredFailureCount", double(sixgr.util.structGet(status, "RequiredFailureCount", 0)), ...
    "VisualArtifactGateOk", logical(sixgr.util.structGet(status, "VisualArtifactGateOk", false)), ...
    "VisualArtifactFailureCount", double(sixgr.util.structGet(status, "VisualArtifactFailureCount", 0)), ...
    "VisualArtifactFailureReason", string(sixgr.util.structGet(status, "VisualArtifactFailureReason", "")), ...
    "RuntimeTruthContractFailures", string(sixgr.util.structGet(status, "RuntimeTruthContractFailures", strings(0, 1))));
encoded = unicode2native(jsonencode(payload), "UTF-8");
signature = lower(string(sixgr.util.sha256Hex(uint8(encoded))));
end

function localDBLog(levelStr, messageText, varargin)
if nargin >= 3
    try
        messageText = sprintf(messageText, varargin{:});
    catch
    end
end
try
    fprintf(1, "[%s] %s %s\n", localUTCStamp(), upper(char(string(levelStr))), char(string(messageText)));
catch
end
try
    if sixgr.db.isArtifactStoreActive()
        sixgr.db.appendLogLine(string(levelStr), string(localUTCStamp()), string(messageText));
    end
catch
end
end

function localAppendLinkRunStatusLog(layout, scenarioStatus)
failingCaseCount = double(sixgr.util.structGet(scenarioStatus, "FailingCaseCount", 0));
requiredFailureCount = double(sixgr.util.structGet(scenarioStatus, "RequiredFailureCount", 0));
if failingCaseCount <= 0 && requiredFailureCount <= 0
    return;
end
try
    sixgr.util.ensureFolder(layout.AirInterfaceLogDir);
    logPath = fullfile(layout.AirInterfaceLogDir, "run.log");
    fid = fopen(logPath, "a");
    if fid < 0
        return;
    end
    cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
    failures = string(sixgr.util.structGet(scenarioStatus, "RequiredFailedCases", strings(0, 1)));
    failures = failures(strlength(strtrim(failures)) > 0);
    if isempty(failures)
        detail = "no detailed failure code published";
    else
        detail = strjoin(failures(1:min(numel(failures), 6)), "; ");
    end
    fprintf(fid, "[%s] WARN Scenario completed with %g failing case(s); requiredFailures=%g statusAuthority=%s runtimeTruthContractOk=%d details=%s\n", ...
        localUTCStamp(), failingCaseCount, requiredFailureCount, ...
        char(string(sixgr.util.structGet(scenarioStatus, "StatusAuthority", ""))), ...
        double(logical(sixgr.util.structGet(scenarioStatus, "RuntimeTruthContractOk", false))), ...
        char(detail));
catch
end
end

function payload = localBuildTerminalStatusPayload(scenarioStatus, stageName, optionalArtifactIssues)
if nargin < 3
    optionalArtifactIssues = strings(0, 1);
end
payload = struct( ...
    "stage", char(string(stageName)), ...
    "result_ok", logical(scenarioStatus.ResultOk), ...
    "run_completed", logical(sixgr.util.structGet(scenarioStatus, "RunCompleted", false)), ...
    "run_completion", string(scenarioStatus.RunCompletion), ...
    "artifacts_written", logical(sixgr.util.structGet(scenarioStatus, "ArtifactsWritten", scenarioStatus.ArtifactsGenerated)), ...
    "required_failure_count", double(scenarioStatus.RequiredFailureCount), ...
    "failing_case_count", double(scenarioStatus.FailingCaseCount), ...
    "warning_count", double(scenarioStatus.WarningCount), ...
    "status_authority", string(scenarioStatus.StatusAuthority), ...
    "runtime_truth_contract_ok", logical(scenarioStatus.RuntimeTruthContractOk), ...
    "truth_contract_ok", logical(sixgr.util.structGet(scenarioStatus, "TruthContractOk", scenarioStatus.RuntimeTruthContractOk)), ...
    "standards_conformance_ok", logical(sixgr.util.structGet(scenarioStatus, "StandardsConformanceOk", scenarioStatus.RuntimeTruthContractOk)), ...
    "scenario_objective_ok", logical(sixgr.util.structGet(scenarioStatus, "ScenarioObjectiveOk", scenarioStatus.ResultOk)), ...
    "configured_effective_ok", logical(sixgr.util.structGet(scenarioStatus, "ConfiguredEffectiveOk", false)), ...
    "configured_effective_policy_ok", logical(sixgr.util.structGet(scenarioStatus, "ConfiguredEffectivePolicyOk", false)), ...
    "mandatory_subsystems_ok", logical(sixgr.util.structGet(scenarioStatus, "MandatorySubsystemsOk", false)), ...
    "active_issue_gate_ok", logical(sixgr.util.structGet(scenarioStatus, "ActiveIssueGateOk", false)), ...
    "kpi_consistency_ok", logical(sixgr.util.structGet(scenarioStatus, "KpiConsistencyOk", false)), ...
    "strict_anchor_eligible", logical(sixgr.util.structGet(scenarioStatus, "StrictAnchorEligible", false)), ...
    "strict_anchor_pass", logical(sixgr.util.structGet(scenarioStatus, "StrictAnchorPass", false)), ...
    "result_status_reason", string(sixgr.util.structGet(scenarioStatus, "ResultStatusReason", "")), ...
    "active_mandatory_issue_count", double(sixgr.util.structGet(scenarioStatus, "ActiveMandatoryIssueCount", 0)), ...
    "active_critical_issue_count", double(sixgr.util.structGet(scenarioStatus, "ActiveCriticalIssueCount", 0)), ...
    "active_high_issue_count", double(sixgr.util.structGet(scenarioStatus, "ActiveHighIssueCount", 0)), ...
    "active_medium_issue_count", double(sixgr.util.structGet(scenarioStatus, "ActiveMediumIssueCount", 0)), ...
    "roundtrip_mismatch_count", double(scenarioStatus.RoundtripMismatchCount), ...
    "required_runtime_evidence_missing_count", double(scenarioStatus.RequiredRuntimeEvidenceMissingCount), ...
    "strict_truth_failure_count", double(scenarioStatus.StrictTruthFailureCount), ...
    "strict_proxy_guard_failure_count", double(scenarioStatus.StrictProxyGuardFailureCount), ...
    "canonical_artifact_gap_count", double(scenarioStatus.CanonicalArtifactGapCount), ...
    "visual_artifact_integrity_ok", logical(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityOk", false)), ...
    "visual_artifact_integrity_failure_count", double(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityFailureCount", 0)), ...
    "visual_artifact_gate_ok", logical(sixgr.util.structGet(scenarioStatus, "VisualArtifactGateOk", false)), ...
    "visual_artifact_gate_status", string(sixgr.util.structGet(scenarioStatus, "VisualArtifactGateStatus", "NOT_EVALUATED")), ...
    "duplicate_artifact_gate_ok", logical(sixgr.util.structGet(scenarioStatus, "DuplicateArtifactGateOk", false)), ...
    "duplicate_artifact_gate_status", string(sixgr.util.structGet(scenarioStatus, "DuplicateArtifactGateStatus", "NOT_EVALUATED")), ...
    "publication_qualified", logical(sixgr.util.structGet(scenarioStatus, "PublicationQualified", false)), ...
    "publication_qualification_status", string(sixgr.util.structGet(scenarioStatus, "PublicationQualificationStatus", "NOT_EVALUATED")), ...
    "browser_publication_required", logical(sixgr.util.structGet(scenarioStatus, "BrowserPublicationRequired", false)), ...
    "browser_published", logical(sixgr.util.structGet(scenarioStatus, "BrowserPublished", false)), ...
    "browser_publication_status", string(sixgr.util.structGet(scenarioStatus, "BrowserPublicationStatus", "NOT_EVALUATED")), ...
    "artifact_contract_required", logical(sixgr.util.structGet(scenarioStatus, "ArtifactContractRequired", false)), ...
    "artifact_contract_executed", logical(sixgr.util.structGet(scenarioStatus, "ArtifactContractExecuted", false)), ...
    "artifact_contract_gate_ok", logical(sixgr.util.structGet(scenarioStatus, "ArtifactContractGateOk", true)), ...
    "artifact_contract_status", string(sixgr.util.structGet(scenarioStatus, "ArtifactContractStatus", "NOT_APPLICABLE")), ...
    "artifact_contract_failure_count", double(sixgr.util.structGet(scenarioStatus, "ArtifactContractFailureCount", 0)), ...
    "artifact_contract_required_failure_count", double(sixgr.util.structGet(scenarioStatus, "ArtifactContractRequiredFailureCount", 0)), ...
    "error_source", string(scenarioStatus.ErrorSource), ...
    "error_identifier", string(scenarioStatus.ErrorIdentifier), ...
    "error_message", string(scenarioStatus.ErrorMessage), ...
    "optional_artifact_issue_count", double(numel(optionalArtifactIssues)), ...
    "optional_artifact_issues", cellstr(string(optionalArtifactIssues(:))), ...
    "timestamp_utc", string(localUTCStamp()));
end

function localMarkRunStatusSafe(statusText, payload)
if ~sixgr.db.isArtifactStoreActive()
    return;
end
try
    sixgr.db.markRunStatus(string(statusText), payload);
catch ME
    try
        fprintf(1, "[%s] WARN Run status update failed: %s | %s\n", ...
            localUTCStamp(), char(string(ME.identifier)), char(string(ME.message)));
    catch
    end
end
end

function hydration = localHydratePublicRunFolderIfNeeded(stagingRunFolder, publicRunFolder)
hydration = struct("Ok", true, "FileCount", 0, "ByteCount", 0, ...
    "SkippedCount", 0, "TargetRoot", string(publicRunFolder), "Notes", "artifact_store_inactive_or_same_folder");
if ~sixgr.db.isArtifactStoreActive()
    return;
end
stagingRunFolder = string(stagingRunFolder);
publicRunFolder = string(publicRunFolder);
if strlength(strtrim(publicRunFolder)) == 0
    hydration.Ok = false;
    hydration.Notes = "public_run_folder_unavailable";
    return;
end
if localSameFolder(stagingRunFolder, publicRunFolder)
    return;
end
try
    hydration = sixgr.db.hydrateActiveArtifactStore(publicRunFolder);
catch ME
    hydration = struct("Ok", false, "FileCount", 0, "ByteCount", 0, ...
        "SkippedCount", NaN, "TargetRoot", publicRunFolder, ...
        "Notes", string(ME.identifier) + ":" + string(ME.message));
end
end

function tf = localSameFolder(a, b)
a = char(string(a));
b = char(string(b));
if ispc
    tf = strcmpi(strrep(a, "/", "\"), strrep(b, "/", "\"));
else
    tf = strcmp(strrep(a, "\", "/"), strrep(b, "\", "/"));
end
end

function relPath = localWriteArtifactManifest(runFolder, scfg, profile, manifest, reportBundle, scenarioStatus)
storeState = sixgr.db.artifactStore("get_state");
runID = double(sixgr.util.structGet(storeState, "RunID", NaN));
if isfinite(runID) && runID > 0
    runToken = sprintf("%d", round(runID));
else
    runToken = localSanitizeToken(string(scfg.ScenarioID), "scenario");
end
relPath = fullfile("outputs", runToken, "artifact_manifest.json");
inventoryT = sixgr.util.structGet(reportBundle, "Inventory", table());
unavailableRows = sixgr.util.structGet(reportBundle, "OutputCoverageArtifacts.ManifestUnavailableEntries", struct([]));
payload = struct();
payload.GeneratedUTC = localUTCStamp();
payload.RunID = runID;
payload.ScenarioID = char(string(scfg.ScenarioID));
payload.RunnerProfile = char(string(profile));
payload.ConfigHash = char(string(sixgr.util.structGet(manifest, "ConfigHash", "")));
payload.RunCompletion = char(string(sixgr.util.structGet(scenarioStatus, "RunCompletion", "")));
payload.ResultOk = logical(sixgr.util.structGet(scenarioStatus, "ResultOk", false));
payload.ArtifactInventoryCSV = "reports/csv/artifact_inventory.csv";
payload.ArtifactCount = height(inventoryT);
payload.Artifacts = localArtifactManifestRows(inventoryT);
payload.UnavailableArtifacts = unavailableRows;
sixgr.util.jsonWrite(fullfile(runFolder, relPath), payload);
end

function rows = localArtifactManifestRows(T)
rows = repmat(struct( ...
    "RelativePath", "", ...
    "ArtifactClass", "", ...
    "SemanticState", "", ...
    "Bytes", NaN, ...
    "MachineReadable", false, ...
    "HumanReadable", false), 0, 1);
if ~(istable(T) && ~isempty(T))
    return;
end
for i = 1:height(T)
    row = struct();
    row.RelativePath = char(string(localTableValue(T, i, "RelativePath", "")));
    row.ArtifactClass = char(string(localTableValue(T, i, "ArtifactClass", "")));
    row.SemanticState = char(string(localTableValue(T, i, "SemanticState", "")));
    row.Bytes = double(localTableValue(T, i, "Bytes", NaN));
    row.MachineReadable = logical(localTableValue(T, i, "MachineReadable", false));
    row.HumanReadable = logical(localTableValue(T, i, "HumanReadable", false));
    rows(end + 1, 1) = row; %#ok<AGROW>
end
end

function value = localTableValue(T, rowIdx, varName, defaultValue)
value = defaultValue;
if ~(istable(T) && rowIdx >= 1 && rowIdx <= height(T) && ismember(varName, string(T.Properties.VariableNames)))
    return;
end
raw = T.(char(varName))(rowIdx);
if iscell(raw)
    value = raw{1};
else
    value = raw;
end
end

function profileName = localResolveRunRowProfileName(scfg)
profileName = string(scfg.get("scenario.runner_profile", ""));
if strlength(strtrim(profileName)) == 0
    profileName = string(scfg.get("scenario.profile_name", ""));
end
if strlength(strtrim(profileName)) == 0
    profileName = string(scfg.get("deployment_topology.cell_type", ""));
end
if strlength(strtrim(profileName)) == 0
    profileName = string(scfg.ScenarioID);
end
profileName = strtrim(profileName);
end

function profile = localResolveEffectiveRunnerProfile(scfg, cfg, configuredProfile)
profile = lower(strtrim(string(configuredProfile)));
if strlength(profile) == 0
    profile = lower(strtrim(string(scfg.get("scenario.runner_profile", ""))));
end

executionModel = lower(strtrim(string(sixgr.util.structGet(cfg, "lls6g.users.execution_model", ...
    scfg.get("users.execution_model", "")))));
controlRequired = any([ ...
    logical(sixgr.util.structGet(cfg, "run.controlGating.pbchRequired", false)), ...
    logical(sixgr.util.structGet(cfg, "run.controlGating.prachRequired", false)), ...
    logical(sixgr.util.structGet(cfg, "run.controlGating.pdcchRequired", false)), ...
    logical(sixgr.util.structGet(cfg, "run.controlGating.srsRequired", false)), ...
    logical(sixgr.util.structGet(cfg, "run.controlGating.trsRequired", false))]);

if profile == "system_level_lls" && executionModel == "slot_coupled_truth" && controlRequired
    profile = "waveform_bundle";
    localDBLog("INFO", ...
        "Effective runner promoted from system_level_lls to waveform_bundle because users.execution_model=slot_coupled_truth and runtime control/reference gating is required.");
end
end

function targets = localAllocationPreflightTargets(profile, scfg)
% A component runner must resolve the exact REs that it actually executes,
% while a full waveform/system runner remains responsible for every enabled
% PHY channel.  This prevents inherited full-stack defaults from turning a
% PRACH-only study into guessed SSB/PDCCH/PUCCH allocations.
profile = lower(strtrim(string(profile)));
switch profile
    case {"prach_detection", "prach_strict_validation"}
        targets = ["FRAME"; "PRACH"];
    case {"pdcch_blind_decode_sweep", "pdcch_strict_validation", ...
            "ctrl6gr_pdcch_study"}
        targets = ["FRAME"; "PDCCH"];
    case "pdsch6gr_truth_study"
        targets = ["FRAME"; "PDSCH"];
    case "trs_strict_validation"
        targets = ["FRAME"; "TRS"];
    case "srs_strict_validation"
        targets = ["FRAME"; "SRS"];
    case "channel_rf_strict_validation"
        targets = ["FRAME"; "PDSCH"; "PUSCH"];
    case "generic_sweep"
        % The parent is an orchestration container and emits no waveform.
        % Each child re-enters runSingle with its effective runner profile
        % and performs its own exact allocation preflight.
        targets = "FRAME";
    case "ai_benchmark"
        % AI benchmarks are component studies.  Their declared target cases
        % identify the real reference-signal/data waveform used to produce
        % the benchmark observations; inherited full-stack features must not
        % become implicit execution requirements.
        targets = localAllocationTargetsFromScenario(scfg);
    otherwise
        targets = strings(0, 1);
end
end

function targets = localAllocationTargetsFromScenario(scfg)
targetCases = upper(strtrim(string(scfg.get("scenario.target_cases", {}))));
targetCases = targetCases(strlength(targetCases) > 0);
aliases = struct( ...
    "SSB", "SSB_PBCH", ...
    "PBCH", "SSB_PBCH", ...
    "TYPE0", "TYPE0_PDCCH", ...
    "SIB1", "SIB1_PDSCH", ...
    "CSIRS", "CSI_RS", ...
    "CSI_RS", "CSI_RS");
supported = ["SSB_PBCH","TYPE0_PDCCH","SIB1_PDSCH","PDCCH", ...
    "PDSCH","CSI_RS","TRS","PRACH","PUCCH","PUSCH","SRS"];
resolved = strings(0, 1);
for i = 1:numel(targetCases)
    token = targetCases(i);
    field = char(token);
    if isfield(aliases, field)
        token = string(aliases.(field));
    end
    if any(token == supported)
        resolved(end+1, 1) = token; %#ok<AGROW>
    end
end
if isempty(resolved)
    error("sixgr:lls6g:runner:MissingComponentAllocationTarget", ...
        "Component runner '%s' has no supported scenario.target_cases allocation authority.", ...
        string(scfg.ScenarioID));
end
targets = unique(["FRAME"; resolved], "stable");
end

function [codeVersion, detail] = localDetectCodeVersion(includeGitHash)
if ~includeGitHash
    codeVersion = "git_hash_omitted";
    detail = "git_hash_omitted_by_config";
    return;
end
repoRoot = localRepoRoot();
codeVersion = "unknown";
detail = "git_unavailable";
cmdHash = sprintf('git -C "%s" rev-parse --short HEAD', repoRoot);
[s1, out1] = system(cmdHash);
if s1 ~= 0
    return;
end
hash = strtrim(out1);
cmdBranch = sprintf('git -C "%s" rev-parse --abbrev-ref HEAD', repoRoot);
[~, out2] = system(cmdBranch);
branch = strtrim(out2);
codeVersion = "git:" + string(hash);
detail = "branch=" + string(branch) + "; hash=" + string(hash);
end

function localAnnotateAllCSV(runFolder, scfg, profile)
if sixgr.db.isArtifactStoreActive()
    return;
end
sixgr.report.annotateScenarioCSVArtifacts(runFolder, scfg.ScenarioID, ...
    scfg.ConfigHash, profile);
end

function result = localMarkComponentAnchorResult(result, anchorRoot)
if ~(isstruct(result) && isscalar(result))
    return;
end
result.EvidenceScope = "component_anchor";
result.SameScenarioInPathEligible = false;
result.ArtifactRoot = string(anchorRoot);
end

function result = localMarkStrictComponentResult(result, policy)
if ~(isstruct(result) && isscalar(result))
    return;
end
if logical(sixgr.util.structGet(policy, ...
        "SameScenarioInPathEligible", false))
    result = localMarkInPathResult(result, policy.ArtifactRoot);
else
    result = localMarkComponentAnchorResult(result, policy.ArtifactRoot);
end
result.RunID = string(sixgr.util.structGet(policy, "RunID", ""));
result.ExecutionID = string(sixgr.util.structGet(policy, "ExecutionID", ""));
result.ScenarioConfigHash = string(sixgr.util.structGet( ...
    policy, "ConfigHash", ""));
end

function result = localMarkInPathResult(result, artifactRoot)
if ~(isstruct(result) && isscalar(result))
    return;
end
result.EvidenceScope = "in_path";
result.SameScenarioInPathEligible = true;
result.ArtifactRoot = string(artifactRoot);
end

function col = localConstantStringColumn(nRows, value)
col = repmat(string(value), max(0, nRows), 1);
end

function T = localBuildScenarioSummaryTable(scfg, cfg, profile, result, scenarioStatus)
okVal = logical(scenarioStatus.ResultOk);
opSummary = localOperatingPointSummary(scfg, cfg, result);
numerologyMu = double(sixgr.util.structGet(opSummary, "Radio.Numerology_mu", NaN));
scsKHz = double(sixgr.util.structGet(opSummary, "Radio.SCS_kHz", NaN));
slotDuration_ms = double(sixgr.util.structGet(opSummary, "Radio.SlotDuration_ms", NaN));
slotsPerFrame = double(sixgr.util.structGet(opSummary, "Radio.SlotsPerFrame", NaN));
symbolsPerSlot = double(sixgr.util.structGet(opSummary, "Radio.SymbolsPerSlot", NaN));
T = table( ...
    string(scfg.ScenarioID), ...
    string(profile), ...
    string(scfg.ConfigHash), ...
    double(scfg.get("simulation.random_seed")), ...
    logical(scfg.get("simulation.deterministic_mode")), ...
    logical(scfg.get("logging.strict_validation")), ...
    double(scfg.get("users.n_users", 1)), ...
    double(scfg.get("mimo.n_layers")), ...
    string(scfg.get("users.beam_selection_strategy")), ...
    "6G_PHY_LLS_SINGLE_SCENARIO", ...
    string(scenarioStatus.RunCompletion), ...
    logical(sixgr.util.structGet(scenarioStatus, "RunCompleted", false)), ...
    okVal, ...
    okVal, ...
    logical(scenarioStatus.PartialOk), ...
    logical(scenarioStatus.ArtifactsGenerated), ...
    logical(sixgr.util.structGet(scenarioStatus, "ArtifactsWritten", scenarioStatus.ArtifactsGenerated)), ...
    double(scenarioStatus.RequiredCaseCount), ...
    double(scenarioStatus.RequiredFailureCount), ...
    double(scenarioStatus.OptionalPrunedCount), ...
    string(scenarioStatus.StatusAuthority), ...
    logical(scenarioStatus.RuntimeTruthContractOk), ...
    logical(sixgr.util.structGet(scenarioStatus, "TruthContractOk", scenarioStatus.RuntimeTruthContractOk)), ...
    logical(sixgr.util.structGet(scenarioStatus, "StandardsConformanceOk", scenarioStatus.RuntimeTruthContractOk)), ...
    logical(sixgr.util.structGet(scenarioStatus, "ScenarioObjectiveOk", scenarioStatus.ResultOk)), ...
    logical(sixgr.util.structGet(scenarioStatus, "ConfiguredEffectiveOk", false)), ...
    logical(sixgr.util.structGet(scenarioStatus, "ConfiguredEffectivePolicyOk", false)), ...
    logical(sixgr.util.structGet(scenarioStatus, "MandatorySubsystemsOk", false)), ...
    logical(sixgr.util.structGet(scenarioStatus, "ActiveIssueGateOk", false)), ...
    logical(sixgr.util.structGet(scenarioStatus, "KpiConsistencyOk", false)), ...
    logical(sixgr.util.structGet(scenarioStatus, "StrictAnchorEligible", false)), ...
    logical(sixgr.util.structGet(scenarioStatus, "StrictAnchorPass", false)), ...
    string(sixgr.util.structGet(scenarioStatus, "ResultStatusReason", "")), ...
    double(sixgr.util.structGet(scenarioStatus, "ActiveMandatoryIssueCount", 0)), ...
    double(sixgr.util.structGet(scenarioStatus, "ActiveCriticalIssueCount", 0)), ...
    double(sixgr.util.structGet(scenarioStatus, "ActiveHighIssueCount", 0)), ...
    double(sixgr.util.structGet(scenarioStatus, "ActiveMediumIssueCount", 0)), ...
    double(scenarioStatus.RoundtripMismatchCount), ...
    double(scenarioStatus.RequiredRuntimeEvidenceMissingCount), ...
    double(scenarioStatus.StrictTruthFailureCount), ...
    double(scenarioStatus.StrictProxyGuardFailureCount), ...
    double(scenarioStatus.CanonicalArtifactGapCount), ...
    logical(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityOk", false)), ...
    double(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityFailureCount", 0)), ...
    string(strjoin(string(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityFailures", strings(0, 1))), "; ")), ...
    logical(sixgr.util.structGet(scenarioStatus, "VisualArtifactGateOk", false)), ...
    double(sixgr.util.structGet(scenarioStatus, "VisualArtifactFailureCount", 0)), ...
    string(strjoin(string(scenarioStatus.RuntimeTruthContractFailures(:)), "; ")), ...
    string(scfg.get("meta.description", "")), ...
    string(opSummary.RuntimeQualifiedDescription), ...
    "nominal", ...
    string(opSummary.Configured.MIMOText), ...
    string(opSummary.Configured.DL.OperatingPointText), ...
    string(opSummary.Configured.UL.OperatingPointText), ...
    double(opSummary.Radio.ActiveGridNumRBs), ...
    double(opSummary.Radio.ConfiguredGridNumRBs), ...
    string(opSummary.Radio.ActiveGridSource), ...
    numerologyMu, ...
    scsKHz, ...
    slotDuration_ms, ...
    slotsPerFrame, ...
    symbolsPerSlot, ...
    string(sixgr.util.structGet(opSummary, "Radio.NumerologySource", "")), ...
    string(sixgr.util.structGet(opSummary, "Radio.TimingInterpretationSource", "")), ...
    string(opSummary.Radio.ActiveDuplexMode), ...
    string(opSummary.Radio.ConfiguredTDDPattern), ...
    string(opSummary.Radio.ActiveTDDPattern), ...
    logical(opSummary.Radio.TDDPatternApplicable), ...
    double(opSummary.DL.SampleCount), ...
    string(opSummary.DL.DominantOperatingPointText), ...
    string(opSummary.DL.LayerHistogram), ...
    string(opSummary.DL.RankHistogram), ...
    string(opSummary.DL.ModulationHistogram), ...
    string(opSummary.DL.MCSHistogram), ...
    double(opSummary.DL.ConfiguredMatchRate), ...
    double(opSummary.UL.SampleCount), ...
    string(opSummary.UL.DominantOperatingPointText), ...
    string(opSummary.UL.LayerHistogram), ...
    string(opSummary.UL.RankHistogram), ...
    string(opSummary.UL.ModulationHistogram), ...
    string(opSummary.UL.MCSHistogram), ...
    double(opSummary.UL.ConfiguredMatchRate), ...
    double(scenarioStatus.FailingCaseCount), ...
    double(scenarioStatus.WarningCount), ...
    string(scenarioStatus.ErrorSource), ...
    string(scenarioStatus.ErrorIdentifier), ...
    string(scenarioStatus.ErrorMessage), ...
    string(scenarioStatus.AuthoritativeStatusSource), ...
    string(opSummary.RuntimeNarrative), ...
    'VariableNames', {'ScenarioID','RunnerProfile','ConfigHash','RandomSeed', ...
    'DeterministicMode','StrictValidation','NumUsers','ConfiguredLayers','BeamSelectionStrategy', ...
    'RunScope','RunCompletion','RunCompleted','Ok','ResultOk','PartialOk','ArtifactsGenerated','ArtifactsWritten', ...
    'RequiredCaseCount','RequiredFailureCount','OptionalPrunedCount','StatusAuthority', ...
    'RuntimeTruthContractOk','TruthContractOk','StandardsConformanceOk','ScenarioObjectiveOk', ...
    'ConfiguredEffectiveOk','ConfiguredEffectivePolicyOk','MandatorySubsystemsOk','ActiveIssueGateOk','KpiConsistencyOk','StrictAnchorEligible','StrictAnchorPass','ResultStatusReason', ...
    'ActiveMandatoryIssueCount','ActiveCriticalIssueCount','ActiveHighIssueCount','ActiveMediumIssueCount', ...
    'RoundtripMismatchCount','RequiredRuntimeEvidenceMissingCount', ...
    'StrictTruthFailureCount','StrictProxyGuardFailureCount','CanonicalArtifactGapCount','VisualArtifactIntegrityOk','VisualArtifactIntegrityFailureCount','VisualArtifactIntegrityFailures','VisualArtifactGateOk','VisualArtifactFailureCount','RuntimeTruthContractFailures','Description', ...
    'RuntimeQualifiedDescription', ...
    'ConfiguredParameterSemantics','ConfiguredMIMO','ConfiguredDLNominalOperatingPoint','ConfiguredULNominalOperatingPoint', ...
    'ActiveGridNumRBs','ConfiguredGridNumRBs','ActiveGridSource','Numerology_mu','SCS_kHz','SlotDuration_ms','SlotsPerFrame','SymbolsPerSlot','NumerologySource','TimingInterpretationSource','ActiveDuplexMode','ConfiguredTDDPattern','ActiveTDDPattern','TDDPatternApplicable', ...
    'EffectiveDLTrialCount','EffectiveDLDominantOperatingPoint','EffectiveDLLayerHistogram','EffectiveDLRankHistogram','EffectiveDLModulationHistogram','EffectiveDLMCSHistogram','EffectiveDLConfiguredMatchRate', ...
    'EffectiveULTrialCount','EffectiveULDominantOperatingPoint','EffectiveULLayerHistogram','EffectiveULRankHistogram','EffectiveULModulationHistogram','EffectiveULMCSHistogram','EffectiveULConfiguredMatchRate', ...
    'FailingCaseCount','WarningCount','ErrorSource','ErrorIdentifier','ErrorMessage','AuthoritativeStatusSource', ...
    'EffectiveRuntimeNote'});
T.PublicationQualified = repmat(logical(sixgr.util.structGet( ...
    scenarioStatus, "PublicationQualified", false)), height(T), 1);
T.PublicationQualificationStatus = repmat(string(sixgr.util.structGet( ...
    scenarioStatus, "PublicationQualificationStatus", "NOT_EVALUATED")), height(T), 1);
T.BrowserPublicationRequired = repmat(logical(sixgr.util.structGet( ...
    scenarioStatus, "BrowserPublicationRequired", false)), height(T), 1);
T.BrowserPublished = repmat(logical(sixgr.util.structGet( ...
    scenarioStatus, "BrowserPublished", false)), height(T), 1);
T.BrowserPublicationStatus = repmat(string(sixgr.util.structGet( ...
    scenarioStatus, "BrowserPublicationStatus", "NOT_EVALUATED")), height(T), 1);
T.ArtifactContractRequired = repmat(logical(sixgr.util.structGet( ...
    scenarioStatus, "ArtifactContractRequired", false)), height(T), 1);
T.ArtifactContractExecuted = repmat(logical(sixgr.util.structGet( ...
    scenarioStatus, "ArtifactContractExecuted", false)), height(T), 1);
T.ArtifactContractGateOk = repmat(logical(sixgr.util.structGet( ...
    scenarioStatus, "ArtifactContractGateOk", true)), height(T), 1);
T.ArtifactContractStatus = repmat(string(sixgr.util.structGet( ...
    scenarioStatus, "ArtifactContractStatus", "NOT_APPLICABLE")), height(T), 1);
T.ArtifactContractCount = repmat(double(sixgr.util.structGet( ...
    scenarioStatus, "ArtifactContractCount", 0)), height(T), 1);
T.ArtifactContractFailureCount = repmat(double(sixgr.util.structGet( ...
    scenarioStatus, "ArtifactContractFailureCount", 0)), height(T), 1);
T.ArtifactContractRequiredFailureCount = repmat(double(sixgr.util.structGet( ...
    scenarioStatus, "ArtifactContractRequiredFailureCount", 0)), height(T), 1);
end

function localWriteMarkdownReport(filePath, scfg, cfg, profile, runFolder, result, manifest, reportBundle, scenarioStatus)
fid = fopen(filePath, "w");
if fid < 0
    return;
end
cleanupObj = onCleanup(@() fclose(fid)); %#ok<NASGU>
opSummary = localOperatingPointSummary(scfg, cfg, result);
fprintf(fid, "# 6G PHY LLS Scenario Report\n\n");
localWriteImplementationVerdictSection(fid, sixgr.util.structGet(reportBundle, "ImplementationValidation", struct()));
fprintf(fid, "- Scenario ID: `%s`\n", string(scfg.ScenarioID));
fprintf(fid, "- Scenario description (configured intent): `%s`\n", string(scfg.get("meta.description", "")));
fprintf(fid, "- Runtime-qualified description: `%s`\n", string(opSummary.RuntimeQualifiedDescription));
fprintf(fid, "- Runner profile: `%s`\n", string(profile));
fprintf(fid, "- Config hash: `%s`\n", string(scfg.ConfigHash));
fprintf(fid, "- Run folder: `%s`\n", string(localRelativeToRunFolder(runFolder, runFolder)));
fprintf(fid, "- Code version: `%s`\n", string(manifest.CodeVersion));
fprintf(fid, "- Random seed: `%d`\n", double(scfg.get("simulation.random_seed")));
fprintf(fid, "- Deterministic mode: `%s`\n", string(logical(scfg.get("simulation.deterministic_mode"))));
fprintf(fid, "- Strict validation: `%s`\n", string(logical(scfg.get("logging.strict_validation"))));
fprintf(fid, "- Users: `%d`\n", double(scfg.get("users.n_users", 1)));
fprintf(fid, "- Configured nominal layers: `%d`\n", double(scfg.get("mimo.n_layers")));
fprintf(fid, "- Configured nominal Tx/Rx antennas: `%dx%d`\n", double(scfg.get("mimo.n_tx_ant")), double(scfg.get("mimo.n_rx_ant")));
fprintf(fid, "- User execution model: `%s`\n", string(scfg.get("users.execution_model", "independent_link_sweep")));
fprintf(fid, "- Beam selection strategy: `%s`\n", string(scfg.get("users.beam_selection_strategy")));
fprintf(fid, "- Run scope: `%s`\n", string(manifest.RunScope));
fprintf(fid, "- Run completion: `%s`\n", string(manifest.RunCompletion));
fprintf(fid, "- Result OK: `%s`\n", string(logical(scenarioStatus.ResultOk)));
fprintf(fid, "- Status: `%s`\n", string(logical(scenarioStatus.ResultOk)));
fprintf(fid, "- Partial OK: `%s`\n", string(logical(scenarioStatus.PartialOk)));
fprintf(fid, "- Artifacts generated: `%s`\n", string(logical(scenarioStatus.ArtifactsGenerated)));
fprintf(fid, "- Required case count: `%g`\n", double(scenarioStatus.RequiredCaseCount));
fprintf(fid, "- Required failure count: `%g`\n", double(scenarioStatus.RequiredFailureCount));
fprintf(fid, "- Optional/pruned case count: `%g`\n", double(scenarioStatus.OptionalPrunedCount));
fprintf(fid, "- Status authority: `%s`\n", string(scenarioStatus.StatusAuthority));
fprintf(fid, "- Runtime truth contract OK: `%s`\n", string(logical(scenarioStatus.RuntimeTruthContractOk)));
fprintf(fid, "- Roundtrip mismatch count: `%g`\n", double(scenarioStatus.RoundtripMismatchCount));
fprintf(fid, "- Required runtime evidence missing count: `%g`\n", double(scenarioStatus.RequiredRuntimeEvidenceMissingCount));
fprintf(fid, "- Strict truth failure count: `%g`\n", double(scenarioStatus.StrictTruthFailureCount));
if strlength(string(scenarioStatus.StatusNotes)) > 0
    fprintf(fid, "- Status notes: `%s`\n", string(scenarioStatus.StatusNotes));
end
fprintf(fid, "- Runtime seconds: `%.3f`\n", double(sixgr.util.structGet(manifest, "ElapsedSeconds", NaN)));
fprintf(fid, "- Environment summary: `meta/environment.json`\n");
fprintf(fid, "- Runtime summary: `meta/runtime_summary.json`\n");
fprintf(fid, "\n## Configured vs Effective Operating Point\n\n");
fprintf(fid, "- Configured parameter semantics: `nominal`\n");
fprintf(fid, "- Configured nominal MIMO: `%s`\n", string(opSummary.Configured.MIMOText));
fprintf(fid, "- Configured DL nominal operating point: `%s`\n", string(opSummary.Configured.DL.OperatingPointText));
fprintf(fid, "- Configured UL nominal operating point: `%s`\n", string(opSummary.Configured.UL.OperatingPointText));
fprintf(fid, "- Active grid RBs: `%s` from `%s`\n", string(localNumericMarkdownToken(opSummary.Radio.ActiveGridNumRBs)), string(opSummary.Radio.ActiveGridSource));
if isfinite(double(opSummary.Radio.ConfiguredGridNumRBs)) && double(opSummary.Radio.ConfiguredGridNumRBs) ~= double(opSummary.Radio.ActiveGridNumRBs)
    fprintf(fid, "- Legacy configured grid RBs retained for traceability: `%s`\n", string(localNumericMarkdownToken(opSummary.Radio.ConfiguredGridNumRBs)));
end
fprintf(fid, "- Active duplex mode: `%s`\n", string(opSummary.Radio.ActiveDuplexMode));
fprintf(fid, "- Configured TDD pattern: `%s`\n", string(opSummary.Radio.ConfiguredTDDPattern));
fprintf(fid, "- Active TDD pattern: `%s`\n", string(opSummary.Radio.ActiveTDDPattern));
fprintf(fid, "- TDD pattern applicable: `%s`\n", string(logical(opSummary.Radio.TDDPatternApplicable)));
if logical(opSummary.DL.HasSamples)
    fprintf(fid, "- Effective DL dominant operating point: `%s`\n", string(opSummary.DL.DominantOperatingPointText));
    fprintf(fid, "- Effective DL layer histogram: `%s`\n", string(opSummary.DL.LayerHistogram));
    fprintf(fid, "- Effective DL rank histogram: `%s`\n", string(opSummary.DL.RankHistogram));
    fprintf(fid, "- Effective DL modulation histogram: `%s`\n", string(opSummary.DL.ModulationHistogram));
    fprintf(fid, "- Effective DL MCS histogram: `%s`\n", string(opSummary.DL.MCSHistogram));
end
if logical(opSummary.UL.HasSamples)
    fprintf(fid, "- Effective UL dominant operating point: `%s`\n", string(opSummary.UL.DominantOperatingPointText));
    fprintf(fid, "- Effective UL layer histogram: `%s`\n", string(opSummary.UL.LayerHistogram));
    fprintf(fid, "- Effective UL rank histogram: `%s`\n", string(opSummary.UL.RankHistogram));
    fprintf(fid, "- Effective UL modulation histogram: `%s`\n", string(opSummary.UL.ModulationHistogram));
    fprintf(fid, "- Effective UL MCS histogram: `%s`\n", string(opSummary.UL.MCSHistogram));
end
fprintf(fid, "- Effective runtime note: `%s`\n", string(opSummary.RuntimeNarrative));
fprintf(fid, "\n## Report Bundle\n\n");
fprintf(fid, "- Coverage table: `reports/csv/lls_output_spec_coverage.csv`\n");
fprintf(fid, "- Metric rows: `reports/csv/lls_output_metric_rows.csv`\n");
fprintf(fid, "- Artifact inventory: `reports/csv/artifact_inventory.csv`\n");
fprintf(fid, "- Validation messages: `reports/csv/validation_messages.csv`\n");
fprintf(fid, "- Executive summary: `%s`\n", string(localRelativeToRunFolder(sixgr.util.structGet(reportBundle, "ExecutiveSummary", ""), runFolder)));
fprintf(fid, "- Technical report: `%s`\n", string(localRelativeToRunFolder(sixgr.util.structGet(reportBundle, "TechnicalReport", ""), runFolder)));
fprintf(fid, "\n## Source Chain\n\n");
for i = 1:numel(scfg.SourceFiles)
    fprintf(fid, "- `%s`\n", string(localPortablePath(scfg.SourceFiles(i))));
end
clear cleanupObj
sixgr.db.captureFileArtifact(filePath, "markdown_report", "text/markdown; charset=UTF-8", true);
end

function localWriteImplementationVerdictSection(fid, validation)
if ~(isstruct(validation) && isfield(validation, "Summary") && isstruct(validation.Summary))
    return;
end
summary = validation.Summary;
fprintf(fid, "## Actual LLS Implementation Verdict\n\n");
fprintf(fid, "- Verdict: `%s`\n", string(sixgr.util.structGet(summary, "ActualLLSVerdict", "")));
fprintf(fid, "- Statement: %s\n", string(sixgr.util.structGet(summary, "VerdictSentence", "")));
fprintf(fid, "- Enabled blocks: `%g`\n", double(sixgr.util.structGet(summary, "EnabledBlockCount", 0)));
fprintf(fid, "- Passing blocks: `%g`\n", double(sixgr.util.structGet(summary, "PassingBlockCount", 0)));
fprintf(fid, "- Reference-compared blocks: `%g`\n", double(sixgr.util.structGet(summary, "ReferenceComparedBlockCount", 0)));
fprintf(fid, "- Numerical sanity failures: `%g`\n", double(sixgr.util.structGet(summary, "NumericalSanityFailureCount", 0)));
fprintf(fid, "- Expected functions not called: `%s`\n", strjoin(cellstr(string(sixgr.util.structGet(summary, "FunctionNotCalled", strings(0, 1)))), " | "));
fprintf(fid, "- Bypassed blocks: `%s`\n", strjoin(cellstr(string(sixgr.util.structGet(summary, "BypassedBlocks", strings(0, 1)))), " | "));
proxyDetections = unique([ ...
    string(sixgr.util.structGet(summary, "LabelOnlyBlocks", strings(0, 1))); ...
    string(sixgr.util.structGet(summary, "ProxyBlocks", strings(0, 1))); ...
    string(sixgr.util.structGet(summary, "FallbackBlocks", strings(0, 1)))]);
fprintf(fid, "- Label-only/proxy detections: `%s`\n\n", strjoin(cellstr(proxyDetections), " | "));
end

function opSummary = localOperatingPointSummary(scfg, cfg, result)
dlTrials = table();
ulTrials = table();
if isstruct(result) && isfield(result, "Link")
    rawTrials = sixgr.util.structGet(result.Link, "RawTrials", struct());
    dlTrials = localOptionalRawTrialTable(rawTrials, "DL");
    ulTrials = localOptionalRawTrialTable(rawTrials, "UL");
    if isempty(dlTrials)
        dlTrials = localOptionalNestedTrialTable(result.Link, "ResultDL");
    end
    if isempty(ulTrials)
        ulTrials = localOptionalNestedTrialTable(result.Link, "ResultUL");
    end
end
opSummary = sixgr.truth.summarizeEffectiveOperatingPoint(scfg, dlTrials, ulTrials, cfg);
opSummary.Radio.SCS_kHz = double(scfg.get("frame.scs_khz", NaN));
cp = string(scfg.get("frame.cp_type", "normal"));
numerology = sixgr.phy.frame.NumerologyCatalog.resolve( ...
    opSummary.Radio.SCS_kHz, cp, "generic_waveform_test", "");
opSummary.Radio.Numerology_mu = double(numerology.Mu);
opSummary.Radio.SlotDuration_ms = ...
    double(numerology.SlotDurationMilliseconds);
opSummary.Radio.SlotsPerFrame = double(numerology.SlotsPerFrame);
opSummary.Radio.SymbolsPerSlot = double(numerology.SymbolsPerSlot);
opSummary.Radio.NumerologySource = "frame.scs_khz_runtime_authority";
opSummary.Radio.TimingInterpretationSource = "nr_mu_from_scs";
end

function T = localOptionalRawTrialTable(rawTrials, fieldName)
T = table();
if isstruct(rawTrials) && isfield(rawTrials, char(fieldName)) && istable(rawTrials.(char(fieldName)))
    T = rawTrials.(char(fieldName));
end
end

function T = localOptionalNestedTrialTable(linkResult, fieldName)
T = table();
if ~(isstruct(linkResult) && isfield(linkResult, char(fieldName)))
    return;
end
node = linkResult.(char(fieldName));
if isstruct(node)
    T = sixgr.util.structGet(node, "TrialTable", table());
end
if ~istable(T)
    T = table();
end
end

function resolvedStruct = localResolvedSnapshotStruct(scfg)
resolvedStruct = scfg.toStruct();
resolvedStruct = localSanitizeNoProxySnapshot(scfg, resolvedStruct);
opSummary = sixgr.truth.summarizeEffectiveOperatingPoint(scfg, table(), table());
legacyGrid = sixgr.util.structGet(resolvedStruct, "resource_grid.num_rbs", NaN);
activeGrid = double(opSummary.Radio.ActiveGridNumRBs);
if isfinite(activeGrid)
    if isfinite(legacyGrid) && legacyGrid ~= activeGrid
        resolvedStruct = sixgr.util.structSet(resolvedStruct, "resource_grid.configured_num_rbs", legacyGrid);
    end
    resolvedStruct = sixgr.util.structSet(resolvedStruct, "resource_grid.num_rbs", activeGrid);
    resolvedStruct = sixgr.util.structSet(resolvedStruct, "resource_grid.active_num_rbs_source", char(string(opSummary.Radio.ActiveGridSource)));
end
resolvedStruct = sixgr.util.structSet(resolvedStruct, "frequency.active_duplex_mode", char(string(opSummary.Radio.ActiveDuplexMode)));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "frame.configured_tdd_pattern", char(string(opSummary.Radio.ConfiguredTDDPattern)));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "frame.tdd_pattern_applicable", logical(opSummary.Radio.TDDPatternApplicable));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "frame.active_tdd_pattern", char(string(opSummary.Radio.ActiveTDDPattern)));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "reporting_semantics.configured_parameters_are_nominal", true);
resolvedStruct = sixgr.util.structSet(resolvedStruct, "reporting_semantics.actual_runtime_selected_parameters_emitted_in", "reports/csv/scenario_summary.csv");
resolvedStruct = sixgr.util.structSet(resolvedStruct, "reporting_semantics.report_bundle_runtime_metadata_emitted_in", "reports/csv/run_metadata_outputs.csv");
resolvedStruct = sixgr.util.structSet(resolvedStruct, "reporting_semantics.runtime_qualified_description_emitted_in", "reports/csv/scenario_summary.csv");
resolvedStruct = sixgr.util.structSet(resolvedStruct, "resolved_runtime_view.configured_mimo", char(string(opSummary.Configured.MIMOText)));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "resolved_runtime_view.configured_dl_nominal_operating_point", char(string(opSummary.Configured.DL.OperatingPointText)));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "resolved_runtime_view.configured_ul_nominal_operating_point", char(string(opSummary.Configured.UL.OperatingPointText)));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "resolved_runtime_view.active_grid_num_rbs", double(opSummary.Radio.ActiveGridNumRBs));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "resolved_runtime_view.active_grid_source", char(string(opSummary.Radio.ActiveGridSource)));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "resolved_runtime_view.active_duplex_mode", char(string(opSummary.Radio.ActiveDuplexMode)));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "resolved_runtime_view.active_tdd_pattern", char(string(opSummary.Radio.ActiveTDDPattern)));
resolvedStruct = sixgr.util.structSet(resolvedStruct, "resolved_runtime_view.tdd_pattern_applicable", logical(opSummary.Radio.TDDPatternApplicable));
end

function resolvedStruct = localSanitizeNoProxySnapshot(scfg, resolvedStruct)
tags = lower(string(sixgr.util.structGet(resolvedStruct, "meta.tags", strings(0, 1))));
strictValidation = false;
try
    strictValidation = logical(scfg.get("logging.strict_validation", false));
catch
end
noProxyTruth = any(tags == "no-proxy") || (any(tags == "truth") && strictValidation);
if ~noProxyTruth
    return;
end

resolvedStruct = sixgr.util.structSet(resolvedStruct, "reporting_semantics.no_proxy_truth_contract", true);
resolvedStruct = sixgr.util.structSet(resolvedStruct, ...
    "reporting_semantics.snapshot_sanitization_note", ...
    "Strict no-proxy truth snapshots disable proxy/fallback defaults and relabel complexity-derived area-efficiency metrics as measured runtime values.");
resolvedStruct = sixgr.util.structSet(resolvedStruct, "reporting_semantics.area_efficiency_runtime_metric", "bits_per_decoder_complexity_unit");

resolvedStruct = sixgr.util.structSet(resolvedStruct, "ai_ml.fallback_enabled", false);
resolvedStruct = sixgr.util.structSet(resolvedStruct, "ai_ml.fallback_mode", "disabled");
resolvedStruct = sixgr.util.structSet(resolvedStruct, "channel_coding.area_efficiency_proxy_policy", "measured_runtime_metric");
resolvedStruct = sixgr.util.structSet(resolvedStruct, "coding_and_decoder.area_efficiency_proxy_policy", "measured_runtime_metric");
resolvedStruct = sixgr.util.structSet(resolvedStruct, "energy_and_complexity.area_efficiency_proxy", "measured_runtime_metric");
resolvedStruct = sixgr.util.structSet(resolvedStruct, "energy_efficiency.area_efficiency_proxy", "measured_runtime_metric");
end

function token = localNumericMarkdownToken(value)
if ~isfinite(double(value))
    token = "NaN";
elseif abs(double(value) - round(double(value))) < 1e-12
    token = string(round(double(value)));
else
    token = string(double(value));
end
end

function runtime = localBuildRuntimeSummary(startUTC, runTimer, profile, runFolder, cfg)
runtime = struct();
runtime.RunID = char(string(sixgr.util.structGet(cfg, "run.runTag", "")));
runtime.ExecutionID = char(string(sixgr.util.structGet(cfg, "run.executionID", "")));
runtime.ConfigHash = char(string(sixgr.util.structGet(cfg, "meta.configHash", "")));
runtime.StartedUTC = char(string(startUTC));
runtime.CompletedUTC = char(string(localUTCStamp()));
runtime.ElapsedSeconds = double(toc(runTimer));
runtime.RunnerProfile = char(string(profile));
runtime.RunFolder = char(string(runFolder));
runtime.WarningCount = 0;
runtime.Warnings = strings(0, 1);
runtime.UseMex = logical(sixgr.util.structGet(cfg, "run.useMex", false));
runtime.UseMexAutoEnabled = logical(sixgr.util.structGet(cfg, "run.useMexAutoEnabled", false));
runtime.UseParallel = logical(sixgr.util.structGet(cfg, "run.useParallel", false));
runtime.RequestedWorkers = double(sixgr.util.structGet(cfg, "run.parallelRequestedWorkers", ...
    sixgr.util.structGet(cfg, "run.numWorkers", 0)));
runtime.EffectiveWorkers = localEffectiveWorkerCount(cfg);
runtime.ParallelDisabledReason = char(string(sixgr.util.structGet(cfg, "run.parallelDisabledReason", "")));
runtime.MaxNumCompThreads = double(localSafeMaxNumCompThreads());
numerology = localResolveConfigNumerology(cfg);
runtime.Numerology_mu = double(numerology.Mu);
runtime.SCS_kHz = double(numerology.SubcarrierSpacingKHz);
runtime.SlotDuration_ms = double(numerology.SlotDurationMilliseconds);
runtime.SlotsPerFrame = double(numerology.SlotsPerFrame);
runtime.SymbolsPerSlot = double(numerology.SymbolsPerSlot);
runtime.ConfiguredGridNumRBs = double(sixgr.util.structGet(cfg, "phy.numerology.configuredGridNumRBs", NaN));
runtime.ActiveGridNumRBs = double(sixgr.util.structGet(cfg, "phy.numerology.activeGridNumRBs", NaN));
runtime.ActiveGridSource = char(string(sixgr.util.structGet(cfg, "phy.numerology.activeGridSource", "")));
runtime.NumerologySource = char(string(sixgr.util.structGet(cfg, "phy.numerology.numerologySource", "")));
runtime.TimingInterpretationSource = char(string(sixgr.util.structGet(cfg, "phy.numerology.timingInterpretationSource", "")));
end

function env = localBuildEnvironmentSummary(cfg)
env = struct();
env.Platform = char(string(computer));
env.Architecture = char(string(computer("arch")));
env.MATLABVersion = char(string(version));
env.MATLABRelease = char(string(version("-release")));
env.JavaVersion = char(string(version("-java")));
env.Hostname = char(string(getenv("COMPUTERNAME")));
env.OS = char(string(getenv("OS")));
env.PhysicalCoreCount = double(localSafeFeatureNumCores());
env.ComputeThreadCount = double(localSafeMaxNumCompThreads());
env.JavaAvailableProcessors = double(localSafeJavaAvailableProcessors());
env.ParallelToolboxInstalled = logical(localHasParallelToolboxInstalled());
env.ParallelLicenseAvailable = logical(localHasParallelLicense());
env.ParpoolFunctionAvailable = logical(exist("parpool", "file") == 2);
env.RequestedWorkers = double(sixgr.util.structGet(cfg, "run.parallelRequestedWorkers", ...
    sixgr.util.structGet(cfg, "run.numWorkers", 0)));
env.EffectiveWorkers = localEffectiveWorkerCount(cfg);
env.UseMex = logical(sixgr.util.structGet(cfg, "run.useMex", false));
env.UseMexAutoEnabled = logical(sixgr.util.structGet(cfg, "run.useMexAutoEnabled", false));
env.ParallelDisabledReason = char(string(sixgr.util.structGet(cfg, "run.parallelDisabledReason", "")));
end

function localEnsureScenarioDirs(layout)
dirs = { ...
    layout.MetaDir, layout.LogDir, layout.ReportDir, layout.ReportCSVDir, layout.ReportMATDir, ...
    layout.ReportImageDir, fullfile(layout.ReportDir, "json"), layout.AirInterfaceDir, layout.AirInterfaceCSVDir, layout.AirInterfaceMATDir, ...
    layout.AirInterfaceImageDir, layout.ControlDir, layout.ControlCSVDir, layout.ControlImageDir, ...
    layout.BeamformingDir, layout.BeamformingCSVDir, layout.BeamformingImageDir};
for i = 1:numel(dirs)
    sixgr.util.ensureFolder(dirs{i});
end
sixgr.visual.clearRunImageDirectories(layout.Root);
end

function leaf = localResolveLeaf(runTag)
runTag = char(string(runTag));
if strlength(string(runTag)) == 0
    leaf = "current";
else
    leaf = localSanitizeToken(runTag, "current");
end
end

function runFolder = localComposeRunFolderNoCreate(resultsRoot, bucket, profile, leaf)
root = sixgr.report.resolveResultsRoot(char(string(resultsRoot)));
bucket = localSanitizeToken(bucket, "lls");
profile = localSanitizeToken(profile, "scenario");
leaf = localSanitizeToken(leaf, "current");
root = localNormalizeRunFolderPath(root);
if localRunFolderEndsWithSegments(root, [bucket profile])
    runFolder = fullfile(root, leaf);
elseif localRunFolderEndsWithSegments(root, bucket)
    runFolder = fullfile(root, profile, leaf);
elseif localRunFolderEndsWithSegments(root, profile)
    % Keep resume/logical-path composition identical to
    % sixgr.report.defaultRunFolder when outputDir is already the complete
    % scenario/profile root.
    runFolder = fullfile(root, leaf);
else
    runFolder = fullfile(root, bucket, profile, leaf);
end
runFolder = localNormalizeRunFolderPath(runFolder);
end

function tf = localRunFolderEndsWithSegments(pathValue, segments)
parts = localRunFolderPathParts(pathValue);
segments = string(segments);
segments = segments(strlength(segments) > 0);
if isempty(segments)
    tf = true;
    return;
end
if numel(parts) < numel(segments)
    tf = false;
    return;
end
tail = parts(end-numel(segments)+1:end);
if ispc
    tf = all(strcmpi(tail, segments));
else
    tf = all(strcmp(tail, segments));
end
end

function parts = localRunFolderPathParts(pathValue)
pathValue = string(localNormalizeRunFolderPath(pathValue));
pathValue = replace(pathValue, "\", "/");
pathValue = regexprep(pathValue, "/+", "/");
parts = split(pathValue, "/");
parts = parts(strlength(parts) > 0);
end

function pathValue = localNormalizeRunFolderPath(pathValue)
pathValue = char(string(strtrim(string(pathValue))));
if strlength(string(pathValue)) == 0
    pathValue = "";
    return;
end
pathValue = strrep(pathValue, "/", filesep);
pathValue = strrep(pathValue, "\", filesep);
while contains(pathValue, [filesep filesep])
    pathValue = strrep(pathValue, [filesep filesep], filesep);
end
if strlength(string(pathValue)) > 1 && endsWith(pathValue, filesep) && ~(ispc && numel(pathValue) == 3 && pathValue(2) == ':')
    pathValue = char(extractBefore(string(pathValue), strlength(string(pathValue))));
end
end

function localCleanupDBOnlyRunFolders(backend, stagingRunFolder, logicalRunFolder)
if lower(string(backend)) ~= "mysql_web"
    return;
end
if localSameFolder(stagingRunFolder, logicalRunFolder)
    % Current mysql_web runs publish directly into the durable result tree.
    % Never delete that authoritative filesystem evidence on cleanup.
    return;
end
localDeleteFolderTreeIfExists(stagingRunFolder);
% The logical folder is the public result folder used by the web UI and
% audits. MySQL artifacts are hydrated there after completion, so cleanup
% must never delete it.
logicalRunFolder = string(logicalRunFolder); %#ok<NASGU>
end

function localDeleteFolderTreeIfExists(folderPath)
folderPath = char(string(folderPath));
if strlength(string(folderPath)) == 0 || ~isfolder(folderPath)
    return;
end
try
    warnState = warning("off", "all");
    cleanupWarn = onCleanup(@() warning(warnState)); %#ok<NASGU>
    rmdir(folderPath, "s");
catch
end
end

function localApplyRunRandomness(scfg)
seed = double(scfg.get("simulation.random_seed"));
if logical(scfg.get("simulation.deterministic_mode"))
    rng(seed, "twister");
else
    rng("shuffle");
end
end

function cfg = localEnsureParallelExecution(cfg)
useParallel = logical(sixgr.util.structGet(cfg, "run.useParallel", false));
requestedWorkers = max(0, round(double(sixgr.util.structGet(cfg, "run.numWorkers", 0))));
autoStartParallelPool = logical(sixgr.util.structGet(cfg, "run.autoStartParallelPool", true));
configuredDisabledReason = string(sixgr.util.structGet(cfg, "run.parallelDisabledReason", ""));
cfg = sixgr.util.structSet(cfg, "run.parallelRequestedWorkers", double(requestedWorkers));
cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", "");
cfg = sixgr.util.structSet(cfg, "run.autoStartParallelPool", logical(autoStartParallelPool));
idleTimeoutMinutes = max(1, double(sixgr.util.structGet(cfg, ...
    "run.parallelPoolIdleTimeoutMinutes", 1440)));
cfg = sixgr.util.structSet(cfg, "run.parallelPoolIdleTimeoutMinutes", double(idleTimeoutMinutes));
parallelInstalled = localHasParallelToolboxInstalled();
parallelLicensed = localHasParallelLicense();
parpoolAvailable = exist("parpool", "file") == 2;
if ~useParallel
    cfg.run.useParallel = false;
    cfg = localSetSerialWorkerState(cfg);
    disabledReason = "parallel_not_requested";
    if strlength(strtrim(configuredDisabledReason)) > 0
        disabledReason = configuredDisabledReason;
    end
    cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", char(disabledReason));
    return;
end
if requestedWorkers <= 1
    cfg.run.useParallel = false;
    cfg = localSetSerialWorkerState(cfg);
    cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", "requested_workers_leq_1");
    return;
end
if ~parallelInstalled || ~parallelLicensed || ~parpoolAvailable
    cfg.run.useParallel = false;
    cfg = localSetSerialWorkerState(cfg);
    if ~parallelLicensed
        cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", "parallel_computing_toolbox_license_unavailable");
    elseif ~parallelInstalled
        cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", "parallel_computing_toolbox_not_installed");
    else
        cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", "parpool_function_unavailable");
    end
    return;
end

if ~autoStartParallelPool
    cfg.run.useParallel = true;
    cfg.run.numWorkers = double(requestedWorkers);
    cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", "");
    cfg = sixgr.util.structSet(cfg, "run.parallelStartMode", "lazy_on_demand");
    cfg = sixgr.util.structSet(cfg, "run.parallelPoolKindEffective", ...
        char(lower(strtrim(string(sixgr.util.structGet(cfg, "run.parallelPoolKind", "auto"))))));
    cfg = sixgr.util.structSet(cfg, "run.parallelPoolSelectionReason", ...
        "auto_start_parallel_pool_disabled_by_config");
    cfg = sixgr.util.structSet(cfg, "run.parallelStartFailure", "");
    cfg = sixgr.util.structSet(cfg, "run.parallelPoolIdleTimeoutEffectiveMinutes", double(idleTimeoutMinutes));
    return;
end

threadCandidates = localParallelWorkerCandidates(requestedWorkers, ...
    [localSafeFeatureNumCores(), localSafeMaxNumCompThreads()]);
processCandidates = localParallelWorkerCandidates(requestedWorkers, ...
    localSafeLocalClusterNumWorkers());

[poolOrder, poolOrderReason] = localResolveParallelPoolStartOrder(cfg);
pool = [];
startReason = "";
startFailures = strings(0, 1);
for poolKind = poolOrder(:).'
    if poolKind == "threads"
        candidates = threadCandidates;
    else
        candidates = processCandidates;
    end
    [pool, startReason, poolFailure] = localStartRequestedParpool(poolKind, candidates, idleTimeoutMinutes);
    if strlength(string(poolFailure)) > 0
        startFailures(end + 1, 1) = string(poolFailure); %#ok<AGROW>
    end
    if ~isempty(pool)
        break;
    end
end
startFailure = char(strjoin(startFailures, " | "));

if isempty(pool)
    cfg.run.useParallel = false;
    cfg = localSetSerialWorkerState(cfg);
    cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", "parpool_start_failed");
    cfg = sixgr.util.structSet(cfg, "run.parallelStartFailure", char(string(startFailure)));
    return;
end

cfg.run.useParallel = ~isempty(pool);
cfg.run.numWorkers = double(pool.NumWorkers);
cfg = sixgr.util.structSet(cfg, "run.parallelDisabledReason", "");
cfg = sixgr.util.structSet(cfg, "run.parallelStartMode", char(startReason));
cfg = sixgr.util.structSet(cfg, "run.parallelPoolKindEffective", char(localPoolKindToken(pool)));
cfg = sixgr.util.structSet(cfg, "run.parallelPoolSelectionReason", char(poolOrderReason));
cfg = sixgr.util.structSet(cfg, "run.parallelStartFailure", char(string(startFailure)));
cfg = sixgr.util.structSet(cfg, "run.parallelPoolIdleTimeoutEffectiveMinutes", double(idleTimeoutMinutes));
sixgr.util.rngInit(double(sixgr.util.structGet(cfg, "run.seed", 1)), true);
end

function cfg = localSetSerialWorkerState(cfg)
% No parpool workers are active, but one MATLAB coordinator still executes
% the exact serial waveform chain. Keep requested-workers separate in
% run.parallelRequestedWorkers and expose one effective execution worker.
cfg = sixgr.util.structSet(cfg, "run.numWorkers", 1);
end

function n = localEffectiveWorkerCount(cfg)
raw = double(sixgr.util.structGet(cfg, "run.numWorkers", 1));
if ~(isscalar(raw) && isfinite(raw) && raw >= 1)
    raw = 1;
end
n = double(max(1, round(raw)));
end

function [order, reason] = localResolveParallelPoolStartOrder(cfg)
requested = lower(strtrim(string(sixgr.util.structGet(cfg, "run.parallelPoolKind", "auto"))));
requiresProcessPool = localRequiresProcessBackedParallelPool(cfg);
if any(requested == ["process", "processes", "local"])
    order = "processes";
    reason = "configured_process_pool";
elseif requested == "threads" && ~requiresProcessPool
    order = "threads";
    reason = "configured_thread_pool";
elseif requested == "threads" && requiresProcessPool
    order = "processes";
    reason = "thread_pool_requested_but_process_pool_required_for_waveform_phy_mex_workers";
elseif requiresProcessPool
    order = "processes";
    reason = "auto_process_pool_required_for_waveform_phy_mex_workers";
else
    order = ["threads", "processes"];
    reason = "auto_threads_preferred_for_non_mex_parallel_work";
end
end

function tf = localRequiresProcessBackedParallelPool(cfg)
runnerProfile = lower(strtrim(string(sixgr.util.structGet(cfg, "run.runnerProfile", ...
    sixgr.util.structGet(cfg, "scenario.runner_profile", "")))));
modeToken = lower(strtrim(string(sixgr.util.structGet(cfg, "run.mode", ""))));
channelModel = upper(strtrim(string(sixgr.util.structGet(cfg, "channel.model", ""))));
usesWaveformBundle = runnerProfile == "waveform_bundle" || modeToken == "link";
usesPHYToolboxMex = usesWaveformBundle || any(channelModel == ["TDL", "CDL", "NRTDL", "NRCDL"]);
tf = logical(usesPHYToolboxMex);
end

function token = localPoolKindToken(pool)
token = "";
if isempty(pool)
    return;
end
try
    classToken = lower(string(class(pool)));
    if contains(classToken, "thread")
        token = "threads";
    elseif contains(classToken, "process")
        token = "processes";
    else
        token = char(class(pool));
    end
catch
    token = "";
end
end

function candidates = localParallelWorkerCandidates(requestedWorkers, caps)
requestedWorkers = max(0, floor(double(requestedWorkers)));
caps = double(caps(:));
caps = caps(isfinite(caps) & caps >= 2);
if isempty(caps)
    maxAllowed = requestedWorkers;
else
    maxAllowed = min(requestedWorkers, max(floor(caps)));
end
if ~(isfinite(maxAllowed) && maxAllowed >= 2)
    candidates = [];
    return;
end

raw = [requestedWorkers, maxAllowed, floor(maxAllowed ./ [2 4 8]), 32, 16, 12, 8, 4, 2];
raw = floor(double(raw(:)));
raw = raw(isfinite(raw) & raw >= 2 & raw <= maxAllowed);
candidates = [];
for i = 1:numel(raw)
    if ~any(candidates == raw(i))
        candidates(end + 1) = raw(i); %#ok<AGROW>
    end
end
candidates = sort(candidates, "descend");
end

function [pool, startReason, failureText] = localStartRequestedParpool(poolKind, candidates, idleTimeoutMinutes)
pool = [];
startReason = "";
failures = strings(0, 1);
poolKind = lower(string(poolKind));
candidates = double(candidates(:)');
idleTimeoutMinutes = max(1, double(idleTimeoutMinutes));
for n = candidates
    try
        existing = gcp("nocreate");
        if ~isempty(existing) && ~localExistingPoolMatchesRequest(existing, poolKind, n)
            delete(existing);
            existing = [];
        end
        if ~isempty(existing)
            pool = existing;
        elseif poolKind == "threads"
            pool = parpool("threads", n);
        else
            pool = localStartProcessParpool(n);
        end
        pool = localApplyParpoolIdleTimeout(pool, idleTimeoutMinutes);
        if ~isempty(pool) && double(pool.NumWorkers) > 1
            startReason = sprintf("%s_%d_workers", char(poolKind), double(pool.NumWorkers));
            failureText = char(strjoin(failures, " | "));
            return;
        end
        if ~isempty(pool)
            delete(pool);
            pool = [];
        end
        failures(end + 1, 1) = sprintf("%s(%d): pool_started_with_leq_1_worker", char(poolKind), n); %#ok<AGROW>
    catch ME
        failures(end + 1, 1) = sprintf("%s(%d): %s %s", char(poolKind), n, char(string(ME.identifier)), char(string(ME.message))); %#ok<AGROW>
    end
end

if poolKind == "threads"
    try
        existing = gcp("nocreate");
        if ~isempty(existing) && ~localExistingPoolMatchesRequest(existing, poolKind, NaN)
            delete(existing);
            existing = [];
        end
        if ~isempty(existing)
            pool = existing;
            pool = localApplyParpoolIdleTimeout(pool, idleTimeoutMinutes);
            startReason = sprintf("threads_default_%d_workers", double(pool.NumWorkers));
            failureText = char(strjoin(failures, " | "));
            return;
        end
        pool = parpool("threads");
        pool = localApplyParpoolIdleTimeout(pool, idleTimeoutMinutes);
        if ~isempty(pool) && double(pool.NumWorkers) > 1
            startReason = sprintf("threads_default_%d_workers", double(pool.NumWorkers));
            failureText = char(strjoin(failures, " | "));
            return;
        end
    catch ME
        failures(end + 1, 1) = sprintf("threads(default): %s %s", char(string(ME.identifier)), char(string(ME.message))); %#ok<AGROW>
    end
end

pool = [];
startReason = "";
failureText = char(strjoin(failures, " | "));
end

function tf = localExistingPoolMatchesRequest(pool, poolKind, workers)
tf = false;
if isempty(pool)
    return;
end
if isfinite(double(workers)) && double(pool.NumWorkers) ~= double(workers)
    return;
end
actualKind = lower(string(localPoolKindToken(pool)));
requestedKind = lower(string(poolKind));
if requestedKind == "processes"
    tf = actualKind == "processes";
elseif requestedKind == "threads"
    tf = actualKind == "threads";
else
    tf = true;
end
end

function pool = localStartProcessParpool(n)
pool = [];
try
    pool = parpool(n);
    return;
catch firstME
    firstFailure = sprintf("%s %s", char(string(firstME.identifier)), char(string(firstME.message)));
end
try
    pool = parpool("local", n);
catch secondME
    error("sixgr:lls6g:ParpoolStartFailed", ...
        "Process parpool(%d) failed: %s; local profile failed: %s %s", ...
        n, firstFailure, char(string(secondME.identifier)), char(string(secondME.message)));
end
end

function pool = localApplyParpoolIdleTimeout(pool, idleTimeoutMinutes)
if isempty(pool)
    return;
end
idleTimeoutMinutes = max(1, double(idleTimeoutMinutes));
try
    if isprop(pool, 'IdleTimeout')
        pool.IdleTimeout = idleTimeoutMinutes;
    end
catch
    % Older MATLAB releases or cluster profiles may keep IdleTimeout read-only.
    % The run still proceeds; grant-level code can restart an expired pool.
end
end

function n = localSafeLocalClusterNumWorkers()
try
    cluster = parcluster("local");
    n = double(cluster.NumWorkers);
catch
    n = NaN;
end
if ~(isscalar(n) && isfinite(n) && n >= 1)
    n = NaN;
end
end

function cfg = localEnsureExactMexAcceleration(cfg)
requestedUseMex = sixgr.util.structGet(cfg, "run.useMex", []);
caps = localExactMexCapabilities();
autoEnabled = false;
forceDisableForStrictCoupledTruth = localShouldDisableExactMexForStrictCoupledTruthWaveform(cfg);

if forceDisableForStrictCoupledTruth
    requestedUseMex = false;
elseif isempty(requestedUseMex)
    requestedUseMex = logical(caps.Any);
    autoEnabled = logical(caps.Any);
end

requestedUseMex = logical(requestedUseMex);
if requestedUseMex && ~logical(caps.Any)
    requestedUseMex = false;
end

cfg = sixgr.util.structSet(cfg, "run.useMex", requestedUseMex);
cfg = sixgr.util.structSet(cfg, "run.useMexAutoEnabled", autoEnabled);
cfg = sixgr.util.structSet(cfg, "run.exactMexAvailable", logical(caps.Any));
cfg = sixgr.util.structSet(cfg, "run.exactMexCapabilities", caps);
if requestedUseMex
    cfg = sixgr.util.structSet(cfg, "run.useMexDisabledReason", "");
else
    if forceDisableForStrictCoupledTruth
        cfg = sixgr.util.structSet(cfg, "run.useMexDisabledReason", ...
            "exact_mex_disabled_for_strict_coupled_truth_waveform_bundle");
    elseif logical(caps.Any)
        cfg = sixgr.util.structSet(cfg, "run.useMexDisabledReason", "exact_mex_not_requested");
    else
        cfg = sixgr.util.structSet(cfg, "run.useMexDisabledReason", "no_exact_mex_kernels_found");
    end
end
end

function tf = localShouldDisableExactMexForStrictCoupledTruthWaveform(cfg)
runnerProfile = lower(strtrim(string(sixgr.util.structGet(cfg, "run.runnerProfile", ...
    sixgr.util.structGet(cfg, "lls6g.scenario.runner_profile", "")))));
if strlength(runnerProfile) == 0
    if lower(strtrim(string(sixgr.util.structGet(cfg, "run.mode", "")))) == "system"
        runnerProfile = "system_level_lls";
    end
end
channelModel = upper(strtrim(string(sixgr.util.structGet(cfg, "channel.model", "AWGN"))));
phyBackend = lower(strtrim(string(sixgr.util.structGet(cfg, "system.phyBackend", "waveform"))));
tf = runnerProfile == "system_level_lls" && phyBackend == "waveform" && channelModel ~= "AWGN";
end

function caps = localExactMexCapabilities()
caps = struct();
caps.AWGNKernel = logical(exist("sixgr_awgn_complex_kernel_mex", "file") == 3);
caps.LDPCBatchDecodeKernel = logical(exist("sixgr_ldpc_decode_batch_kernel_mex", "file") == 3);
caps.StructGetKernel = logical(exist("sixgr_struct_get_mex", "file") == 3);
caps.FFTPAPRKernel = logical(exist("sixgr_fft_papr_kernel_mex", "file") == 3);
caps.CorrelationMetricKernel = logical(exist("sixgr_corr_metric_kernel_mex", "file") == 3);
caps.FrequencyCorrectionSearchKernel = logical(exist("sixgr_freq_corr_search_kernel_mex", "file") == 3);
caps.FrequencyShiftKernel = logical(exist("sixgr_freq_shift_kernel_mex", "file") == 3);
caps.TBBytesToBitsKernel = logical(exist("sixgr_tb_bytes_to_bits_kernel_mex", "file") == 3);
caps.TBBitsToBytesKernel = logical(exist("sixgr_tb_bits_to_bytes_kernel_mex", "file") == 3);
caps.TBResizeBitsKernel = logical(exist("sixgr_tb_resize_bits_kernel_mex", "file") == 3);
caps.TruthGrantHashKernel = logical(exist("sixgr_truth_grant_hash_kernel_mex", "file") == 3);
caps.FastChannelEstLSKernel = logical(exist("sixgr_channel_est_ls_kernel_mex", "file") == 3);
caps.FastChannelEstLSAllowed = false;
caps.Any = logical(caps.AWGNKernel || caps.LDPCBatchDecodeKernel || caps.StructGetKernel || ...
    caps.FFTPAPRKernel || caps.CorrelationMetricKernel || caps.FrequencyCorrectionSearchKernel || ...
    caps.FrequencyShiftKernel || caps.TBBytesToBitsKernel || caps.TBBitsToBytesKernel || ...
    caps.TBResizeBitsKernel || caps.TruthGrantHashKernel);
end

function tf = localHasParallelLicense()
try
    tf = logical(license("test", "Distrib_Computing_Toolbox"));
catch
    tf = false;
end
end

function tf = localHasParallelToolboxInstalled()
try
    tf = ~isempty(ver("parallel"));
catch
    tf = false;
end
end

function n = localSafeFeatureNumCores()
try
    n = double(feature("numcores"));
catch
    n = NaN;
end
if ~(isscalar(n) && isfinite(n) && n >= 1)
    n = NaN;
end
end

function n = localSafeMaxNumCompThreads()
try
    n = double(maxNumCompThreads);
catch
    n = NaN;
end
if ~(isscalar(n) && isfinite(n) && n >= 1)
    n = NaN;
end
end

function n = localSafeJavaAvailableProcessors()
try
    n = double(java.lang.Runtime.getRuntime.availableProcessors);
catch
    n = NaN;
end
if ~(isscalar(n) && isfinite(n) && n >= 1)
    n = NaN;
end
end

function token = localSanitizeToken(inToken, fallback)
token = lower(strtrim(char(string(inToken))));
token = regexprep(token, '[^a-z0-9]+', '_');
token = regexprep(token, '_+', '_');
token = regexprep(token, '^_+|_+$', '');
if strlength(string(token)) == 0
    token = char(string(fallback));
end
end

function p = localPortablePath(inPath)
p = replace(string(inPath), "\", "/");
end

function txt = localRelativeToRunFolder(pathIn, runFolder)
txt = localPortablePath(pathIn);
if strlength(txt) == 0
    return;
end
root = regexprep(localPortablePath(runFolder), '/+', '/');
txt = regexprep(txt, '/+', '/');
if strcmpi(txt, root)
    txt = ".";
    return;
end
rootPrefix = root + "/";
if startsWith(lower(txt), lower(rootPrefix))
    txt = extractAfter(txt, strlength(rootPrefix));
end
end

function grid = localBuildSweepGrid(snr_dB, offsets_dB, sweepEnabled, explicitValues_dB)
if nargin >= 4 && logical(sweepEnabled)
    explicitValues_dB = double(explicitValues_dB(:)).';
    explicitValues_dB = explicitValues_dB(isfinite(explicitValues_dB));
    if ~isempty(explicitValues_dB)
        grid = unique(sort(explicitValues_dB));
        return;
    end
end
snr_dB = double(snr_dB);
offsets_dB = double(offsets_dB(:)).';
offsets_dB = offsets_dB(isfinite(offsets_dB));
if isempty(offsets_dB)
    grid = snr_dB;
    return;
end
grid = unique(sort(snr_dB + offsets_dB));
end

function tf = localUsesReceiverNoiseMeasurement(cfg)
mode = lower(strtrim(string(sixgr.util.structGet(cfg, "run.noiseOperatingMode", ...
    "receiver_noise_figure_thermal_noise"))));
tf = mode == "receiver_noise_figure_thermal_noise";
end

function grid = localBuildPhysicalOperatingPointGrid(snr_dB)
snr_dB = double(snr_dB);
if ~(isscalar(snr_dB) && isfinite(snr_dB))
    grid = NaN;
else
    grid = snr_dB;
end
end

function value = ternaryDouble(condition, trueValue, falseValue)
if logical(condition)
    value = double(trueValue);
else
    value = double(falseValue);
end
end

function [y, nVar, replay, noiseOnlyWave] = localRunnerApplyPDCCHChannelAndNoise(x, cfg, tx, txInfo, snr_dB)
if nargin < 4 || ~isstruct(txInfo)
    txInfo = struct();
end
if ~isfield(txInfo, "OFDM")
    try
        txInfo.OFDM = nrOFDMInfo(tx.Carrier);
    catch
        txInfo.OFDM = struct();
    end
end
% Match the bundle's physical units/order. Applying RX RF before adding
% noise, or calibrating normalized TX against a link-budget scalar, is not
% a physical thermal-noise receiver.
sampleRateHz = localRunnerResolvePDCCHSampleRate(tx,txInfo);
[x,powerContext] = sixgr.rf.applyPowerContext(x,cfg,"DL",txInfo);
cfg = sixgr.util.structSet(cfg,"lls6g.runtimePowerContext",powerContext);
txRF = sixgr.rf.applyRFImpairmentChain(x,cfg, ...
    "SampleRateHz",sampleRateHz,"Direction","DL","MeasurementPoint","tx_output", ...
    "Endpoint","tx","StrictMutationRequired",false,"UseLegacyGlobalConfig",false, ...
    "ApplyPA",false,"ApplyADC",false);
x = cast(txRF.Waveform,"like",x);
state = sixgr.link.initWaveformTruthChannelState(cfg, tx, txInfo);
sampleRateHz = double(sixgr.util.structGet(state, "SampleRate_Hz", localRunnerResolvePDCCHSampleRate(tx, txInfo)));
y = x;
replay = struct( ...
    "ConfiguredSNR_dB", double(snr_dB), ...
    "AppliedAWGNSNR_dB", double(snr_dB), ...
    "InjectedNoiseVariance", NaN, ...
    "NoiseVarianceSource", "", ...
    "ChannelModelApplied", string(sixgr.util.structGet(cfg, "channel.model", "AWGN")), ...
    "ChannelFadingApplied", false);

[y, channelReplay, state] = sixgr.link.applyRuntimeFadingChannel(x, state); %#ok<ASGLU>
chFields = fieldnames(channelReplay);
for chIdx = 1:numel(chFields)
    replay.(chFields{chIdx}) = channelReplay.(chFields{chIdx});
end

cfgReplay = sixgr.util.structSet(cfg, "channel.snr_dB", double(snr_dB));
[y, impairmentReplay] = sixgr.link.applyWaveformImpairments(y, cfgReplay, sampleRateHz,"ApplyRFChain",false);
fields = fieldnames(impairmentReplay);
for ii = 1:numel(fields)
    replay.(fields{ii}) = impairmentReplay.(fields{ii});
end
replay.ChannelModelApplied = string(sixgr.util.structGet(cfg, "channel.model", replay.ChannelModelApplied));
replay.ChannelFadingApplied = logical(sixgr.util.structGet(replay, "ChannelFadingApplied", false)) || ...
    logical(sixgr.util.structGet(state, "UseFading", false));
desiredWaveform = y;
[y, nVar] = localRunnerAddAwgnFromReplay(y, replay, desiredWaveform);
replay.InjectedNoiseVariance = double(nVar);
if isfinite(nVar) && nVar > 0
    replay.NoiseVarianceSource = "pdcch_runner_reference_waveform_awgn";
end
[y,replay] = sixgr.link.applyCompositeReceiverFrontEnd(y,cfgReplay,sampleRateHz,replay,"Direction","DL");
replay = sixgr.link.applyCompositeFrontEndVarianceReplay(replay);
nVar = replay.InjectedNoiseVariancePostCompositeFrontEnd;
replay.TxRFStageOrder = txRF.Replay.RFStageOrder;
replay.TxRFAppliedStageCount = txRF.Replay.RFAppliedStageCount;
noiseOnlyWave = localRunnerNoiseOnlyWaveformLike(y, nVar);
end

function sampleRateHz = localRunnerResolvePDCCHSampleRate(tx, txInfo)
sampleRateHz = [];
if isstruct(txInfo)
    sampleRateHz = sixgr.util.structGet(txInfo, "OFDM.SampleRate", []);
end
if isempty(sampleRateHz) && isstruct(tx)
    try
        ofdmInfo = nrOFDMInfo(tx.Carrier);
        sampleRateHz = double(sixgr.util.structGet(ofdmInfo, "SampleRate", []));
    catch
        sampleRateHz = [];
    end
end
if isempty(sampleRateHz) || ~(isfinite(double(sampleRateHz)) && double(sampleRateHz) > 0)
    sampleRateHz = 30.72e6;
else
    sampleRateHz = double(sampleRateHz);
end
end

function [y, nVar] = localRunnerAddAwgnFromReplay(x, replay, referenceWaveform)
noiseMode = string(sixgr.util.structGet(replay, "NoiseOperatingMode", "receiver_noise_figure_thermal_noise"));
if noiseMode == "receiver_noise_figure_thermal_noise"
    nVar = localRunnerResolveThermalNoiseVariance(replay, referenceWaveform);
    if isfinite(nVar) && nVar > 0
        n = sqrt(nVar / 2) .* (randn(size(x), "like", real(x)) + 1i * randn(size(x), "like", real(x)));
        y = x + cast(n, "like", x);
        return;
    end
    y = x;
    nVar = NaN;
    return;
end
appliedSNR_dB = double(sixgr.util.structGet(replay, "AppliedAWGNSNR_dB", NaN));
nVar = localRunnerResolveConfiguredSNRNoiseVariance(referenceWaveform, appliedSNR_dB);
if isfinite(nVar) && nVar >= 0
    if nVar > 0
        n = sqrt(nVar / 2) .* (randn(size(x), "like", real(x)) + 1i * randn(size(x), "like", real(x)));
        y = x + cast(n, "like", x);
    else
        y = x;
    end
    return;
end
[y, nVar] = sixgr.util.addAwgnComplex(x, appliedSNR_dB);
end

function nVar = localRunnerResolveConfiguredSNRNoiseVariance(referenceWaveform, snr_dB)
nVar = NaN;
snr_dB = double(snr_dB);
if ~(isscalar(snr_dB) && isfinite(snr_dB)) || isempty(referenceWaveform)
    return;
end
refPower = mean(abs(double(referenceWaveform(:))).^2, "omitnan");
if ~(isfinite(refPower) && refPower >= 0)
    return;
end
nVar = refPower / max(10.^(snr_dB / 10), eps);
end

function nVar = localRunnerResolveThermalNoiseVariance(replay, referenceWaveform) %#ok<INUSD>
nVar = sixgr.link.resolveReceiverThermalNoiseVariance(replay);
end

function noiseOnlyWave = localRunnerNoiseOnlyWaveformLike(referenceWaveform, nVar)
noiseOnlyWave = zeros(size(referenceWaveform), "like", referenceWaveform);
if isfinite(double(nVar)) && double(nVar) > 0
    n = sqrt(double(nVar) / 2) .* ...
        (randn(size(referenceWaveform), "like", real(referenceWaveform)) + ...
        1i * randn(size(referenceWaveform), "like", real(referenceWaveform)));
    noiseOnlyWave = cast(n, "like", referenceWaveform);
end
end

function args = localRunnerNoiseVarArgs(nVar)
args = {};
if isnumeric(nVar) && isscalar(nVar) && isfinite(double(nVar)) && double(nVar) >= 0
    args = {"NoiseVar", double(nVar)};
end
end

function [y, nVar] = localAddAwgn(x, snr_dB)
[y, nVar] = sixgr.util.addAwgnComplex(x, snr_dB);
end

function [y, nVar] = localAddAwgnOnly(x, snr_dB)
snrLin = 10.^(snr_dB/10);
sigPow = max(mean(abs(x(:)).^2), 1);
nVar = sigPow / max(snrLin, eps);
n = sqrt(nVar/2) * (randn(size(x)) + 1i*randn(size(x)));
y = x + n;
end

function [be, bt] = localBitErrors(txBits, rxBits)
txBits = int8(txBits(:));
rxBits = int8(rxBits(:));
bt = min(numel(txBits), numel(rxBits));
if bt == 0
    be = NaN;
    return;
end
be = sum(txBits(1:bt) ~= rxBits(1:bt));
end

function val = localScalarValue(x)
if isempty(x)
    val = NaN;
elseif isscalar(x)
    val = double(x);
else
    val = double(x(1));
end
end

function nmse_dB = localUnitChannelNMSE(H)
if isempty(H)
    nmse_dB = NaN;
    return;
end
e = H(:) - 1;
nmse = mean(abs(e).^2) / max(mean(abs(ones(size(e))).^2), eps);
nmse_dB = 10*log10(max(nmse, eps));
end

function mcs = localClampMCS(mcsIn)
mcs = double(min(max(round(double(mcsIn)), 0), 27));
end

function score = localMCSScore(mcs)
score = (1 + double(mcs)) * 0.15;
end

function cls = localInterferenceClass(level_dB, thresholds_dB)
thresholds_dB = sort(double(thresholds_dB(:)).');
if isempty(thresholds_dB)
    thresholds_dB = [3 10];
end
if level_dB < thresholds_dB(1)
    cls = "low";
elseif numel(thresholds_dB) < 2 || level_dB < thresholds_dB(2)
    cls = "medium";
else
    cls = "high";
end
end

function det = localDetectorChoice(conditionNumber, threshold)
if conditionNumber >= threshold
    det = "MMSE";
else
    det = "ZF";
end
end

function bucket = localStudyBucketFromClass(researchClass)
researchClass = lower(string(researchClass));
if any(researchClass == ["baseline_benchmark", "agreed_starting_point"])
    bucket = "baseline";
elseif any(researchClass == ["study_item_candidate", "optional_research_experiment"])
    bucket = "open_study";
else
    bucket = "unclassified";
end
end

function status = localAggregateScenarioStatus(result)
status = struct();
status.RunCompletion = "completed";
status.RunCompleted = true;
status.ResultOk = logical(sixgr.util.structGet(result, "Ok", false));
status.PartialOk = false;
status.ArtifactsGenerated = true;
status.ArtifactsWritten = true;
status.ArtifactCompletenessOk = false;
status.RequiredCaseCount = 1;
status.RequiredFailureCount = double(~status.ResultOk);
status.OptionalPrunedCount = 0;
status.RequiredFailedCases = strings(0, 1);
status.OptionalPrunedCases = strings(0, 1);
status.StatusAuthority = "scenario_status_aggregation_v1";
status.StatusNotes = "";
status.ProfileReportedOk = logical(sixgr.util.structGet(result, "Ok", false));
status.AuthoritativeStatusSource = "result.Ok";
status.RuntimeTruthContractOk = false;
status.TruthContractOk = false;
status.StandardsConformanceOk = false;
status.ScenarioObjectiveOk = false;
status.ConfiguredEffectiveOk = false;
status.ConfiguredEffectivePolicyOk = false;
status.ConfiguredEffectiveSupplementalEvaluated = false;
status.MandatorySubsystemsOk = false;
status.ActiveIssueGateOk = false;
status.KpiConsistencyOk = false;
status.StrictAnchorEligible = false;
status.StrictAnchorPass = false;
status.ResultStatusReason = "root_gates_not_evaluated";
status.ActiveMandatoryIssueCount = 0;
status.ActiveCriticalIssueCount = 0;
status.ActiveHighIssueCount = 0;
status.ActiveMediumIssueCount = 0;
status.RoundtripMismatchCount = 0;
status.RequiredRuntimeEvidenceMissingCount = 0;
status.StrictTruthFailureCount = 0;
status.StrictProxyGuardFailureCount = 0;
status.CanonicalArtifactGapCount = 0;
status.RuntimeTruthContractFailures = strings(0, 1);
status.VisualArtifactIntegrityOk = false;
status.VisualArtifactIntegrityFailureCount = 1;
status.VisualArtifactIntegrityFailures = "visual_artifact_integrity:not_evaluated";
status.VisualArtifactGateOk = false;
status.VisualArtifactGateRequired = false;
status.VisualArtifactGateStatus = "NOT_EVALUATED";
status.DuplicateArtifactGateOk = false;
status.DuplicateArtifactGateStatus = "NOT_EVALUATED";
status.PublicationQualified = false;
status.PublicationQualificationStatus = "NOT_EVALUATED";
status.BrowserPublicationRequired = false;
status.BrowserPublished = false;
status.BrowserPublicationStatus = "NOT_EVALUATED";
status.BrowserPublicationFailureReason = "";
status.ArtifactContractRequired = false;
status.ArtifactContractExecuted = false;
status.ArtifactContractGateOk = true;
status.ArtifactContractStatus = "NOT_APPLICABLE";
status.ArtifactContractCount = 0;
status.ArtifactContractFailureCount = 0;
status.ArtifactContractRequiredFailureCount = 0;
status.ArtifactContractAuditPath = "";
status.ArtifactContractFailurePath = "";
status.ArtifactContractErrorIdentifier = "";
status.ArtifactContractErrorMessage = "";
status.CausalPHYChainAuditRequired = false;
status.CausalPHYChainAuditExecuted = false;
status.CausalPHYChainAuditOk = true;
status.CausalPHYChainAuditFailureCount = 0;
status.CausalPHYChainAuditFailures = strings(0, 1);
status.WarningCount = 0;
status.FailingCaseCount = 0;
status.CaseOk = logical(status.ResultOk);
status.ErrorSource = "";
status.ErrorIdentifier = "";
status.ErrorMessage = "";

if isstruct(result) && isfield(result, "Link")
    [status.ResultOk, status.RequiredCaseCount, status.RequiredFailureCount, ...
        status.RequiredFailedCases, status.OptionalPrunedCount, status.OptionalPrunedCases, ...
        status.StatusNotes, status.AuthoritativeStatusSource, status.WarningCount, ...
        status.ErrorSource, status.ErrorIdentifier, status.ErrorMessage] = localAggregateWaveformLinkStatus(result.Link, status.ProfileReportedOk);
end

mimoEvidence = sixgr.util.structGet(result, ...
    "StrictSupplemental.MIMO",struct());
if isstruct(mimoEvidence) && ~isempty(fieldnames(mimoEvidence))
    status.ConfiguredEffectiveSupplementalEvaluated = true;
    status.ConfiguredEffectiveOk = logical(sixgr.util.structGet( ...
        mimoEvidence,"StrictOk",sixgr.util.structGet(mimoEvidence,"Ok",false)));
    if ~status.ConfiguredEffectiveOk
        status.StatusNotes = localJoinStatusNotes(status.StatusNotes, ...
            "Configured/effective status failed because strict runtime MIMO evidence did not match the configured rank/antenna execution contract.");
    end
end

status.FailingCaseCount = double(numel(string(status.RequiredFailedCases)));
status.CaseOk = status.FailingCaseCount == 0;
if ~logical(status.ResultOk) && status.RunCompletion == "completed"
    status.RunCompletion = "completed_with_failures";
end
status.RunCompleted = any(string(status.RunCompletion) == ["completed", "completed_with_failures"]);
status.ArtifactsWritten = logical(status.ArtifactsGenerated);
status.PartialOk = logical(status.ArtifactsGenerated) && ~logical(status.ResultOk);
end

function status = localApplyRuntimeTruthContract(status, result, scfg, cfg, runFolder)
try
    verdict = sixgr.truth.evaluateLLSRuntimeTruthContract(runFolder, scfg, cfg, "Result", result);
catch ME
    localDBLog("ERROR", ...
        "Runtime truth contract evaluator failed closed: %s | %s", ...
        char(string(ME.identifier)), char(string(ME.message)));
    verdict = struct();
    verdict.Ok = false;
    verdict.RuntimeTruthContractOk = false;
    verdict.RoundtripMismatchCount = 0;
    verdict.RequiredRuntimeEvidenceMissingCount = 1;
    verdict.StrictTruthFailureCount = 1;
    verdict.StrictProxyGuardFailureCount = 0;
    verdict.CanonicalArtifactGapCount = 0;
    verdict.Failures = "runtime_truth_contract_evaluator_error:" + string(ME.identifier);
    verdict.EvaluatorErrorIdentifier = string(ME.identifier);
    verdict.EvaluatorErrorMessage = string(ME.message);
end

status.StatusAuthority = "scenario_status_aggregation_v2_runtime_truth_contract";
status.RuntimeTruthContractOk = logical(sixgr.util.structGet(verdict, "RuntimeTruthContractOk", sixgr.util.structGet(verdict, "Ok", false)));
status.TruthContractOk = logical(status.RuntimeTruthContractOk);
status.RoundtripMismatchCount = double(sixgr.util.structGet(verdict, "RoundtripMismatchCount", 0));
status.RequiredRuntimeEvidenceMissingCount = double(sixgr.util.structGet(verdict, "RequiredRuntimeEvidenceMissingCount", 0));
status.StrictTruthFailureCount = double(sixgr.util.structGet(verdict, "StrictTruthFailureCount", 0));
status.StrictProxyGuardFailureCount = double(sixgr.util.structGet(verdict, "StrictProxyGuardFailureCount", 0));
status.CanonicalArtifactGapCount = double(sixgr.util.structGet(verdict, "CanonicalArtifactGapCount", 0));
status.RuntimeTruthContractFailures = string(sixgr.util.structGet(verdict, "Failures", strings(0, 1)));
status.RuntimeTruthContractFailures = status.RuntimeTruthContractFailures(:);
details = sixgr.util.structGet(verdict, "CheckDetails", struct());
issueRegistry = sixgr.util.structGet(details, "IssueRegistry", struct());
scenarioObjective = sixgr.util.structGet(details, "ScenarioObjective", struct());
rootResultStatus = sixgr.util.structGet(verdict, "ResultStatus", struct());
rootResultOk = logical(sixgr.util.structGet(rootResultStatus, "ResultOk", false));
status.ArtifactsWritten = logical(sixgr.util.structGet(rootResultStatus, ...
    "ArtifactsWritten", status.ArtifactsGenerated));
status.ArtifactCompletenessOk = logical(sixgr.util.structGet(rootResultStatus, ...
    "ArtifactCompletenessOk", false));
status.ActiveMandatoryIssueCount = double(sixgr.util.structGet(issueRegistry, "BlockingIssueCount", 0));
status.ActiveCriticalIssueCount = double(sixgr.util.structGet(issueRegistry, "ActiveCriticalCount", 0));
status.ActiveHighIssueCount = double(sixgr.util.structGet(issueRegistry, "ActiveHighCount", 0));
status.ActiveMediumIssueCount = double(sixgr.util.structGet(issueRegistry, "ActiveMediumCount", 0));
status.ScenarioObjectiveOk = logical(sixgr.util.structGet(rootResultStatus, "ScenarioObjectiveOk", ...
    sixgr.util.structGet(scenarioObjective, "ScenarioObjectiveOk", false)));
status.StandardsConformanceOk = logical(sixgr.util.structGet(rootResultStatus, "StandardsConformanceOk", ...
    logical(status.RuntimeTruthContractOk) && status.ActiveMandatoryIssueCount == 0));
rootConfiguredEffectiveOk = logical(sixgr.util.structGet(rootResultStatus,"ConfiguredEffectiveOk",false));
rootConfiguredEffectivePolicyOk = logical(sixgr.util.structGet( ...
    rootResultStatus,"ConfiguredEffectivePolicyOk",false));
if logical(sixgr.util.structGet(status, "ConfiguredEffectiveSupplementalEvaluated", false))
    status.ConfiguredEffectiveOk = logical(sixgr.util.structGet(status, ...
        "ConfiguredEffectiveOk",false)) && rootConfiguredEffectiveOk;
else
    status.ConfiguredEffectiveOk = rootConfiguredEffectiveOk;
end
status.ConfiguredEffectivePolicyOk = rootConfiguredEffectivePolicyOk;
status.MandatorySubsystemsOk = logical(sixgr.util.structGet(rootResultStatus, "MandatorySubsystemsOk", ...
    false));
status.ActiveIssueGateOk = logical(sixgr.util.structGet(rootResultStatus, "ActiveIssueGateOk", ...
    false));
status.KpiConsistencyOk = logical(sixgr.util.structGet(rootResultStatus, "KpiConsistencyOk", ...
    false));
status.VisualArtifactGateOk = logical(sixgr.util.structGet(rootResultStatus, ...
    "VisualArtifactGateOk", false));
status.VisualArtifactGateRequired = logical(sixgr.util.structGet(rootResultStatus, ...
    "VisualArtifactGateRequired", false));
status.DuplicateArtifactGateOk = logical(sixgr.util.structGet(rootResultStatus, ...
    "DuplicateArtifactGateOk", false));
status.VisualArtifactGateStatus = string(sixgr.util.structGet(rootResultStatus, ...
    "VisualArtifactGateStatus", "NOT_EVALUATED"));
status.VisualArtifactFailureCount = double(sixgr.util.structGet( ...
    rootResultStatus, "VisualArtifactFailureCount", 0));
status.VisualArtifactFailureReason = string(sixgr.util.structGet( ...
    rootResultStatus, "VisualArtifactFailureReason", ""));
status.DuplicateArtifactGateStatus = string(sixgr.util.structGet(rootResultStatus, ...
    "DuplicateArtifactGateStatus", "NOT_EVALUATED"));
status.DuplicateArtifactFailureCount = double(sixgr.util.structGet( ...
    rootResultStatus, "DuplicateArtifactFailureCount", 0));
status.DuplicateArtifactFailureReason = string(sixgr.util.structGet( ...
    rootResultStatus, "DuplicateArtifactFailureReason", ""));
status.PublicationQualified = logical(sixgr.util.structGet(rootResultStatus, ...
    "PublicationQualified", false));
status.PublicationQualificationStatus = string(sixgr.util.structGet( ...
    rootResultStatus, "PublicationQualificationStatus", "NOT_EVALUATED"));
status.BrowserPublicationRequired = logical(sixgr.util.structGet( ...
    rootResultStatus, "BrowserPublicationRequired", false));
status.BrowserPublished = logical(sixgr.util.structGet(rootResultStatus, ...
    "BrowserPublished", false));
status.BrowserPublicationStatus = string(sixgr.util.structGet(rootResultStatus, ...
    "BrowserPublicationStatus", "NOT_EVALUATED"));
status.BrowserPublicationFailureReason = string(sixgr.util.structGet( ...
    rootResultStatus, "BrowserPublicationFailureReason", ""));
status.StrictAnchorEligible = logical(sixgr.util.structGet(rootResultStatus, "StrictAnchorEligible", ...
    sixgr.util.structGet(status, "StrictAnchorEligible", false)));
status.StrictAnchorPass = logical(sixgr.util.structGet(rootResultStatus, "StrictAnchorPass", ...
    false));
status.ResultStatusReason = string(sixgr.util.structGet(rootResultStatus, "ResultStatusReason", ...
    sixgr.util.structGet(status, "ResultStatusReason", "")));
roundtripStatusDetails = string(sixgr.util.structGet(verdict, "RoundtripStatusDetails", strings(0, 1)));
roundtripStatusDetails = roundtripStatusDetails(strlength(roundtripStatusDetails) > 0);
if ~isempty(roundtripStatusDetails)
    status.RuntimeTruthContractFailures = unique([status.RuntimeTruthContractFailures; roundtripStatusDetails(:)], "stable");
end

if ~logical(status.RuntimeTruthContractOk) || ~rootResultOk
    status.ResultOk = false;
    status.CaseOk = false;
    status.PartialOk = logical(status.ArtifactsGenerated);
    status.RunCompletion = "completed_with_failures";
    status.RequiredFailureCount = double(status.RequiredFailureCount) + max(1, double(status.StrictTruthFailureCount));
    status.RequiredFailedCases = unique([string(status.RequiredFailedCases(:)); status.RuntimeTruthContractFailures], "stable");
    status.FailingCaseCount = double(numel(string(status.RequiredFailedCases)));
    status.AuthoritativeStatusSource = "runtime_truth_contract";
    status.StatusNotes = localJoinStatusNotes(status.StatusNotes, ...
        "Run-level success is gated by the runtime truth contract and canonical root status; missing/proxy/mismatched evidence or root-gate failures force ResultOk=false.");
    if strlength(string(status.ErrorIdentifier)) == 0
        status.ErrorSource = "runtime_truth_contract";
        status.ErrorIdentifier = "runtime_truth_contract_failed";
        status.ErrorMessage = char(strjoin(status.RuntimeTruthContractFailures, "; "));
    end
else
    status.FailingCaseCount = double(numel(string(status.RequiredFailedCases)));
    status.CaseOk = logical(status.ResultOk) && status.FailingCaseCount == 0;
    status.PartialOk = logical(status.ArtifactsGenerated) && ~logical(status.ResultOk);
end
status.RunCompleted = any(string(status.RunCompletion) == ["completed", "completed_with_failures"]);
status.ArtifactsWritten = logical(sixgr.util.structGet(status, ...
    "ArtifactsWritten", status.ArtifactsGenerated));
end

function status = localApplyCausalPHYChainAuditStatus(status, audit)
% Fail closed when a YAML-required stage or parameter is bypassed. This is
% an execution/wiring gate, not a scientific-performance qualification: it
% proves configured authority reached exact consumers and truthful measured
% artifacts without claiming that BLER or conformance targets passed.
status.CausalPHYChainAuditRequired = logical(sixgr.util.structGet( ...
    audit, "Required", false));
status.CausalPHYChainAuditExecuted = logical(sixgr.util.structGet( ...
    audit, "Executed", false));
status.CausalPHYChainAuditOk = logical(sixgr.util.structGet( ...
    audit, "Ok", ~status.CausalPHYChainAuditRequired));
status.CausalPHYChainAuditFailureCount = double(sixgr.util.structGet( ...
    audit, "FailureCount", double(status.CausalPHYChainAuditRequired)));

failureTokens = strings(0,1);
detailT = sixgr.util.structGet(audit, "DetailTable", table());
if istable(detailT) && ~isempty(detailT) && ...
        all(ismember(["StrictPass","StageID","StageOutcome", ...
        "RequiredForScenario"], ...
        string(detailT.Properties.VariableNames)))
    failed = ~logical(detailT.StrictPass) & ...
        (logical(detailT.RequiredForScenario) | ...
        string(detailT.StageOutcome) == "DISABLED_BUT_CALLED");
    failureTokens = [failureTokens; ...
        "causal_phy_stage:" + string(detailT.StageID(failed)) + ":" + ...
        string(detailT.StageOutcome(failed))]; %#ok<AGROW>
end
bindingT = sixgr.util.structGet(audit, "ParameterBindingTable", table());
if istable(bindingT) && ~isempty(bindingT) && ...
        all(ismember(["StrictPass","ParameterID","Status", ...
        "RequiredForScenario"], ...
        string(bindingT.Properties.VariableNames)))
    failed = ~logical(bindingT.StrictPass) & logical(bindingT.RequiredForScenario);
    failureTokens = [failureTokens; ...
        "causal_phy_parameter:" + string(bindingT.ParameterID(failed)) + ":" + ...
        string(bindingT.Status(failed))]; %#ok<AGROW>
end
failureTokens = unique(failureTokens(strlength(failureTokens) > 0), "stable");
if status.CausalPHYChainAuditRequired && isempty(failureTokens) && ...
        ~status.CausalPHYChainAuditOk
    failureTokens = "causal_phy_chain_audit:required_gate_failed";
end
status.CausalPHYChainAuditFailures = failureTokens;

if ~status.CausalPHYChainAuditRequired || status.CausalPHYChainAuditOk
    return;
end
status.ResultOk = false;
status.CaseOk = false;
status.PartialOk = logical(status.ArtifactsGenerated);
status.RunCompletion = "completed_with_failures";
status.ScenarioObjectiveOk = false;
status.RequiredFailureCount = double(status.RequiredFailureCount) + ...
    max(1, status.CausalPHYChainAuditFailureCount);
status.RequiredFailedCases = unique([string(status.RequiredFailedCases(:)); ...
    failureTokens(:)], "stable");
status.FailingCaseCount = double(numel(string(status.RequiredFailedCases)));
status.AuthoritativeStatusSource = "yaml_causal_phy_chain_audit";
status.StatusNotes = localJoinStatusNotes(status.StatusNotes, ...
    "YAML causal PHY-chain audit failed: an enabled stage was not called, a disabled stage executed, configured and runtime authority differed, or required measured truth evidence was absent.");
if strlength(string(status.ErrorIdentifier)) == 0
    status.ErrorSource = "yaml_causal_phy_chain_audit";
    status.ErrorIdentifier = "causal_phy_chain_audit_failed";
    status.ErrorMessage = char(strjoin(failureTokens, "; "));
end
end

function status = localApplyVisualArtifactIntegrityStatus(status, visualIntegrity)
required = logical(sixgr.util.structGet(status, "VisualArtifactGateRequired", false));
if ~(istable(visualIntegrity) && ~isempty(visualIntegrity) && ismember("IntegrityOk", string(visualIntegrity.Properties.VariableNames)))
    status.VisualArtifactIntegrityOk = false;
    status.VisualArtifactIntegrityFailureCount = 1;
    status.VisualArtifactIntegrityFailures = "visual_artifact_integrity:not_evaluated:required_integrity_table_missing_or_empty";
    if ~required
        return;
    end
    status.ResultOk = false;
    status.CaseOk = false;
    status.PartialOk = logical(status.ArtifactsGenerated);
    status.RunCompletion = "completed_with_failures";
    status.RequiredFailureCount = double(status.RequiredFailureCount) + 1;
    status.RequiredFailedCases = unique([string(status.RequiredFailedCases(:)); ...
        status.VisualArtifactIntegrityFailures(:)], "stable");
    status.FailingCaseCount = double(numel(string(status.RequiredFailedCases)));
    status.AuthoritativeStatusSource = "visual_artifact_integrity";
    status.StatusNotes = localJoinStatusNotes(status.StatusNotes, ...
        "Required visual artifact integrity evidence was missing or empty; publication fails closed.");
    if strlength(string(status.ErrorIdentifier)) == 0
        status.ErrorSource = "visual_artifact_integrity";
        status.ErrorIdentifier = "visual_artifact_integrity_not_evaluated";
        status.ErrorMessage = char(status.VisualArtifactIntegrityFailures);
    end
    return;
end
okMask = logical(visualIntegrity.IntegrityOk);
bad = visualIntegrity(~okMask, :);
status.VisualArtifactIntegrityOk = isempty(bad);
status.VisualArtifactIntegrityFailureCount = double(height(bad));
status.VisualArtifactIntegrityFailures = localVisualArtifactFailureStrings(bad);
if isempty(bad) || ~required
    return;
end
status.ResultOk = false;
status.CaseOk = false;
status.PartialOk = logical(status.ArtifactsGenerated);
status.RunCompletion = "completed_with_failures";
status.RequiredFailureCount = double(status.RequiredFailureCount) + double(height(bad));
status.RequiredFailedCases = unique([string(status.RequiredFailedCases(:)); status.VisualArtifactIntegrityFailures(:)], "stable");
status.FailingCaseCount = double(numel(string(status.RequiredFailedCases)));
status.AuthoritativeStatusSource = "visual_artifact_integrity";
status.StatusNotes = localJoinStatusNotes(status.StatusNotes, ...
    "Run-level success is gated by visual artifact byte/signature integrity; extension/mime mismatches or stale suppressed PNGs force ResultOk=false.");
if strlength(string(status.ErrorIdentifier)) == 0
    status.ErrorSource = "visual_artifact_integrity";
    status.ErrorIdentifier = "visual_artifact_integrity_failed";
        status.ErrorMessage = char(strjoin(status.VisualArtifactIntegrityFailures, "; "));
    end
end

function audit = localRunFixedSNRSweepAuditIfNeeded(runFolder, scfg, cfg)
audit = struct( ...
    "Required", false, ...
    "Executed", false, ...
    "Ok", true, ...
    "Status", "not_required", ...
    "FailureCount", 0, ...
    "WarningCount", 0, ...
    "FailureCodes", strings(0, 1), ...
    "WarningCodes", strings(0, 1), ...
    "Identifier", "", ...
    "Message", "");

runClass = lower(strtrim(string(localRunnerScenarioGet(scfg, cfg, "validation.RunClass", ...
    localRunnerScenarioGet(scfg, cfg, "validation.run_class", "")))));
fixedOnly = logical(localRunnerScenarioGetBool(scfg, cfg, "sweeps_and_matrix.fixed_link_calibration.only", ...
    localRunnerScenarioGetBool(scfg, cfg, "canonical_control.run.fixed_link_campaign_only", false)));
required = runClass == "fixed_snr_sweep_lls" || ...
    logical(localRunnerScenarioGetBool(scfg, cfg, "validation.fixed_snr_sweep_required", false)) || ...
    fixedOnly;
audit.Required = logical(required);
if ~audit.Required
    return;
end

try
    audit = sixgr.validation.auditFixedSNRSweepRun(runFolder, "Strict", false, "WriteOutputs", true);
    audit.Required = true;
    audit.Executed = true;
catch ME
    audit.Required = true;
    audit.Executed = false;
    audit.Ok = false;
    audit.Status = "error";
    audit.FailureCount = 1;
    audit.WarningCount = 0;
    audit.FailureCodes = "fixed_snr_sweep_audit_error";
    audit.WarningCodes = strings(0, 1);
    audit.Identifier = string(ME.identifier);
    audit.Message = string(ME.message);
end
end

function audit = localRunGeometryScenarioAuditIfNeeded(runFolder, scfg, cfg)
audit = sixgr.validation.runGeometryScenarioAuditIfNeeded(runFolder, scfg, cfg);
end

function plotInfo = localRunGeometryScenarioPlotsIfNeeded(runFolder, geometryAudit, scfg, cfg)
plotInfo = struct( ...
    "Required", false, ...
    "Executed", false, ...
    "Ok", true, ...
    "Status", "not_required", ...
    "GeneratedPlots", strings(0, 1), ...
    "Identifier", "", ...
    "Message", "");

required = localGeometryEvidenceRequired(scfg, cfg);
plotInfo.Required = logical(required);
if ~plotInfo.Required || ~logical(sixgr.util.structGet(geometryAudit, "Ok", true)) || ~usejava("jvm")
    if plotInfo.Required && ~usejava("jvm")
        plotInfo.Status = "skipped_no_jvm";
        plotInfo.Ok = false;
        plotInfo.Identifier = "geometry_plot_jvm_unavailable";
        plotInfo.Message = "Geometry evidence plots were skipped because the MATLAB JVM is unavailable.";
    end
    return;
end

try
    plotInfo = sixgr.visual.plotGeometryScenarioEvidence(runFolder);
    plotInfo.Required = true;
    plotInfo.Executed = true;
    plotInfo.Ok = true;
    plotInfo.Status = "plotted";
catch ME
    plotInfo.Required = true;
    plotInfo.Executed = false;
    plotInfo.Ok = false;
    plotInfo.Status = "error";
    plotInfo.GeneratedPlots = strings(0, 1);
    plotInfo.Identifier = string(ME.identifier);
    plotInfo.Message = string(ME.message);
end
end

function required = localGeometryEvidenceRequired(scfg, cfg)
% Geometry evidence follows the resolved runtime launch authority.  A run
% may deliberately use an adaptive diagnostic run class while still
% executing position, pathloss, angle, mobility, and Doppler models.  Such
% a run must not silently skip the audit/plots merely because its run-class
% label is not the dedicated geometry-campaign label.
required = sixgr.validation.geometryEvidenceRequired(scfg, cfg);
end

function audit = localRunArtifactAuditIfNeeded(runFolder, scfg, cfg)
audit = struct( ...
    "Required", false, ...
    "Executed", false, ...
    "Ok", true, ...
    "Status", "not_required", ...
    "FailureCount", 0, ...
    "WarningCount", 0, ...
    "FailureCodes", strings(0, 1), ...
    "WarningCodes", strings(0, 1), ...
    "Identifier", "", ...
    "Message", "");

strictAudit = logical(localRunnerScenarioGetBool(scfg, cfg, "validation.strict_after_run_artifact_audit", false));
emitPlaceholders = logical(localRunnerScenarioGetBool(scfg, cfg, "output.emit_placeholder_artifacts", false));
required = localIsBrowserLaunchedScenario(scfg, cfg) && (strictAudit || ~emitPlaceholders);
audit.Required = logical(required);

try
    audit = sixgr.validation.auditRunArtifacts(runFolder, ...
        "Strict", false, ...
        "FailOnEmptyRequiredCSV", true, ...
        "FailOnBlankRequiredImage", true, ...
        "WriteOutputs", true);
    % Always refresh the exact terminal CSV/image inventory.  Whether its
    % findings are a mandatory scenario gate remains configuration-owned.
    audit.Required = logical(required);
    audit.Executed = true;
catch ME
    audit.Required = logical(required);
    audit.Executed = false;
    audit.Ok = false;
    audit.Status = "error";
    audit.FailureCount = 1;
    audit.WarningCount = 0;
    audit.FailureCodes = "recursive_artifact_audit_error";
    audit.WarningCodes = strings(0, 1);
    audit.Identifier = string(ME.identifier);
    audit.Message = string(ME.message);
end
end

function evidence = localRefreshFinalQualificationEvidence(runFolder, scfg, cfg)
% Phase-7 consumes terminal CSV/image audits and plot lineage.  Its initial
% pass necessarily runs before browser contract materialization so those
% tables exist for the browser.  The terminal caller first refreshes the
% recursive filesystem audit and only then rebuilds this scientific
% reducer.  Missing campaigns, samples, FRC references or determinism
% evidence continue to fail closed in the same evaluator.
phase7 = sixgr.analytics.buildPhase7ReadinessArtifacts(scfg, runFolder);
publication = sixgr.analytics.evaluatePublicationReadinessGates(cfg, runFolder);
evidence = struct( ...
    "Phase7", phase7, ...
    "PublicationReadiness", publication, ...
    "RefreshedAfterMaterialization", true, ...
    "EvidencePolicy", "terminal_filesystem_no_proxy_no_missing_gate_override");
end

function out = localRunIndependentReferenceQualification(runFolder, scfg, cfg)
base = "validation.independent_reference_qualification.";
enabled = logical(localRunnerScenarioGetBool(scfg, cfg, base + "enabled", false));
profile = lower(strtrim(string(localRunnerScenarioGet(scfg, cfg, ...
    base + "profile", "full"))));
if ~ismember(profile, ["full","diagnostic"])
    error("sixgr:lls6g:InvalidFRCQualificationProfile", ...
        "validation.independent_reference_qualification.profile must be full or diagnostic.");
end
out = struct("Enabled", enabled, "Profile", profile, ...
    "AllPassed", false, "OutputPath", "", "Table", table());
if ~enabled
    localPublishReferenceQualificationConfig(base + "enabled", false);
    return;
end

entryIds = string(localRunnerScenarioGet(scfg, cfg, ...
    base + "entry_ids", strings(0,1)));
entryIds = entryIds(:);
entryIds = entryIds(strlength(strtrim(entryIds)) > 0);
if isempty(entryIds)
    error("sixgr:lls6g:MissingFRCQualificationEntries", ...
        "Enabled independent FRC qualification requires nonempty entry_ids in YAML.");
end

args = { ...
    "Profile", profile, ...
    "EntryIds", entryIds, ...
    "EntrySampling", localRunnerScenarioGet( ...
        scfg, cfg, base + "sampling_by_entry", {}), ...
    "Tolerance_dB", double(localRunnerScenarioGet(scfg, cfg, base + "tolerance_db", 1.0)), ...
    "ConfidenceLevel", double(localRunnerScenarioGet( ...
        scfg, cfg, base + "confidence_level", 0.95)), ...
    "RequireSymmetricRegression", logical(localRunnerScenarioGetBool( ...
        scfg, cfg, base + "require_symmetric_regression_for_production", false)), ...
    "Seed", double(localRunnerScenarioGet( ...
        scfg, cfg, base + "seed", 38104)), ...
    "ParallelWorkers", double(localRunnerScenarioGet( ...
        scfg, cfg, base + "parallel_workers", 0)), ...
    "MinimumBlockErrors", double(localRunnerScenarioGet(scfg, cfg, base + "minimum_block_errors", 100)), ...
    "Verbose", logical(localRunnerScenarioGetBool(scfg, cfg, base + "verbose", true))};
optional = [ ...
    "min_transport_blocks", "MinTransportBlocks"; ...
    "max_transport_blocks", "MaxTransportBlocks"; ...
    "batch_size", "BatchSize"; ...
    "max_confidence_half_width", "MaxConfidenceHalfWidth"];
for index = 1:size(optional,1)
    value = localRunnerScenarioGet(scfg, cfg, base + optional(index,1), []);
    if ~isempty(value)
        args(end+1:end+2) = {char(optional(index,2)), double(value)}; %#ok<AGROW>
        localPublishReferenceQualificationConfig( ...
            base + optional(index,1), double(value));
    end
end
localPublishReferenceQualificationConfig(base + "enabled", true);
localPublishReferenceQualificationConfig(base + "profile", profile);
localPublishReferenceQualificationConfig(base + "entry_ids", entryIds);
localPublishReferenceQualificationConfig(base + "sampling_by_entry", ...
    localRunnerScenarioGet(scfg, cfg, base + "sampling_by_entry", {}));
localPublishReferenceQualificationConfig(base + "tolerance_db", args{8});
localPublishReferenceQualificationConfig(base + "confidence_level", args{10});
localPublishReferenceQualificationConfig(base + "minimum_block_errors", ...
    localRunnerScenarioGet(scfg, cfg, base + "minimum_block_errors", 100));
localPublishReferenceQualificationConfig(base + "parallel_workers", ...
    localRunnerScenarioGet(scfg, cfg, base + "parallel_workers", 0));
localPublishReferenceQualificationConfig( ...
    base + "require_symmetric_regression_for_production", ...
    localRunnerScenarioGetBool(scfg, cfg, ...
    base + "require_symmetric_regression_for_production", false));
localPublishReferenceQualificationConfig(base + "seed", ...
    localRunnerScenarioGet(scfg, cfg, base + "seed", 38104));
localPublishReferenceQualificationConfig(base + "verbose", ...
    localRunnerScenarioGetBool(scfg, cfg, base + "verbose", true));
qualification = sixgr.conformance.runReferenceQualification(runFolder, args{:});
out = qualification;
out.Enabled = true;
end

function localPublishReferenceQualificationConfig(parameterId, value)
sixgr.config.publishConfigApplicationEvidence("record", ...
    parameterId, "Truth_Contract", parameterId, ...
    "sixgr.lls6g.runners.runSingle.localRunIndependentReferenceQualification", ...
    value, "RuntimeObjectType", "frc_qualification_runtime_options", ...
    "RuntimeObjectPath", parameterId, ...
    "ApplicationScope", "independent_frc_campaign");
end

function value = localRunnerScenarioGet(scfg, cfg, pathValue, defaultValue)
value = defaultValue;
try
    if isobject(scfg) && ismethod(scfg, "get")
        % Only let the scenario object win when it actually owns this
        % path.  Internal-only resolved fields must remain discoverable in
        % cfg instead of being hidden behind the caller's default value.
        if ~ismethod(scfg, "has") || scfg.has(pathValue)
            value = scfg.get(pathValue, defaultValue);
            return;
        end
    end
catch
end
try
    value = sixgr.util.structGet(scfg, pathValue, defaultValue);
    if ~isequaln(value, defaultValue)
        return;
    end
catch
end
try
    value = sixgr.util.structGet(cfg, pathValue, defaultValue);
catch
    value = defaultValue;
end
end

function value = localRunnerScenarioGetBool(scfg, cfg, pathValue, defaultValue)
raw = localRunnerScenarioGet(scfg, cfg, pathValue, defaultValue);
if islogical(raw)
    value = logical(raw);
elseif isnumeric(raw)
    value = raw ~= 0;
else
    token = lower(strtrim(string(raw)));
    value = any(token == ["true", "1", "yes", "on"]);
end
if isempty(value)
    value = defaultValue;
end
end

function tf = localIsBrowserLaunchedScenario(scfg, cfg)
tf = false;
sourceKind = lower(strtrim(string(localRunnerScenarioGet(scfg, cfg, "SourceKind", ...
    localRunnerScenarioGet(scfg, cfg, "meta.SourceKind", ...
    localRunnerScenarioGet(scfg, cfg, "config_inheritance.provenance.source_kind", ...
    localRunnerScenarioGet(scfg, cfg, "lls6g.resolvedConfig.config_inheritance.provenance.source_kind", "")))))));
if sourceKind == "browser_runtime_overlay"
    tf = true;
    return;
end

paths = strings(0, 1);
configPath = "";
sourceFiles = strings(0, 1);
if isobject(scfg)
    try
        configPath = string(scfg.ConfigPath);
    catch
        configPath = "";
    end
    try
        sourceFiles = string(scfg.SourceFiles(:));
    catch
        sourceFiles = strings(0, 1);
    end
end
if strlength(strtrim(configPath)) == 0
    configPath = string(localRunnerScenarioGet(scfg, cfg, "ConfigPath", ""));
end
if strlength(strtrim(configPath)) > 0
    paths(end + 1, 1) = configPath; %#ok<AGROW>
end
if isempty(sourceFiles)
    sourceFiles = localRunnerScenarioGet(scfg, cfg, "SourceFiles", strings(0, 1));
    sourceFiles = string(sourceFiles(:));
end
sourceFiles = sourceFiles(strlength(strtrim(sourceFiles)) > 0);
paths = [paths; sourceFiles]; %#ok<AGROW>
for i = 1:numel(paths)
    if localIsBrowserOverlayPath(paths(i))
        tf = true;
        return;
    end
end
end

function tf = localIsBrowserOverlayPath(candidate)
candidate = string(candidate);
tf = false;
if strlength(candidate) == 0
    return;
end
[~, name, ext] = fileparts(char(candidate));
name = string(name);
ext = string(ext);
tf = startsWith(name, "__web_runtime_", "IgnoreCase", true) && any(strcmpi(ext, [".yaml", ".yml", ".json"]));
end

function status = localApplyFixedSNRSweepAuditStatus(status, audit)
status.FixedSNRSweepAuditRequired = logical(sixgr.util.structGet(audit, "Required", false));
status.FixedSNRSweepAuditExecuted = logical(sixgr.util.structGet(audit, "Executed", false));
status.FixedSNRSweepAuditOk = logical(sixgr.util.structGet(audit, "Ok", true));
status.FixedSNRSweepAuditFailureCount = double(sixgr.util.structGet(audit, "FailureCount", 0));
status.FixedSNRSweepAuditWarningCount = double(sixgr.util.structGet(audit, "WarningCount", 0));
status.FixedSNRSweepAuditFailures = string(sixgr.util.structGet(audit, "FailureCodes", strings(0, 1)));
status.FixedSNRSweepAuditFailures = status.FixedSNRSweepAuditFailures(:);
if ~logical(status.FixedSNRSweepAuditRequired) || logical(status.FixedSNRSweepAuditOk)
    return;
end

failureTokens = status.FixedSNRSweepAuditFailures;
if isempty(failureTokens)
    identifier = string(sixgr.util.structGet(audit, "Identifier", ""));
    if strlength(identifier) > 0
        failureTokens = "fixed_snr_sweep_audit:" + identifier;
    else
        failureTokens = "fixed_snr_sweep_audit_failed";
    end
else
    failureTokens = "fixed_snr_sweep_audit:" + failureTokens;
end

% The sweep audit evaluates scientific objectives, sample adequacy,
% confidence and plot lineage after an otherwise completed waveform run.
% It must not retroactively claim that execution failed. Runtime truth,
% artifact-integrity and subsystem reducers independently fail ResultOk for
% missing/corrupt/proxy evidence. Keep this outcome in the objective and
% production-qualification dimensions instead.
status.ScenarioObjectiveOk = false;
status.StatusNotes = localJoinStatusNotes(status.StatusNotes, ...
    "Fixed-SNR scientific objective/qualification failed without relabelling the completed truth execution as a functional failure: " + strjoin(failureTokens, "; "));
end

function status = localApplyGeometryScenarioAuditStatus(status, audit)
status.GeometryScenarioAuditRequired = logical(sixgr.util.structGet(audit, "Required", false));
status.GeometryScenarioAuditExecuted = logical(sixgr.util.structGet(audit, "Executed", false));
status.GeometryScenarioAuditOk = logical(sixgr.util.structGet(audit, "Ok", true));
status.GeometryScenarioAuditFailureCount = double(sixgr.util.structGet(audit, "FailureCount", 0));
status.GeometryScenarioAuditWarningCount = double(sixgr.util.structGet(audit, "WarningCount", 0));
status.GeometryScenarioAuditFailures = string(sixgr.util.structGet(audit, "FailureCodes", strings(0, 1)));
status.GeometryScenarioAuditFailures = status.GeometryScenarioAuditFailures(:);
if ~logical(status.GeometryScenarioAuditRequired) || logical(status.GeometryScenarioAuditOk)
    return;
end

failureTokens = status.GeometryScenarioAuditFailures;
if isempty(failureTokens)
    identifier = string(sixgr.util.structGet(audit, "Identifier", ""));
    if strlength(identifier) > 0
        failureTokens = "geometry_scenario_audit:" + identifier;
    else
        failureTokens = "geometry_scenario_audit_failed";
    end
else
    failureTokens = "geometry_scenario_audit:" + failureTokens;
end

status.ResultOk = false;
status.CaseOk = false;
status.PartialOk = logical(status.ArtifactsGenerated);
status.RunCompletion = "completed_with_failures";
status.ScenarioObjectiveOk = false;
status.RequiredFailureCount = double(status.RequiredFailureCount) + max(1, double(status.GeometryScenarioAuditFailureCount));
status.RequiredFailedCases = unique([string(status.RequiredFailedCases(:)); failureTokens(:)], "stable");
status.FailingCaseCount = double(numel(string(status.RequiredFailedCases)));
status.AuthoritativeStatusSource = "geometry_scenario_audit";
status.StatusNotes = localJoinStatusNotes(status.StatusNotes, ...
    "Run-level success is gated by the geometry scenario audit; empty trajectory evidence, cell/UE topology mismatches, pathloss or propagation-delay gaps, Doppler mismatches, missing serving-cell lineage, or missing measured SINR rows force ResultOk=false.");
if strlength(string(status.ErrorIdentifier)) == 0
    status.ErrorSource = "geometry_scenario_audit";
    status.ErrorIdentifier = "geometry_scenario_audit_failed";
    status.ErrorMessage = char(strjoin(failureTokens, "; "));
end
end

function status = localApplyArtifactAuditStatus(status, audit)
status.ArtifactAuditRequired = logical(sixgr.util.structGet(audit, "Required", false));
status.ArtifactAuditExecuted = logical(sixgr.util.structGet(audit, "Executed", false));
status.ArtifactAuditOk = logical(sixgr.util.structGet(audit, "Ok", true));
status.ArtifactAuditFailureCount = double(sixgr.util.structGet(audit, "FailureCount", 0));
status.ArtifactAuditWarningCount = double(sixgr.util.structGet(audit, "WarningCount", 0));
status.ArtifactAuditFailures = string(sixgr.util.structGet(audit, "FailureCodes", strings(0, 1)));
status.ArtifactAuditFailures = status.ArtifactAuditFailures(:);
if ~logical(status.ArtifactAuditRequired) || logical(status.ArtifactAuditOk)
    return;
end

failureTokens = status.ArtifactAuditFailures;
if isempty(failureTokens)
    identifier = string(sixgr.util.structGet(audit, "Identifier", ""));
    if strlength(identifier) > 0
        failureTokens = "artifact_audit:" + identifier;
    else
        failureTokens = "artifact_audit_failed";
    end
else
    failureTokens = "artifact_audit:" + failureTokens;
end

status.ResultOk = false;
status.CaseOk = false;
status.PartialOk = logical(status.ArtifactsGenerated);
status.RunCompletion = "completed_with_failures";
status.ScenarioObjectiveOk = false;
status.RequiredFailureCount = double(status.RequiredFailureCount) + max(1, double(status.ArtifactAuditFailureCount));
status.RequiredFailedCases = unique([string(status.RequiredFailedCases(:)); failureTokens(:)], "stable");
status.FailingCaseCount = double(numel(string(status.RequiredFailedCases)));
status.AuthoritativeStatusSource = "recursive_artifact_audit";
status.StatusNotes = localJoinStatusNotes(status.StatusNotes, ...
    "Browser-launched LLS runs with strict artifact audit enabled fail closed when required CSVs are empty or missing, required plots are blank, or recursively audited artifacts report structural problems.");
if strlength(string(status.ErrorIdentifier)) == 0
    status.ErrorSource = "recursive_artifact_audit";
    status.ErrorIdentifier = "recursive_artifact_audit_failed";
    status.ErrorMessage = char(strjoin(failureTokens, "; "));
end
end

function failures = localVisualArtifactFailureStrings(T)
if ~(istable(T) && ~isempty(T))
    failures = strings(0, 1);
    return;
end
paths = localStatusColumnAsString(T, "ArtifactPath", height(T));
codes = localStatusColumnAsString(T, "FailureCode", height(T));
reasons = localStatusColumnAsString(T, "FailureReason", height(T));
failures = "visual_artifact_integrity:" + codes + ":" + paths;
hasReason = strlength(strtrim(reasons)) > 0;
failures(hasReason) = failures(hasReason) + ":" + reasons(hasReason);
failures = unique(failures(:), "stable");
end

function values = localStatusColumnAsString(T, name, n)
if istable(T) && ismember(string(name), string(T.Properties.VariableNames))
    values = string(T.(char(name)));
else
    values = strings(n, 1);
end
values = values(:);
if numel(values) < n
    values(end+1:n, 1) = "";
end
end

function result = localApplyScenarioStatus(result, scenarioStatus)
result.ProfileReportedOk = logical(sixgr.util.structGet(result, "Ok", true));
result.Ok = logical(scenarioStatus.ResultOk);
result.RunCompletion = char(string(scenarioStatus.RunCompletion));
result.RunCompleted = logical(sixgr.util.structGet(scenarioStatus, "RunCompleted", false));
result.PartialOk = logical(scenarioStatus.PartialOk);
result.ArtifactsGenerated = logical(scenarioStatus.ArtifactsGenerated);
result.ArtifactsWritten = logical(sixgr.util.structGet(scenarioStatus, "ArtifactsWritten", scenarioStatus.ArtifactsGenerated));
result.RequiredCaseCount = double(scenarioStatus.RequiredCaseCount);
result.RequiredFailureCount = double(scenarioStatus.RequiredFailureCount);
result.OptionalPrunedCount = double(scenarioStatus.OptionalPrunedCount);
result.RequiredFailedCases = string(scenarioStatus.RequiredFailedCases(:));
result.OptionalPrunedCases = string(scenarioStatus.OptionalPrunedCases(:));
result.StatusAuthority = char(string(scenarioStatus.StatusAuthority));
result.StatusNotes = char(string(scenarioStatus.StatusNotes));
result.AuthoritativeStatusSource = char(string(scenarioStatus.AuthoritativeStatusSource));
result.RuntimeTruthContractOk = logical(scenarioStatus.RuntimeTruthContractOk);
result.TruthContractOk = logical(sixgr.util.structGet(scenarioStatus, "TruthContractOk", scenarioStatus.RuntimeTruthContractOk));
result.StandardsConformanceOk = logical(sixgr.util.structGet(scenarioStatus, "StandardsConformanceOk", scenarioStatus.RuntimeTruthContractOk));
result.ScenarioObjectiveOk = logical(sixgr.util.structGet(scenarioStatus, "ScenarioObjectiveOk", scenarioStatus.ResultOk));
result.ActiveMandatoryIssueCount = double(sixgr.util.structGet(scenarioStatus, "ActiveMandatoryIssueCount", 0));
result.ActiveCriticalIssueCount = double(sixgr.util.structGet(scenarioStatus, "ActiveCriticalIssueCount", 0));
result.ActiveHighIssueCount = double(sixgr.util.structGet(scenarioStatus, "ActiveHighIssueCount", 0));
result.ActiveMediumIssueCount = double(sixgr.util.structGet(scenarioStatus, "ActiveMediumIssueCount", 0));
result.RoundtripMismatchCount = double(scenarioStatus.RoundtripMismatchCount);
result.RequiredRuntimeEvidenceMissingCount = double(scenarioStatus.RequiredRuntimeEvidenceMissingCount);
result.StrictTruthFailureCount = double(scenarioStatus.StrictTruthFailureCount);
result.StrictProxyGuardFailureCount = double(scenarioStatus.StrictProxyGuardFailureCount);
result.CanonicalArtifactGapCount = double(scenarioStatus.CanonicalArtifactGapCount);
result.RuntimeTruthContractFailures = string(scenarioStatus.RuntimeTruthContractFailures(:));
result.VisualArtifactIntegrityOk = logical(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityOk", false));
result.VisualArtifactIntegrityFailureCount = double(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityFailureCount", 0));
result.VisualArtifactIntegrityFailures = string(sixgr.util.structGet(scenarioStatus, "VisualArtifactIntegrityFailures", strings(0, 1)));
result.VisualArtifactGateOk = logical(sixgr.util.structGet(scenarioStatus, "VisualArtifactGateOk", false));
result.VisualArtifactGateStatus = string(sixgr.util.structGet(scenarioStatus, "VisualArtifactGateStatus", "NOT_EVALUATED"));
result.DuplicateArtifactGateOk = logical(sixgr.util.structGet(scenarioStatus, "DuplicateArtifactGateOk", false));
result.DuplicateArtifactGateStatus = string(sixgr.util.structGet(scenarioStatus, "DuplicateArtifactGateStatus", "NOT_EVALUATED"));
result.PublicationQualified = logical(sixgr.util.structGet(scenarioStatus, "PublicationQualified", false));
result.PublicationQualificationStatus = string(sixgr.util.structGet(scenarioStatus, "PublicationQualificationStatus", "NOT_EVALUATED"));
result.BrowserPublicationRequired = logical(sixgr.util.structGet(scenarioStatus, "BrowserPublicationRequired", false));
result.BrowserPublished = logical(sixgr.util.structGet(scenarioStatus, "BrowserPublished", false));
result.BrowserPublicationStatus = string(sixgr.util.structGet(scenarioStatus, "BrowserPublicationStatus", "NOT_EVALUATED"));
result.ArtifactContractRequired = logical(sixgr.util.structGet(scenarioStatus, "ArtifactContractRequired", false));
result.ArtifactContractExecuted = logical(sixgr.util.structGet(scenarioStatus, "ArtifactContractExecuted", false));
result.ArtifactContractGateOk = logical(sixgr.util.structGet(scenarioStatus, "ArtifactContractGateOk", true));
result.ArtifactContractStatus = string(sixgr.util.structGet(scenarioStatus, "ArtifactContractStatus", "NOT_APPLICABLE"));
result.ArtifactContractCount = double(sixgr.util.structGet(scenarioStatus, "ArtifactContractCount", 0));
result.ArtifactContractFailureCount = double(sixgr.util.structGet(scenarioStatus, "ArtifactContractFailureCount", 0));
result.ArtifactContractRequiredFailureCount = double(sixgr.util.structGet(scenarioStatus, "ArtifactContractRequiredFailureCount", 0));
result.FixedSNRSweepAuditRequired = logical(sixgr.util.structGet(scenarioStatus, "FixedSNRSweepAuditRequired", false));
result.FixedSNRSweepAuditExecuted = logical(sixgr.util.structGet(scenarioStatus, "FixedSNRSweepAuditExecuted", false));
result.FixedSNRSweepAuditOk = logical(sixgr.util.structGet(scenarioStatus, "FixedSNRSweepAuditOk", true));
result.FixedSNRSweepAuditFailureCount = double(sixgr.util.structGet(scenarioStatus, "FixedSNRSweepAuditFailureCount", 0));
result.FixedSNRSweepAuditWarningCount = double(sixgr.util.structGet(scenarioStatus, "FixedSNRSweepAuditWarningCount", 0));
result.FixedSNRSweepAuditFailures = string(sixgr.util.structGet(scenarioStatus, "FixedSNRSweepAuditFailures", strings(0, 1)));
result.GeometryScenarioAuditRequired = logical(sixgr.util.structGet(scenarioStatus, "GeometryScenarioAuditRequired", false));
result.GeometryScenarioAuditExecuted = logical(sixgr.util.structGet(scenarioStatus, "GeometryScenarioAuditExecuted", false));
result.GeometryScenarioAuditOk = logical(sixgr.util.structGet(scenarioStatus, "GeometryScenarioAuditOk", true));
result.GeometryScenarioAuditFailureCount = double(sixgr.util.structGet(scenarioStatus, "GeometryScenarioAuditFailureCount", 0));
result.GeometryScenarioAuditWarningCount = double(sixgr.util.structGet(scenarioStatus, "GeometryScenarioAuditWarningCount", 0));
result.GeometryScenarioAuditFailures = string(sixgr.util.structGet(scenarioStatus, "GeometryScenarioAuditFailures", strings(0, 1)));
result.WarningCount = double(scenarioStatus.WarningCount);
result.FailingCaseCount = double(scenarioStatus.FailingCaseCount);
result.CaseOk = logical(scenarioStatus.CaseOk);
result.ErrorSource = char(string(scenarioStatus.ErrorSource));
result.ErrorIdentifier = char(string(scenarioStatus.ErrorIdentifier));
result.ErrorMessage = char(string(scenarioStatus.ErrorMessage));
end

function [resultOk, requiredCaseCount, requiredFailureCount, failedCases, optionalPrunedCount, optionalPrunedCases, statusNotes, authority, warningCount, errorSource, errorIdentifier, errorMessage] = localAggregateWaveformLinkStatus(link, profileReportedOk)
resultOk = logical(profileReportedOk);
requiredCaseCount = NaN;
requiredFailureCount = NaN;
failedCases = strings(0, 1);
optionalPrunedCount = 0;
optionalPrunedCases = strings(0, 1);
statusNotes = "";
authority = "Link.Result.Ok";
warningCount = 0;
errorSource = "";
errorIdentifier = "";
errorMessage = "";

kpitable = sixgr.util.structGet(link, "KPITable", table());
unsupported = sixgr.util.structGet(link, "UnsupportedCases", table());
linkResultOk = localTryLogical(sixgr.util.structGet(link, "Result.Ok", []), NaN);
linkOuterOk = localTryLogical(sixgr.util.structGet(link, "Ok", []), NaN);

if istable(kpitable) && ~isempty(kpitable)
    requiredCaseCount = double(height(kpitable));
    caseNames = string(localTableColumnOrDefault(kpitable, "Case", repmat("", height(kpitable), 1)));
    okMask = logical(localTableColumnOrDefault(kpitable, "Ok", true(height(kpitable), 1)));
    skippedMask = logical(localTableColumnOrDefault(kpitable, "Skipped", false(height(kpitable), 1)));
    failMask = ~okMask | skippedMask;
    requiredFailureCount = double(sum(failMask));
    failedCases = unique(caseNames(failMask), "stable");
end

if istable(unsupported) && ~isempty(unsupported) && ismember("Case", string(unsupported.Properties.VariableNames))
    optionalPrunedCases = unique(string(unsupported.Case), "stable");
    optionalPrunedCount = double(numel(optionalPrunedCases));
    warningCount = optionalPrunedCount;
end

candidateOk = [linkResultOk, linkOuterOk];
candidateOk = candidateOk(isfinite(candidateOk));
if ~isempty(candidateOk)
    resultOk = all(candidateOk ~= 0);
end
if isfinite(requiredFailureCount)
    resultOk = resultOk && requiredFailureCount == 0;
end
if ~isfinite(requiredCaseCount) && ~isfinite(requiredFailureCount) && isfinite(linkResultOk)
    requiredCaseCount = 1;
    requiredFailureCount = double(~logical(linkResultOk));
end
if isfinite(linkResultOk) && isfinite(linkOuterOk) && logical(linkResultOk) ~= logical(linkOuterOk)
    statusNotes = localJoinStatusNotes(statusNotes, ...
        "Top-level link Ok disagreed with nested Link.Result.Ok; authoritative scenario status was derived conservatively from nested link status.");
end
if ~resultOk && isempty(failedCases) && isfinite(linkResultOk) && ~logical(linkResultOk)
    failedCases = "link_result";
    if ~isfinite(requiredFailureCount) || requiredFailureCount <= 0
        requiredFailureCount = 1;
    end
    errorSource = "Link.Result.Ok";
    errorIdentifier = "required_case_failed";
    errorMessage = "Nested link result reported failure.";
end
if ~isfinite(requiredCaseCount)
    requiredCaseCount = 0;
end
if ~isfinite(requiredFailureCount)
    requiredFailureCount = double(~resultOk);
end
if requiredFailureCount > 0 && strlength(string(errorIdentifier)) == 0
    errorSource = "KPITable";
    errorIdentifier = "required_case_failed";
    errorMessage = "At least one required waveform-link case failed or was skipped.";
end
end

function mu = localDeriveNumerologyMu(scsKHz)
mu = NaN;
scsKHz = double(scsKHz);
if ~(isfinite(scsKHz) && scsKHz > 0)
    return;
end
numerology = sixgr.phy.frame.NumerologyCatalog.resolve( ...
    scsKHz, "normal", "generic_waveform_test", "");
mu = double(numerology.Mu);
end

function slotDuration_ms = localDeriveSlotDurationMs(mu)
slotDuration_ms = NaN;
mu = double(mu);
if isfinite(mu)
    numerology = sixgr.phy.frame.AbsoluteTime.resolveNumerology(mu);
    slotDuration_ms = 1e3 * double(numerology.TicksPerSlot) / ...
        double(sixgr.phy.frame.AbsoluteTime.TicksPerSecond);
end
end

function slotsPerFrame = localDeriveSlotsPerFrame(mu)
slotsPerFrame = NaN;
mu = double(mu);
if isfinite(mu)
    numerology = sixgr.phy.frame.AbsoluteTime.resolveNumerology(mu);
    slotsPerFrame = double(numerology.SlotsPerFrame);
end
end

function numerology = localResolveConfigNumerology(cfg)
scsKHz = double(sixgr.util.structGet(cfg, ...
    "phy.carrier.SubcarrierSpacing", ...
    sixgr.util.structGet(cfg, "phy.carrier.SubcarrierSpacing_kHz", ...
    sixgr.util.structGet(cfg, "phy.numerology.scs_kHz", NaN))));
cp = string(sixgr.util.structGet(cfg, "phy.carrier.CyclicPrefix", "normal"));
numerology = sixgr.phy.frame.NumerologyCatalog.resolve( ...
    scsKHz, cp, "generic_waveform_test", "");
end

function value = localTryLogical(rawValue, defaultValue)
if nargin < 2
    defaultValue = NaN;
end
if isempty(rawValue)
    value = defaultValue;
    return;
end
try
    value = double(logical(rawValue(1)));
catch
    value = defaultValue;
end
end

function values = localTableColumnOrDefault(T, name, defaultValue)
if istable(T) && ismember(name, string(T.Properties.VariableNames))
    values = T.(name);
else
    values = defaultValue;
end
end

function note = localJoinStatusNotes(varargin)
parts = strings(0, 1);
for i = 1:nargin
    txt = strtrim(string(varargin{i}));
    if strlength(txt) > 0
        parts(end+1, 1) = txt; %#ok<AGROW>
    end
end
if isempty(parts)
    note = "";
    return;
end
parts = unique(parts, "stable");
note = strjoin(parts, " | ");
end

function metadata = localBenchmarkMetadata(scfg, descriptor, aiEnabled)
metadata = struct();
metadata.UseCase = string(scfg.get("ai_ml.use_case"));
metadata.AIEnabled = logical(aiEnabled);
metadata.Mode = string(scfg.get("ai_ml.mode"));
metadata.ModelID = string(scfg.get("ai_ml.model_id"));
metadata.ModelVersion = string(scfg.get("ai_ml.model_version"));
metadata.DescriptorType = string(scfg.get("ai_ml.descriptor_type"));
metadata.QuantizationMode = string(scfg.get("ai_ml.quantization_mode"));
metadata.RuntimeBudget_us = double(scfg.get("ai_ml.runtime_budget_us"));
metadata.LatencyBudget_us = double(scfg.get("ai_ml.latency_budget_us"));
metadata.FLOPsBudget = double(scfg.get("ai_ml.flops_budget"));
metadata.InferenceBatchSize = double(scfg.get("ai_ml.inference_batch_size"));
metadata.FallbackEnabled = logical(scfg.get("ai_ml.fallback_enabled"));
metadata.ConfidenceLoggingEnabled = logical(scfg.get("ai_ml.confidence_logging"));
metadata.ParameterCount = double(localOptionalDescriptorValue(descriptor, "parameter_count", NaN));
metadata.ConfiguredConfidenceBias = double(localOptionalDescriptorValue(descriptor, "confidence_bias", NaN));
metadata.ConfiguredInputFeatures = strjoin(string(scfg.get("ai_ml.input_features")), "|");
metadata.ConfiguredOutputTargets = strjoin(string(scfg.get("ai_ml.output_targets")), "|");
end

function T = localAppendBenchmarkColumns(T, metadata, confidenceValue)
if ~istable(T)
    return;
end
vars = { ...
    "UseCase", repmat(metadata.UseCase, height(T), 1), ...
    "AIEnabled", repmat(metadata.AIEnabled, height(T), 1), ...
    "Mode", repmat(metadata.Mode, height(T), 1), ...
    "ModelID", repmat(metadata.ModelID, height(T), 1), ...
    "ModelVersion", repmat(metadata.ModelVersion, height(T), 1), ...
    "DescriptorType", repmat(metadata.DescriptorType, height(T), 1), ...
    "QuantizationMode", repmat(metadata.QuantizationMode, height(T), 1), ...
    "RuntimeBudget_us", repmat(metadata.RuntimeBudget_us, height(T), 1), ...
    "LatencyBudget_us", repmat(metadata.LatencyBudget_us, height(T), 1), ...
    "FLOPsBudget", repmat(metadata.FLOPsBudget, height(T), 1), ...
    "InferenceBatchSize", repmat(metadata.InferenceBatchSize, height(T), 1), ...
    "FallbackEnabled", repmat(metadata.FallbackEnabled, height(T), 1), ...
    "ConfidenceLoggingEnabled", repmat(metadata.ConfidenceLoggingEnabled, height(T), 1), ...
    "ConfidenceScore", repmat(confidenceValue, height(T), 1), ...
    "ParameterCount", repmat(metadata.ParameterCount, height(T), 1)};
    for k = 1:2:numel(vars)
        name = vars{k};
        values = vars{k+1};
        if ~ismember(name, T.Properties.VariableNames)
            T = addvars(T, values, 'NewVariableNames', name);
        end
    end
end

function value = localBenchmarkConfidence(descriptor, scfg)
if ~logical(scfg.get("ai_ml.confidence_logging"))
    value = NaN;
    return;
end
% Descriptor-side confidence_bias is static model metadata, not measured
% runtime confidence telemetry. Keep benchmark confidence unavailable until
% the active AI path emits per-observation runtime confidence.
value = double(localOptionalDescriptorValue(descriptor, "runtime_measured_confidence_score", NaN));
end

function Hout = localApplyCEPlugin(Hin, descriptor)
pluginType = lower(string(localRequireDescriptorField(descriptor, "plugin_type")));
switch pluginType
    case "moving_average_denoiser"
        alpha = double(localRequireDescriptorField(descriptor, "smoothing_alpha"));
        Hout = (1 - alpha) .* Hin + alpha .* ones(size(Hin), "like", Hin);
    otherwise
        Hout = Hin;
end
end

function [xHat, ratio] = localApplyCSICompressionPlugin(x, descriptor, latentDim, quantBits)
x = double(x(:));
step = max(1, ceil(numel(x) / max(latentDim, 1)));
z = x(1:step:end);
maxAbs = max(abs(z));
if maxAbs <= 0
    zq = z;
else
    qLevels = max(2^max(quantBits,1)-1, 1);
    zq = round((z / maxAbs) * qLevels) / qLevels * maxAbs;
end
xHat = repelem(zq, step);
xHat = xHat(1:numel(x));
ratio = double(numel(x)) / max(double(numel(zq)), 1);
if lower(string(localRequireDescriptorField(descriptor, "plugin_type"))) ~= "latent_quantizer"
    xHat = x;
    ratio = 1;
end
end

function beamIdx = localApplyBeamPlugin(metric, descriptor)
pluginType = lower(string(localRequireDescriptorField(descriptor, "plugin_type")));
metric = double(metric(:));
switch pluginType
    case "argmax"
        [~, beamIdx] = max(metric);
    case "top2_energy_bias"
        [~, idx] = sort(metric, "descend");
        beamIdx = idx(min(2, numel(idx)));
    otherwise
        [~, beamIdx] = max(metric);
end
beamIdx = double(beamIdx);
end

function descriptor = localLoadAIDescriptor(modelPath)
descriptor = struct();
modelPath = string(modelPath);
if strlength(modelPath) == 0
    return;
end
resolved = localResolveModelPath(modelPath);
if exist(resolved, "file") ~= 2
    return;
end
descriptor = sixgr.lls6g.config.readConfigFile(resolved);
end

function value = localRequireDescriptorField(descriptor, fieldName)
if ~isfield(descriptor, fieldName)
    error("sixgr:lls6g:runner:MissingDescriptorField", ...
        "AI descriptor is missing required field '%s'.", fieldName);
end
value = descriptor.(fieldName);
end

function value = localOptionalDescriptorValue(descriptor, fieldName, defaultValue)
if isfield(descriptor, fieldName)
    value = descriptor.(fieldName);
else
    value = defaultValue;
end
end

function p = localResolveModelPath(modelPath)
if exist(char(modelPath), "file") == 2
    p = char(modelPath);
    return;
end
root = localRepoRoot();
candidate = fullfile(root, char(modelPath));
if exist(candidate, "file") == 2
    p = candidate;
    return;
end
p = char(modelPath);
end

function localWriteOptionalTable(filePath, T)
if istable(T) && ~isempty(T)
    sixgr.util.csvWriteTable(filePath, T);
end
end

function root = localRepoRoot()
root = fileparts(fileparts(fileparts(fileparts(mfilename("fullpath")))));
end

function out = localMaterializeBrowserContractArtifacts(runFolder)
out = sixgr.artifact.materializeBrowserContractArtifacts(runFolder);
end

function localPublishMappedRuntimeConfigEvidence(scfg, cfg)
if isa(scfg, "sixgr.lls6g.config.ScenarioConfig")
    s = scfg.toStruct();
else
    s = scfg;
end
if ~isstruct(s)
    return;
end

mappings = {
    "bwp.dl", "PHY_BWP", "phy.bwp.dl"
    "bwp.ul", "PHY_BWP", "phy.bwp.ul"
    "pdsch.resource_allocation_type", "DL_Data_PDSCH", "phy.pdsch.resourceAllocationType"
    "pdsch.mapping_type", "DL_Data_PDSCH", "phy.pdsch.mappingType"
    "pdsch.start_symbol", "DL_Data_PDSCH", "phy.pdsch.startSymbol"
    "pdsch.num_symbols", "DL_Data_PDSCH", "phy.pdsch.numSymbols"
    "pdsch.vrb_to_prb_mapping", "DL_Data_PDSCH", "phy.pdsch.vrbToPRBMapping"
    "pdsch.prb_bundling_type", "DL_Data_PDSCH", "phy.pdsch.prbBundlingType"
    "pdsch.prb_bundle_size", "DL_Data_PDSCH", "phy.pdsch.prbBundleSize"
    "pdsch.rate_matching_pattern", "DL_Data_PDSCH", "phy.pdsch.rateMatchingPattern"
    "pdsch.xoh_pdsch", "DL_Data_PDSCH", "phy.pdsch.xOverhead"
    "pdsch.tbs_scaling", "DL_Data_PDSCH", "phy.pdsch.tbsScaling"
    "pdsch.cbg_transmission", "DL_Data_PDSCH", "phy.pdsch.cbgTransmission"
    "pusch.resource_allocation_type", "UL_Data_PUSCH", "phy.pusch.resourceAllocationType"
    "pusch.mapping_type", "UL_Data_PUSCH", "phy.pusch.mappingType"
    "pusch.start_symbol", "UL_Data_PUSCH", "phy.pusch.startSymbol"
    "pusch.num_symbols", "UL_Data_PUSCH", "phy.pusch.numSymbols"
    "pusch.frequency_hopping", "UL_Data_PUSCH", "phy.pusch.frequencyHopping.mode"
    "pusch.intra_slot_frequency_hopping", "UL_Data_PUSCH", "phy.pusch.intraSlotFrequencyHopping"
    "pusch.inter_slot_frequency_hopping", "UL_Data_PUSCH", "phy.pusch.interSlotFrequencyHopping"
    "pusch.transform_precoding", "UL_Data_PUSCH", "phy.pusch.transformPrecoding"
    "pusch.codebook_based_transmission", "UL_Data_PUSCH", "phy.pusch.codebookBasedTransmission"
    "pusch.xoh_pusch", "UL_Data_PUSCH", "phy.pusch.xOverhead"
    "pusch.cbg_transmission", "UL_Data_PUSCH", "phy.pusch.cbgTransmission"
    "pusch.tp_pi2_bpsk", "UL_Data_PUSCH", "phy.pusch.pi2BPSKTransformPrecoding"
    "pdcch.coreset", "DL_UL_Control_PDCCH", "phy.pdcch.coresets"
    "pdcch.coresets", "DL_UL_Control_PDCCH", "phy.pdcch.coresets"
    "pdcch.search_spaces", "DL_UL_Control_PDCCH", "phy.pdcch.searchSpaces"
    "pdcch.blind_decoding_attempts", "DL_UL_Control_PDCCH", "phy.pdcch.blindDecodingAttempts"
    "pdcch.dmrs_scrambling_id_source", "DL_UL_Control_PDCCH", "phy.pdcch.dmrsScramblingIdSource"
    "pdcch.rnti_config", "DL_UL_Control_PDCCH", "phy.pdcch.rntiConfig"
    "channel_estimation.algorithm", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.algorithm"
    "channel_estimation.interpolation_method", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.interpolationMethod"
    "channel_estimation.filter_length_time", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.filterLengthTime"
    "channel_estimation.filter_length_freq", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.filterLengthFrequency"
    "channel_estimation.noise_variance_source", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.noiseVarianceSource"
    "channel_estimation.noise_variance_averaging_window_slots", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.noiseVarianceAveragingWindowSlots"
    "channel_estimation.delay_spread_assumption_ns", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.delaySpreadAssumption_ns"
    "channel_estimation.doppler_assumption_hz", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.dopplerAssumption_Hz"
    "channel_estimation.temporal_filtering_enable", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.temporalFilteringEnabled"
    "channel_estimation.frequency_smoothing_enable", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.frequencySmoothingEnabled"
    "channel_estimation.perfect_csi", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.perfectCSI"
    "channel_estimation.ce_extrapolation_mode", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.extrapolationMode"
    "channel_estimation.ce_bound_delay_ns", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.boundDelay_ns"
    "channel_estimation.ce_reference_signal", "PHY_Receiver_Channel_Estimation", "phy.channelEstimation.referenceSignal"
    "equalization.algorithm", "PHY_Receiver_Equalization", "phy.equalization.algorithm"
    "equalization.regularization_method", "PHY_Receiver_Equalization", "phy.equalization.regularizationMethod"
    "equalization.noise_variance_for_equalizer", "PHY_Receiver_Equalization", "phy.equalization.noiseVarianceForEqualizer"
    "equalization.post_equalization_snr_estimation", "PHY_Receiver_Equalization", "phy.equalization.postEqualizationSNREstimation"
    "equalization.irc_interference_covariance_window_slots", "PHY_Receiver_Equalization", "phy.equalization.ircInterferenceCovarianceWindowSlots"
    "equalization.irc_covariance_estimation", "PHY_Receiver_Equalization", "phy.equalization.ircCovarianceEstimation"
    "equalization.sv_threshold", "PHY_Receiver_Equalization", "phy.equalization.singularValueThreshold"
    "equalization.condition_number_cap", "PHY_Receiver_Equalization", "phy.equalization.conditionNumberCap"
    "equalization.per_prb_equalization", "PHY_Receiver_Equalization", "phy.equalization.perPRBEqualization"
    "equalization.per_symbol_equalization", "PHY_Receiver_Equalization", "phy.equalization.perSymbolEqualization"
    "equalization.equalizer_output_scaling", "PHY_Receiver_Equalization", "phy.equalization.outputScaling"
    "equalization.sic_enable", "PHY_Receiver_Equalization", "phy.equalization.sicEnabled"
    "equalization.sic_stages", "PHY_Receiver_Equalization", "phy.equalization.sicStages"
    "synchronization.timing_sync_algorithm", "PHY_Synchronization", "phy.synchronization.timingSyncAlgorithm"
    "synchronization.frequency_sync_algorithm", "PHY_Synchronization", "phy.synchronization.frequencySyncAlgorithm"
    "synchronization.symbol_timing_recovery", "PHY_Synchronization", "phy.synchronization.symbolTimingRecovery"
    "synchronization.integer_cfo_correction_enable", "PHY_Synchronization", "phy.synchronization.integerCFOCorrectionEnabled"
    "synchronization.fractional_cfo_correction_enable", "PHY_Synchronization", "phy.synchronization.fractionalCFOCorrectionEnabled"
    "synchronization.timing_tracking_mode", "PHY_Synchronization", "phy.synchronization.timingTrackingMode"
    "synchronization.frequency_tracking_mode", "PHY_Synchronization", "phy.synchronization.frequencyTrackingMode"
    "synchronization.pss_detection_threshold", "PHY_Synchronization", "phy.synchronization.pssDetectionThreshold"
    "synchronization.sss_hypothesis_test_threshold", "PHY_Synchronization", "phy.synchronization.sssHypothesisTestThreshold"
    "synchronization.max_timing_uncertainty_samples", "PHY_Synchronization", "phy.synchronization.maxTimingUncertaintySamples"
    "synchronization.ota_timing_advance_enable", "PHY_Synchronization", "phy.synchronization.otaTimingAdvanceEnabled"
    "synchronization.timing_advance_granularity_ts", "PHY_Synchronization", "phy.synchronization.timingAdvanceGranularityTs"
    "rf_hardware.adc_resolution_bits", "RF_Hardware", "rf.hardware.adc.resolutionBits"
    "rf_hardware.dac_resolution_bits", "RF_Hardware", "rf.hardware.dac.resolutionBits"
    "rf_hardware.adc_dynamic_range_db", "RF_Hardware", "rf.hardware.adc.dynamicRange_dB"
    "rf_hardware.adc_full_scale_power_dBm", "RF_Hardware", "rf.hardware.adc.fullScalePower_dBm"
    "rf_hardware.agc_enable", "RF_Hardware", "rf.hardware.agc.enabled"
    "rf_hardware.agc_target_level_dBm", "RF_Hardware", "rf.hardware.agc.targetLevel_dBm"
    "rf_hardware.agc_attack_time_us", "RF_Hardware", "rf.hardware.agc.attackTime_us"
    "rf_hardware.agc_release_time_us", "RF_Hardware", "rf.hardware.agc.releaseTime_us"
    "rf_hardware.dc_offset_enable", "RF_Hardware", "rf.hardware.dcOffset.enabled"
    "rf_hardware.dc_offset_level_dBc", "RF_Hardware", "rf.hardware.dcOffset.level_dBc"
    "rf_hardware.dc_offset_compensation_enable", "RF_Hardware", "rf.hardware.dcOffset.compensationEnabled"
    "rf_hardware.lna_gain_dB", "RF_Hardware", "rf.hardware.lna.gain_dB"
    "rf_hardware.rx_gain_dB", "RF_Hardware", "rf.hardware.rxGain_dB"
    "rf_hardware.tx_gain_dB", "RF_Hardware", "rf.hardware.txGain_dB"
    "rf_hardware.mutual_coupling_matrix_enable", "RF_Hardware", "rf.hardware.mutualCouplingMatrixEnabled"
    "scheduling_timing.pdcch_to_pdsch_k0", "Scheduling_Timing", "phy.schedulingTiming.pdcchToPDSCHK0"
    "scheduling_timing.pdcch_to_pusch_k2", "Scheduling_Timing", "phy.schedulingTiming.pdcchToPUSCHK2"
    "scheduling_timing.dl_harq_feedback_k1", "Scheduling_Timing", "phy.schedulingTiming.dlHARQFeedbackK1Candidates"
    "scheduling_timing.ul_grant_k2", "Scheduling_Timing", "phy.schedulingTiming.ulGrantK2"
    "scheduling_timing.harq_roundtrip_slots", "Scheduling_Timing", "phy.schedulingTiming.harqRoundtripSlots"
    "scheduling_timing.dl_to_ul_guard_time_us", "Scheduling_Timing", "phy.schedulingTiming.dlToULGuardTime_us"
    "scheduling_timing.timing_advance_max_us", "Scheduling_Timing", "phy.schedulingTiming.timingAdvanceMax_us"
    "scheduling_timing.n1_pdsch_processing_time_symbols", "Scheduling_Timing", "phy.schedulingTiming.n1PDSCHProcessingTimeSymbols"
    "scheduling_timing.n2_pusch_preparation_time_symbols", "Scheduling_Timing", "phy.schedulingTiming.n2PUSCHPreparationTimeSymbols"
    "tdd_timing.pdcch_to_pdsch_k0", "Scheduling_Timing", "phy.schedulingTiming.pdcchToPDSCHK0"
    "tdd_timing.pdcch_to_pusch_k2", "Scheduling_Timing", "phy.schedulingTiming.pdcchToPUSCHK2"
    "tdd_timing.dl_harq_feedback_k1", "Scheduling_Timing", "phy.schedulingTiming.dlHARQFeedbackK1Candidates"
    "tdd_timing.ul_grant_k2", "Scheduling_Timing", "phy.schedulingTiming.ulGrantK2"
    "tdd_timing.harq_roundtrip_slots", "Scheduling_Timing", "phy.schedulingTiming.harqRoundtripSlots"
    "tdd_timing.dl_to_ul_guard_time_us", "Scheduling_Timing", "phy.schedulingTiming.dlToULGuardTime_us"
    "tdd_timing.timing_advance_max_us", "Scheduling_Timing", "phy.schedulingTiming.timingAdvanceMax_us"
    "tdd_timing.n1_pdsch_processing_time_symbols", "Scheduling_Timing", "phy.schedulingTiming.n1PDSCHProcessingTimeSymbols"
    "tdd_timing.n2_pusch_preparation_time_symbols", "Scheduling_Timing", "phy.schedulingTiming.n2PUSCHPreparationTimeSymbols"
    "coding.ldpc_lifting_size_z_selection", "PHY_Coding", "phy.ldpc.liftingSizeZSelection"
    "coding.ldpc_schedule_type", "PHY_Coding", "phy.ldpc.scheduleType"
    "coding.ldpc_min_sum_offset", "PHY_Coding", "phy.ldpc.minSumOffset"
    "coding.polar_reliability_sequence_source", "PHY_Coding", "phy.polar.reliabilitySequenceSource"
    "coding.polar_rate_matching_type", "PHY_Coding", "phy.polar.rateMatchingType"
    "link_adaptation.olla_init_offset_db", "Link_Adaptation", "phy.linkAdaptation.ollaInitialOffset_dB"
    "link_adaptation.olla_max_offset_db", "Link_Adaptation", "phy.linkAdaptation.ollaMaxOffset_dB"
    "link_adaptation.olla_min_offset_db", "Link_Adaptation", "phy.linkAdaptation.ollaMinOffset_dB"
    "link_adaptation.olla_window_size_slots", "Link_Adaptation", "phy.linkAdaptation.ollaWindowSizeSlots"
    "link_adaptation.olla_forgetting_factor", "Link_Adaptation", "phy.linkAdaptation.ollaForgettingFactor"
    "link_adaptation.mcs_backoff_dl_db", "Link_Adaptation", "phy.linkAdaptation.dlMCSBackoff_dB"
    "link_adaptation.mcs_backoff_ul_db", "Link_Adaptation", "phy.linkAdaptation.ulMCSBackoff_dB"
    "link_adaptation.sinr_to_cqi_mapping_table", "Link_Adaptation", "phy.linkAdaptation.sinrToCQITable"
    };

for i = 1:size(mappings, 1)
    parameterId = string(mappings{i, 1});
    featureFamily = string(mappings{i, 2});
    internalPath = string(mappings{i, 3});
    [~, sourceFound] = localTryGetNestedRuntime(s, parameterId);
    [appliedValue, internalFound] = localTryGetNestedRuntime(cfg, internalPath);
    if ~(sourceFound && internalFound)
        continue;
    end
    sixgr.config.publishConfigApplicationEvidence("record", ...
        parameterId, featureFamily, internalPath, ...
        "sixgr.lls6g.buildInternalConfig", appliedValue, ...
        "RuntimeObjectType", "struct", ...
        "RuntimeObjectPath", "cfg." + internalPath, ...
        "ApplicationScope", "run", ...
        "EvidenceSource", "resolved_config_to_internal_cfg_mapping");
end
end

function [value, found] = localTryGetNestedRuntime(s, path)
value = [];
found = false;
if ~isstruct(s)
    return;
end
parts = split(string(path), ".");
cursor = s;
for i = 1:numel(parts)
    key = char(parts(i));
    if ~(isstruct(cursor) && isscalar(cursor) && isfield(cursor, key))
        return;
    end
    cursor = cursor.(key);
end
value = cursor;
found = true;
end

function localPruneEmptyDirs(rootFolder)
rootFolder = char(string(rootFolder));
if ~isfolder(rootFolder)
    return;
end
entries = dir(rootFolder);
for i = 1:numel(entries)
    name = string(entries(i).name);
    if name == "." || name == ".." || ~entries(i).isdir
        continue;
    end
    child = fullfile(rootFolder, char(name));
    localPruneEmptyDirs(child);
end
entries = dir(rootFolder);
entries = entries(~ismember(string({entries.name}), [".", ".."]));
if isempty(entries)
    try
        rmdir(rootFolder);
    catch
    end
end
end

function fixedCfg = localResolveFixedLinkCampaignRuntimeConfig(scfg, cfg, controlledSNRGrid, fixedLinkEnabledDefault, defaultFixedTrials, totalSlots)
validationCfg = sixgr.util.structGet(cfg, "validation.fixed_link_campaign", struct());
if isstruct(validationCfg) && logical(sixgr.util.structGet(validationCfg, "enabled", false))
    fixedCfg = localBuildFixedLinkCampaignConfigFromValidation(cfg, validationCfg);
    return;
end
fixedCfg = localBuildFixedLinkCampaignConfigFromLegacy(scfg, cfg, controlledSNRGrid, fixedLinkEnabledDefault, defaultFixedTrials, totalSlots);
end

function fixedCfg = localBuildFixedLinkCampaignConfigFromValidation(cfg, validationCfg)
% validation.fixed_link_campaign is already schema-validated and is the
% authoritative master-YAML contract. Preserve it exactly; the campaign
% runner performs the final runtime/capability validation.
fixedCfg = validationCfg;
fixedCfg.Enabled = logical(sixgr.util.structGet( ...
    validationCfg, "enabled", false));
fixedCfg.Only = logical(sixgr.util.structGet(cfg, ...
    "sweeps_and_matrix.fixed_link_calibration.only", ...
    sixgr.util.structGet(cfg, ...
    "canonical_control.run.fixed_link_campaign_only", false)));
end

function fixedCfg = localBuildFixedLinkCampaignConfigFromLegacy(scfg, cfg, controlledSNRGrid, fixedLinkEnabledDefault, defaultFixedTrials, totalSlots)
fixedCfg = struct();
fixedCfg.Enabled = logical(scfg.get("sweeps_and_matrix.fixed_link_calibration.enabled", fixedLinkEnabledDefault));
fixedCfg.Only = logical(scfg.get("sweeps_and_matrix.fixed_link_calibration.only", ...
    sixgr.util.structGet(cfg, "run.fixedLinkCampaignOnly", false)));
fixedCfg.Direction = string(scfg.get("sweeps_and_matrix.fixed_link_calibration.direction", "both"));
fixedCfg.ChannelModel = upper(string(scfg.get("sweeps_and_matrix.fixed_link_calibration.channel_model", ...
    sixgr.util.structGet(cfg, "channel.model", "AWGN"))));
fixedCfg.SNR_dB = localFiniteRowVector(scfg.get("sweeps_and_matrix.fixed_link_calibration.snr_db", controlledSNRGrid), ...
    controlledSNRGrid);
fixedCfg.MCS = [];
fixedCfg.DLMCS = localFiniteIntegerRowVector(sixgr.util.structGet(cfg, "phy.pdsch.mcsIndex", []), []);
fixedCfg.ULMCS = localFiniteIntegerRowVector(sixgr.util.structGet(cfg, "phy.pusch.mcsIndex", []), []);
fixedCfg.Rank = localPositiveIntegerOrDefault(sixgr.util.structGet(cfg, "phy.pdsch.rank", []), 1);
fixedCfg.Layers = localPositiveIntegerOrDefault(sixgr.util.structGet(cfg, "phy.pdsch.nLayers", ...
    sixgr.util.structGet(cfg, "phy.pusch.nLayers", 1)), 1);
fixedCfg.NPRB = localDefaultCampaignNPRB(cfg);
fixedCfg.MinTBPerPoint = max(1, round(double(scfg.get("sweeps_and_matrix.fixed_link_calibration.min_trials", defaultFixedTrials))));
fixedCfg.MaxTBPerPoint = max(fixedCfg.MinTBPerPoint, ...
    round(double(scfg.get("sweeps_and_matrix.fixed_link_calibration.max_trials", defaultFixedTrials))));
    % Zero explicitly disables the error-count stopping criterion.  An
    % infinite legacy sentinel is not a valid YAML campaign integer and
    % must not leak into the strict campaign validator.
    fixedCfg.MinErrorsForCI = max(0, round(double(scfg.get( ...
        "sweeps_and_matrix.fixed_link_calibration.error_target", 0))));
fixedCfg.MaxCIHalfWidth = max(0, double(scfg.get("sweeps_and_matrix.fixed_link_calibration.ci_width_target", inf)) / 2);
fixedCfg.Seeds = localFiniteIntegerRowVector(scfg.get("sweeps_and_matrix.fixed_link_calibration.seed", ...
    double(sixgr.util.structGet(cfg, "run.seed", 1)) + 730001), ...
    double(sixgr.util.structGet(cfg, "run.seed", 1)) + 730001);
fixedCfg.TargetBLER = localFiniteRowVector(scfg.get("sweeps_and_matrix.fixed_link_calibration.target_bler", 0.10), 0.10);
fixedCfg.PrimaryTargetBLER = double(fixedCfg.TargetBLER(1));
fixedCfg.ConfidenceLevel = double(scfg.get("sweeps_and_matrix.fixed_link_calibration.confidence_level", 0.95));
fixedCfg.BatchTBCount = max(1, round(double(scfg.get("sweeps_and_matrix.fixed_link_calibration.trials_per_drop", totalSlots))));
fixedCfg.SeedBase = double(fixedCfg.Seeds(1));
end

function value = localDefaultCampaignNPRB(cfg)
value = localPositiveIntegerOrDefault(numel(double(sixgr.util.structGet(cfg, "phy.pdsch.PRBSet", []))), NaN);
if ~(isfinite(value) && value >= 1)
    value = localPositiveIntegerOrDefault(numel(double(sixgr.util.structGet(cfg, "phy.pusch.PRBSet", []))), NaN);
end
if ~(isfinite(value) && value >= 1)
    value = localPositiveIntegerOrDefault(sixgr.util.structGet(cfg, "phy.numerology.activeGridNumRBs", []), ...
        sixgr.util.structGet(cfg, "phy.carrier.NSizeGrid", 24));
end
end

function values = localFiniteRowVector(value, fallback)
values = double(value);
values = values(:).';
values = values(isfinite(values));
if isempty(values)
    values = double(fallback);
    values = values(:).';
    values = values(isfinite(values));
end
end

function values = localFiniteIntegerRowVector(value, fallback)
values = localFiniteRowVector(value, fallback);
values = round(double(values));
end

function value = localPositiveIntegerOrDefault(value, fallback)
value = double(value);
if ~(isscalar(value) && isfinite(value) && value >= 1)
    value = double(fallback);
end
if ~(isscalar(value) && isfinite(value) && value >= 1)
    value = 1;
end
value = round(double(value));
end

function value = localFiniteNonNegativeOrDefault(value, fallback)
value = double(value);
if ~(isscalar(value) && isfinite(value) && value >= 0)
    value = double(fallback);
end
if ~(isscalar(value) && isfinite(value) && value >= 0)
value = 0;
end
end

function stage = localReadCurrentRuntimeStage(layout)
stage = "";
candidates = [ ...
    string(fullfile(layout.ReportCSVDir, "live_stage_status.csv")); ...
    string(fullfile(layout.AirInterfaceDir, "reports", "csv", ...
    "live_stage_status.csv"))];
for index = 1:numel(candidates)
    if exist(char(candidates(index)), "file") ~= 2
        continue;
    end
    try
        status = readtable(char(candidates(index)), "FileType", "text", ...
            "Delimiter", ",", "ReadVariableNames", true, ...
            "TextType", "string", "VariableNamingRule", "preserve");
        if height(status) == 1 && ...
                ismember("Stage", string(status.Properties.VariableNames))
            stage = string(status.Stage(1));
            return;
        end
    catch
    end
end
end
