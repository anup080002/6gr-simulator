function probeBaselineCSIReportCalendarExact(outputPath)
% Resolved-config calendar audit only. No RF, UE measurements or CSI transmission.
setup6GRSimToolkit('Verbose',false);
scenarioPath='simulator/configs/scenarios/lls_causal_access_to_data_wiring_tdd_short_continuous_iq.yaml';
scenario=sixgr.lls6g.config.loadScenarioConfig(scenarioPath);
cfg=sixgr.lls6g.buildInternalConfig(scenario,tempname);
period=cfg.phy.csi.reportPeriodicitySlots;
offset=cfg.phy.csi.reportOffsetSlots;
delay=sixgr.truth.CoupledTruthRuntime.resolveConfiguredCSIFeedbackSlots(cfg);
assert(cfg.phy.csi.reportCSI && string(cfg.phy.csi.reportTrigger)=="periodic");
records=struct([]);
nSlots=double(scenario.Data.run_control.total_slots);
section=cfg.validation.pucch_resources;
resource=section.resources([section.resources.id]==section.csi_resource_ids(1));
assert(isscalar(resource),'test:CSIResourceIdentity');
controlStart=double(resource.starting_symbol);
controlCount=double(resource.nrof_symbols);
searchLimit=max(20,4*cfg.phy.numerology.slotsPerFrame);
for slot=1:nSlots
    if ~sixgr.truth.CoupledTruthRuntime.isCSIReportOccasionRuntime(cfg,slot,"DL"), continue; end
    [~,ul,label,partition]=sixgr.truth.CoupledTruthRuntime.resolveSlotPartition(cfg,slot);
    assert(mod((slot-1)-offset,period)==0);
    % Projection of the current enqueue source+delay/next-UL rule, not an
    % actual enqueued or transmitted CSI report.
    candidate=slot+delay;
    projectedFits=false;
    for shift=0:searchLimit
        candidate=slot+delay+shift;
        [~,candidateUL,~,candidatePartition]=sixgr.truth.CoupledTruthRuntime.resolveSlotPartition(cfg,candidate);
        allocated=candidatePartition.ULSymbolAllocation;
        projectedFits=candidateUL && controlStart>=allocated(1) && ...
            controlStart+controlCount<=sum(allocated);
        if projectedFits, break; end
    end
    assert(projectedFits,'test:UnboundedCalendarProbe');
    nominal=partition.ULSymbolAllocation;
    nominalFits=ul && controlStart>=nominal(1) && controlStart+controlCount<=sum(nominal);
    row=struct('ConfiguredReportSlot',slot,'PeriodSlots',period,'OffsetSlots0',offset, ...
        'ConfiguredSlotDirection',string(label),'ConfiguredSlotAllowsUL',logical(ul), ...
        'ConfiguredULSymbolStart',partition.ULSymbolAllocation(1), ...
        'ConfiguredULSymbolCount',partition.ULSymbolAllocation(2), ...
        'ConfiguredCSIResourceID',resource.id,'CSIControlStart',controlStart, ...
        'CSIControlCount',controlCount,'ConfiguredCSIResourceFitsUL',logical(nominalFits), ...
        'ProcessingDelaySlots',delay,'CurrentRuleProjectedDueSlot',candidate, ...
        'ProjectedDueMatchesReportOffset',mod((candidate-1)-offset,period)==0, ...
        'EvidenceClass',"resolved_config_calendar_only_not_RF");
    if isempty(records), records=row; else, records(end+1)=row; end %#ok<AGROW>
end
T=struct2table(records);
assert(~isfile(outputPath),'test:PreserveExistingEvidence','Choose a new audit output.');
writetable(T,outputPath);
disp(T);
fprintf('BASELINE_CSI_CALENDAR_EXACT_AUDIT occasions=%d no_UL=%d shifted_off_configured_offset=%d RF_executions=0\n', ...
    height(T),nnz(~T.ConfiguredSlotAllowsUL | T.ConfiguredULSymbolCount==0), ...
    nnz(~T.ProjectedDueMatchesReportOffset));
assert(all(T.ConfiguredCSIResourceFitsUL), ...
    'test:BaselineCSIReportOccasionsOutsideUL', ...
    'The configured periodic CSI resource does not fit the nominal report occasions.');
assert(all(T.ProjectedDueMatchesReportOffset), ...
    'test:CSIReportOffsetShiftedByProcessingDelay', ...
    'The report transmission calendar must be independent of source-slot plus processing-delay projection.');
end
