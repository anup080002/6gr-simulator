function probeBaselineCSIReportCalendar(outputPath)
% Resolved-config calendar audit only. No RF, UE measurements or CSI transmission.
setup6GRSimToolkit('Verbose',false);
scenarioPath='simulator/configs/scenarios/lls_causal_access_to_data_wiring_tdd_short_continuous_iq.yaml';
scenario=sixgr.lls6g.config.loadScenarioConfig(scenarioPath);
cfg=sixgr.lls6g.buildInternalConfig(scenario,tempname);
period=cfg.phy.csi.reportPeriodicitySlots;
offset=cfg.phy.csi.reportOffsetSlots;
delay=sixgr.truth.CoupledTruthRuntime.resolveConfiguredCSIFeedbackSlots(cfg);
assert(cfg.phy.csi.reportCSI && string(cfg.phy.csi.reportTrigger)=="periodic");
records=struct([]);
for slot=1:58
    if ~sixgr.truth.CoupledTruthRuntime.isCSIReportOccasionRuntime(cfg,slot,"DL"), continue; end
    [~,ul,label,partition]=sixgr.truth.CoupledTruthRuntime.resolveSlotPartition(cfg,slot);
    assert(mod((slot-1)-offset,period)==0);
    % Projection of the current enqueue source+delay/next-UL rule, not an
    % actual enqueued or transmitted CSI report.
    candidate=slot+delay;
    while true
        [~,candidateUL,~,candidatePartition]=sixgr.truth.CoupledTruthRuntime.resolveSlotPartition(cfg,candidate);
        if candidateUL && candidatePartition.ULSymbolAllocation(2)>0, break; end
        candidate=candidate+1;
        assert(candidate<=slot+delay+2*period+20,'test:UnboundedCalendarProbe');
    end
    row=struct('ConfiguredReportSlot',slot,'PeriodSlots',period,'OffsetSlots0',offset, ...
        'ConfiguredSlotDirection',string(label),'ConfiguredSlotAllowsUL',logical(ul), ...
        'ConfiguredULSymbolStart',partition.ULSymbolAllocation(1), ...
        'ConfiguredULSymbolCount',partition.ULSymbolAllocation(2), ...
        'ProcessingDelaySlots',delay,'CurrentRuleProjectedDueSlot',candidate, ...
        'ProjectedDueMatchesReportOffset',mod((candidate-1)-offset,period)==0, ...
        'EvidenceClass',"resolved_config_calendar_only_not_RF");
    if isempty(records), records=row; else, records(end+1)=row; end %#ok<AGROW>
end
T=struct2table(records);
assert(~isfile(outputPath),'test:PreserveExistingEvidence','Choose a new audit output.');
writetable(T,outputPath);
disp(T);
fprintf('BASELINE_CSI_CALENDAR_AUDIT occasions=%d no_UL=%d shifted_off_configured_offset=%d RF_executions=0\n', ...
    height(T),nnz(~T.ConfiguredSlotAllowsUL | T.ConfiguredULSymbolCount==0), ...
    nnz(~T.ProjectedDueMatchesReportOffset));
assert(all(T.ConfiguredSlotAllowsUL & T.ConfiguredULSymbolCount>0), ...
    'test:BaselineCSIReportCalendarNotUL', ...
    'Periodic PUCCH report occasions must not be configured entirely in DL slots.');
assert(all(T.ProjectedDueMatchesReportOffset), ...
    'test:CSIReportOffsetShiftedByProcessingDelay', ...
    'The report transmission calendar must be independent of source-slot plus processing-delay projection.');
end
