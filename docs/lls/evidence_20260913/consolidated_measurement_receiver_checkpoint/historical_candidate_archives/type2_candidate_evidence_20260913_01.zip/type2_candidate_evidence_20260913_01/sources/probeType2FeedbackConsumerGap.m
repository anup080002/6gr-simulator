function probeType2FeedbackConsumerGap()
% Deliberately RED integration-gap probe. Declared MAC inputs, not RF or
% received-waveform evidence. Do not add to a passing suite until integrated.
setup6GRSimToolkit('Verbose',false);
cfg=sixgr.config.defaultConfig();
cases={struct('Name',"leading",'Ordinals',2), ...
    struct('Name',"interior",'Ordinals',[1 3]), ...
    struct('Name',"wrapped",'Ordinals',[1 5])};
wrong=0;
for ci=1:numel(cases)
    c=cases{ci}; n=max(c.Ordinals); received=c.Ordinals;
    events=repmat(struct('DAI',1,'EventIndex',1,'PDSCHID',"", ...
        'Priority',0,'ServingCell',1,'State',"ACK",'ConfigurationEpoch',2, ...
        'TargetSlot',10,'RNTI',321),numel(received),1);
    for k=1:numel(received)
        events(k).DAI=mod(received(k)-1,4)+1;
        events(k).EventIndex=received(k);
        events(k).PDSCHID="declared-DL-"+received(k);
    end
    book=sixgr.phy.pucch.HARQACKCodebookBuilder.build('TYPE2_DYNAMIC',events,2);
    assert(numel(book.Bits)==n && all(book.Bits(received)==1));
    assert(isequal(find(book.SourceEventIndex>0),received(:)));
    assert(all(book.Bits(book.MissingAssignmentMask)==0));
    h=sixgr.l2.mac.HARQEntity(cfg,'Direction','DL');
    layout=sixgr.phy.phycode.resolveCodingLayout('Direction','DL', ...
        'TransportBlockSize',800,'TargetCodeRate',.3,'RV',0, ...
        'Modulation','QPSK','NumLayers',1,'RateMatchedBitCount',2748);
    grant=struct('TBSBits',800,'Direction',"DL",'Modulation',"QPSK", ...
        'NumLayers',1,'TargetCodeRate',.3,'CodingLayout',layout);
    ids=zeros(1,n); buffers=cell(1,h.NumProcesses);
    for k=1:n
        a=h.allocate(321,k,100,'NewData',true);
        ids(k)=a.HARQ.HarqID;
        h.onTx(321,ids(k),ones(800,1,'uint8'),grant,k);
        soft=struct('LLRSum',[k;-k],'ObservationWeight',1);
        h.storeSoftBuffer(321,ids(k),soft);
        buffers{ids(k)+1}=soft.LLRSum;
    end
    rows=table();
    for k=received
        row=struct('RNTI',321,'UEIndex',1,'HarqID',ids(k),'Direction',"DL", ...
            'FeedbackForDirection',"DL",'SourceSlot',k,'DueSlot',10, ...
            'ServingCell',1,'TBSBits',800,'RV',0,'IsRetransmission',false, ...
            'Ack',true,'Processed',false,'PUCCHGrantId',"declared-DL-"+k, ...
            'UCIType',"harq_ack");
        rows=[rows;struct2table(row)]; %#ok<AGROW>
    end
    recorder=FeedbackDispositionRecorder();
    state=struct('CfgMobility',struct(),'DLHarq',h,'ULHarq',h, ...
        'DLSchedulers',{{recorder}},'ULSchedulers',{{recorder}}, ...
        'DLCombinedLLR',{buffers},'ULCombinedLLR',{buffers}, ...
        'PUCCHGrantTraceTable',table(),'PendingFeedbackTable',table(), ...
        'ControlTrials',struct('PUCCH',table()));
    % Ideal decoded-vector input is explicitly declared. This isolates
    % disposition; no detector performance or actual UCI reception is claimed.
    observed=struct('DecodeOk',true,'DTXFlag',false,'DecodedBits',book.Bits);
    sixgr.truth.CoupledTruthRuntime.applyObservedPUCCHFeedbackRuntime(state,rows,observed);
    actual=strings(numel(recorder.Updates),1);
    for k=1:numel(actual), actual(k)=string(recorder.Updates{k}.Outcome); end
    mismatch=nnz(actual~="ACK");
    omitted=n-numel(recorder.Updates);
    wrong=wrong+mismatch+omitted;
    fprintf('TYPE2_CONSUMER_GAP case=%s bits=%s received_ordinals=%s outcomes=%s wrong_received=%d omitted_gnb_obligations=%d declared_MAC_only=1\n', ...
        c.Name,mat2str(book.Bits.'),mat2str(received),strjoin(actual,','),mismatch,omitted);
end
assert(wrong==0,'test:Type2FeedbackConsumerIntegrationGap', ...
    'Row-index disposition cannot consume Type-2 gap/wrap positions and independent gNB obligations.');
end
