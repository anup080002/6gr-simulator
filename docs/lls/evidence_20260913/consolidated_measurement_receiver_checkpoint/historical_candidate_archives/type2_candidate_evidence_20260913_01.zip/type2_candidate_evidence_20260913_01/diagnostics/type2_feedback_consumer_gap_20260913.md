# Type-2 normal feedback consumer: isolated red reproduction

Revision: 8412775e52ffba94f2cb9cb6dc9779d6ac54192a
Scope: declared MAC inputs and the real Type-2 codebook builder/HARQ reducer.
Not a received-DCI, actual-PUCCH, actual-PUSCH, or 12 dB qualification.
This probes an already documented integration gap; it does not establish a
regression introduced by the latest stale-feedback repair.

## Frozen-source test

External test: C:/Users/anup0/AppData/Local/Temp/sixgr_type2_mapping_probe_94c9cc53573247c6b73a9ecb12de0ff4/probeType2FeedbackConsumerGap.m
Test SHA-256: 70bad8827ba5ef7bda1f3ebcfb10a5ea7a2dd899af4daea27736f098ec7c0779
Log: logs/type2_feedback_consumer_gap_red_01.log
Log SHA-256: 9fc8e4472db413722ad9ccdad9b286b6ad7f90a217bbd5d921dba680e2247e04
MATLAB process exit: 1, expected red assertion
Identifier: test:Type2FeedbackConsumerIntegrationGap
The eight latest repair source SHA-256 values were rechecked after exit and
matched the committed evidence receipt. Git status remained clean.
The external test is not registered in testAll and is not yet committed.

The probe constructs protocol gap/wrap positions using HARQACKCodebookBuilder,
then feeds its bits as an explicitly ideal, declared decoded-vector input to
applyObservedPUCCHFeedbackRuntime. Real HARQ entities hold distinct declared
800-bit TBs for every scheduled ordinal. No waveform is generated, no decoder
is run, no RF/noise/power is altered, and no result is labeled radio truth.

| Case | Codebook bits | UE rows for ordinals | Actual updates | Omitted scheduled obligations |
| --- | --- | --- | --- | --- |
| Leading gap | 0 1 | 2 | NACK | 1 |
| Interior gap | 1 0 1 | 1, 3 | ACK, NACK | 1 |
| Wrapped DAI | 1 0 0 0 1 | 1, 5 | ACK, NACK | 3 |

All received-event ordinals in these declared cases have ACK. The last ACK
was misapplied in every case because bit index followed row index. The
omitted count is the declared schedule count minus actual scheduler calls;
it is not a waveform-detection statistic.

## Source trace at this revision

- prepareSharedPUCCHFeedbackRuntime selects PUCCHGrantTraceTable rows.
  buildReceivedHARQACKCodebook is only called in its absent-producer branch,
  where it guards that no received events were lost.
- observePUCCHFeedback constructs expectedBits from rowExpectedPUCCHAck, one
  bit per HARQ row, then passes that raw vector to planHARQ/planCombined.
- applyObservedPUCCHFeedback calls resolveReceivedHARQBit(observedFeedback,i,...)
  for each row i. It does not consume buildScheduledHARQACKMapping.
- multiplexDueHARQACKOnPUSCHImpl sorts pending source-slot/HARQ rows and
  constructs ackBits from AckBit, then creates PUSCHUCIPayload without its
  available HARQACKReport binding.
- markFeedbackRowsReservedForPUSCH similarly records row-ordinal bit indices.
- consumeDecodedPUSCHHARQACK uses numel(expectedBits) and demands exactly one
  pending-row/grant/source-slot/process for every bit. That is incompatible
  with protocol-gap positions that have no received UE event.
- The independent gNB receive-only helper correctly starts from actual
  transmitted DL obligations, but currently requires HARQ-only config:
  CSI off, UCI-on-PUSCH off, and explicitly empty SR resources. It cannot be
  silently reused to claim combined baseline integration.

## Next atomic integration boundary

1. Normal shared UE preparation must use available received-event codebooks,
   and received UL DCI total DAI for PUSCH, retaining source-event positions.
   Protocol-gap NACK positions must not manufacture UE decoder events.
2. Build gNB receive length/resource and per-bit identity from its own
   physically executed schedule and installed RRC. Do not derive it from
   the UE book, serialized report, TX payload, expected ACK bits or row count.
3. Interpret real decoded bits with that independent gNB mapping, including
   scheduled assignments without a UE feedback row; bind process, NDI,
   source attempt and physical occasion before mutation. Reuse the actual
   HARQ acceptance disposition, single-owner and stale-buffer guards.
4. Bind CSI/SR and PUSCH transport ownership before IQ preparation, including
   missing-DCI/no-producer occasions. No duplicate physical transmission or
   fake grant rows may be introduced to satisfy a one-row-per-bit assumption.
5. Then replace this declared diagnostic with actual shared received-DCI and
   waveform gap/wrap/retained-ACK/CSI/PUSCH cases, retain IQ and trace evidence,
   and rerun mandatory final-source regression and 12 dB measurement gates.

All three existing validation jobs were revalidated live in this turn.
No source checkout was changed or suite restarted. The current committed
revision guard batch has passed config, both strict guards, DL and UL so far.
Final full-suite and baseline statuses remain pending.
