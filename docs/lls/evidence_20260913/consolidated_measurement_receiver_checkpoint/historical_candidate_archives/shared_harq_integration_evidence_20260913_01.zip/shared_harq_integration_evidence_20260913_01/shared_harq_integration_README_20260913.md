# Shared HARQ-only PUCCH integration candidate

Status: STAGED, UNAPPLIED, UNCOMMITTED, NOT PUSHED. No 12 dB pass claim.

Base: 8412775e52ffba94f2cb9cb6dc9779d6ac54192a.
Stage: consolidated_shared_harq_stage_20260913 (34 files, 31 MATLAB files).
Applicable patch: pending_consolidated_shared_harq_20260913_02.patch.
Patch SHA256: 6E2C763A64C6DE1A87BDBF3AE58135CEECC552C61BD5410AD0F1425AE5679EF7.
Git reports 1668 insertions and 124 deletions; `git apply --check
--whitespace=error` passed against the base without applying anything.
This supersedes the 31-file receiver-fields candidate and retains all its
CRC, independent trial receiver, CSI-clock, preview, PRACH and noise-capture edits.
All earlier candidate stages and evidence are preserved.

## Concrete runtime change

The normal shared-PUCCH preparation now recognizes the installed DL HARQ-only
case: CSI reporting disabled by configuration, UCI-on-PUSCH disabled by
configuration, explicitly empty installed SR resource IDs, no pending CSI
payload on this occasion. The patch does not change any configuration value.
Combined CSI/SR and PUSCH paths remain unfinished and are not qualified by this branch.

For that case, preparation obtains the typed Type-2 codebook from the actual
UE received-event ledger through buildReceivedHARQACKCodebook. Pending rows
are bound by UE/RNTI/data slot/HARQ process/feedback slot, not by ACK values or
row ordinal. The last received event selects the producer bookkeeping row
and received PRI. The typed codebook, including protocol NACK gap positions,
is passed to the existing production PUCCH planner and encoder.

The independent gNB allocation and expected HARQ count come from the actual
transmitted DL schedule and installed RRC. The receive boundary receives only
its typed Assignment and payload-free Context, never the scheduling ledger.
The scheduling/assignment digests and logical associations are revalidated
at completion. Received bits enter the common scheduled HARQ commit once;
the legacy row-ordered HARQ mutation is skipped for this branch. Existing
producer traces are updated by gNB bit identity; a missing-DCI obligation
does not generate a fake UE grant row. Actual schedule dispositions remain
in SharedGNBUCIHARQTable. Trial metadata records UE codebook and gNB mapping
digests, independent assignment identity, and receiver expected HARQ count.
No detector threshold, RF gain, noise, channel model or qualification gate changed.

Protocol basis: repository Type-2 implementation of TS 38.213 V18.8.0,
sections 9.1.3 and 9.2; reviewed against the ETSI publication:
https://www.etsi.org/deliver/etsi_ts/138200_138299/138213/18.08.00_60/ts_138213v180800p.pdf
This is not a universal standards-conformance claim.

## Completed validation

- Exact staged testSharedPUCCHCodebookBinding and both new binding helpers
  executed in an isolated minimal package with exact base dependencies.
  MATLAB R2026a -nojvm -singleCompThread, sessions 91239 and 50813, both exit 0.
- Declared protocol fixtures cover middle missing-DCI NACK insertion,
  actual typed UCI serialization, DAI wrap, reordered producer tables,
  unchanged results under contradictory scoring ACKs, and 16 negative guards.
  These fixtures are explicitly not PHY or received-DCI execution evidence.
- Static Code Analyzer completed all 31 staged MATLAB files and corresponding
  base files, exit 0. All 484 diagnostics are retained. They include 31
  environmental warnings about an unreadable configured R2025b analyzer
  settings file; MATLAB used defaults. No syntax-error diagnostic was reported.
  Existing files have no additional ID/message diagnostics after accounting
  for changed line references. Warnings were not suppressed or settings changed.
- Patch version 01 failed its application/whitespace check because the
  PowerShell diff assembly retained carriage returns. It is preserved as an
  unsuccessful packaging attempt. Version 02 normalizes patch line endings
  only and passed. No source checkout was altered by either check.

## Still required

The new shared preparation/completion branch has NOT been executed with an
actual shared owner on this revision. Actual normal/missing-DCI/gap/wrap/retained
ACK and independent receiver waveform integration must be run, followed by
the final-source testAll and applicable NR, config, strict, scheduler, export
and E2E gates. The three pre-existing full suites are left running unchanged;
they cannot validate this staged revision.

Independent combined CSI/SR and PUSCH integration, detector false/missed-ACK
qualification, CSI/report-calendar and timing closure, all-measurement closure,
actual 12 dB execution, sweep, main consolidation and GitHub publication remain.
The later full-impairments long-run objective is unchanged.
