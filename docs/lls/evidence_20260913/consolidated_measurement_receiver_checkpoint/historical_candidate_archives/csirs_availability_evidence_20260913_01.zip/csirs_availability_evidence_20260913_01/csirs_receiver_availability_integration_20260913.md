# CSI receiver availability: confirmed reducer defect and integration boundary

Revision inspected: 8412775e52ffba94f2cb9cb6dc9779d6ac54192a.
Status: open; no production source or YAML edits applied during frozen regression.

## Executed boundary regression

`probeCSIRSAvailabilityBackdating.m` calls the production applyCSIRSTrial and
consumeReferenceSignalMeasurementRuntime methods with a DECLARED test row.
It does not execute CSI-RS, report a measured RF result, or export a primary
measurement table. All signal-availability flags are fixture inputs.

The source slot is 4, the declared delivery slot and current slot are 9.
The production reducer publishes AvailableSlot=4; the production consumer
then returns Usable=true for a slot-8 knowledge query. The expected assertion
fails with test:CSIRSAvailabilityBackdated (MATLAB exit 1).
This proves that the reducer ignores this delivery field. It does not by
itself prove a particular completed waveform campaign used future CSI.

Files: csirs_availability_backdating_red_01.log and .csv.

## Source trace and repair consequences

1. CoupledTruthRuntime.applyCSIRSTrialImpl publishes ProducerSlot and
   AvailableSlot from row.Slot. This differs from the explicit received-clock
   delivery contracts already present for SRS/TRS/SSB.
2. runWaveformLinkBundle.localCompleteSharedDataPlan has the complete physical
   receiver observation and the owner Events.NextSampleIndex. It already
   constructs res.HARQ.ReceivedTimingEvidence from actual prepared transmission,
   receive timing, and observation. Bind CSI measurement availability to
   that same actual completion event, without borrowing HARQ decisions.
3. CSI report generation cannot read a transmitter row to invent its own
   observation clock. Preserve source slot, capture interval, sample rate,
   result-available sample, UE/resource/configuration identity separately.
4. Merely changing AvailableSlot to CurrentSlot is not enough for reports
   prepared inside a slot: causalMeasurementState currently compares slots,
   not samples. A slot-start consumer must not see a measurement produced
   later in that slot. Use sample-exact knowledge checks for shared-clock
   consumers, or an explicitly conservative next-slot-start delivery boundary
   for slot-only consumers. Do not round an intra-slot completion backward.
5. The normal shared CSI measurement route is inside data completion. The
   received-DCI guard and retained-HARQ early return precede executeGrantPHYJob.
   An independent configured CSI-RS receiver is therefore needed for no-data,
   missed-DCI, and retained-ACK cases; do not solve periodic reporting by
   manufacturing a PDSCH completion. Audit the physical CSI-RS waveform owner
   and RE exclusions together, so a standalone path does not transmit twice.
6. Integrate this boundary with the already identified periodic-report
   calendar and independent gNB combined-UCI receive obligations. A corrected
   YAML report offset alone cannot establish measurement causality.

## Required integrated regressions

- Actual shared CSI-RS observation whose receive tail crosses a slot boundary.
- A report prepare event immediately before and after measurement completion
  in the same slot, using sample-exact ordering.
- Periodic report with retained older, available measurement; no fresh PDSCH.
- Missing measurement remains unavailable: no synthetic CQI/PMI/RI/CRI.
- Missed PDCCH and retained HARQ ACK do not suppress independent CSI-RS
  measurement when its configured waveform/resource is actually present.
- CSI-RS resource/configuration epoch changes and independent sweep reset
  cannot reuse ineligible measurements.
- Receiver obligations and layout remain independent of UE report payload;
  combined UCI and PUSCH transport are each physically decoded and scored.
- Full required final-source tests, then actual 12 dB measurement/export audit.

The NR-validation skill guided the actual-receiver timing requirement; the
config-driven skill keeps waveform/report calendars explicit and distinct.
This audit is not a repair-complete or 12 dB qualification receipt.
