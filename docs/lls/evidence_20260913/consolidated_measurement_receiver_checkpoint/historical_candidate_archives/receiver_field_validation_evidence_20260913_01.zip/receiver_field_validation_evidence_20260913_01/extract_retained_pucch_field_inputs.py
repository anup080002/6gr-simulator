"""Extract only recorded numeric RX fields for a small JVM-free MATLAB audit.

This does not generate or decode IQ. Originals are read-only; source hashes
bind the extracted numeric views to the prior actual component execution.
"""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
from scipy.io import loadmat, savemat


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert not args.output.exists()
    args.output.mkdir(parents=True)
    manifest=[]
    for source in sorted(args.source.glob('tx_*_rx_*.mat')):
        with source.open('rb') as stream:
            digest=hashlib.file_digest(stream,'sha256').hexdigest()
        data=loadmat(source,variable_names=['trial','direct','txCount','rxCount'],simplify_cells=True)
        original=data['trial']
        receiver=original['Receiver']
        fields={name:np.asarray(receiver['DecodedFields'][name]).reshape(-1,1)
                for name in ['HARQACK','SR','CSIPart1','CSIPart2']}
        for name,value in fields.items():
            assert np.array_equal(value.reshape(-1),np.asarray(data['direct']['DecodedFields'][name]).reshape(-1))
            assert np.isin(value,[0,1]).all()
        trial={name:original[name] for name in [
            'ReceiverExpectedBitCount','ReceiverExpectedHARQBitCount','ReceiverExpectedSRBitCount',
            'ReceiverExpectedCSIPart1BitCount','ReceiverExpectedCSIPart2BitCount']}
        trial['ReceiverFields']=fields
        trial['Receiver']={
            'DecodedSequence1':np.asarray(receiver['DecodedSequence1']).reshape(-1,1),
            'DecodedSequence2':np.asarray(receiver['DecodedSequence2']).reshape(-1,1),
            'DecodedFields':fields}
        target=args.output/source.name
        savemat(target,dict(trial=trial,txCount=data['txCount'],rxCount=data['rxCount'],
                sourceSHA256=digest,sourcePath=str(source),
                scope='retained_actual_RX_numeric_field_extraction_not_new_PHY_execution'),
                do_compression=True,long_field_names=True)
        manifest.append(dict(source=str(source),source_sha256=digest,extracted_file=target.name,
                             tx_bits=int(data['txCount']),rx_bits=int(data['rxCount'])))
    assert len(manifest)==4
    with (args.output/'manifest.json').open('w',encoding='utf-8') as stream:
        json.dump(manifest,stream,indent=2)
    print(json.dumps(manifest,indent=2))


if __name__=='__main__':
    main()
