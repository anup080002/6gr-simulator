function ok=testRetainedPUCCHReceiverFields(inputRoot,outputFile)
% Extraction of previously recorded numeric RX fields, not a new PHY run.
listing=dir(fullfile(inputRoot,'tx_*_rx_*.mat'));
assert(numel(listing)==4 && ~isfile(outputFile));
rows=cell(4,1);
for k=1:numel(listing)
    x=load(fullfile(listing(k).folder,listing(k).name));
    [report,layoutOK]=sixgr.truth.extractPUCCHReceiverFields(x.trial);
    assert(layoutOK);
    f=x.trial.Receiver.DecodedFields;
    assert(isequal(report.HARQACKBits,int8(f.HARQACK(:))) && ...
        isequal(report.SRBits,int8(f.SR(:))) && ...
        isequal(report.CSIPart1Bits,int8(f.CSIPart1(:))) && ...
        isequal(report.CSIPart2Bits,int8(f.CSIPart2(:))));
    changed=x.trial;
    changed.ExpectedBits=int8(zeros(x.txCount+7,1));
    changed.Transmitter=struct('Serialization','must not be consumed');
    [other,otherOK]=sixgr.truth.extractPUCCHReceiverFields(changed);
    assert(otherOK && isequaln(report,other));
    rows{k}=struct('TXBits',double(x.txCount),'ReceiverExpectedBits',double(x.rxCount), ...
        'LayoutOK',layoutOK,'DecodedHARQBits',numel(report.HARQACKBits), ...
        'HARQBits',string(sprintf('%d',report.HARQACKBits)), ...
        'SourceSHA256',string(x.sourceSHA256), ...
        'EvidenceScope',"retained_actual_RX_field_extraction_not_new_PHY_or_CRC_qualification");
    fprintf('RETAINED_PUCCH_FIELD_PASS tx_bits=%d receiver_expected_bits=%d harq_bits=%d\n', ...
        x.txCount,x.rxCount,numel(report.HARQACKBits));
end
writetable(struct2table(vertcat(rows{:})),outputFile);
fprintf('RETAINED_PUCCH_FIELD_EXTRACTION_PASS cases=4 no_new_PHY_execution=1\n');
ok=true;
end
