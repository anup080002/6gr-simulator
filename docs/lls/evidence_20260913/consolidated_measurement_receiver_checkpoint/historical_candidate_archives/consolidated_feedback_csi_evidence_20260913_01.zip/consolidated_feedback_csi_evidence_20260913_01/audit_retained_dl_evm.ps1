param(
    [Parameter(Mandatory=$true)][string]$ConstellationCsv,
    [Parameter(Mandatory=$true)][string]$TrialCsv,
    [Parameter(Mandatory=$true)][string]$FixtureSource,
    [Parameter(Mandatory=$true)][string]$OutputDirectory
)
$ErrorActionPreference='Stop'
if (Test-Path -LiteralPath $OutputDirectory) { throw 'Preserve the existing audit directory.' }
$culture=[Globalization.CultureInfo]::InvariantCulture
$reader=[IO.File]::OpenText((Resolve-Path -LiteralPath $ConstellationCsv).Path)
$count=0; $errorSum=0.0; $referenceSum=0.0; $meanRe=0.0; $meanIm=0.0
$bySymbol=@{}
try {
    $header=$reader.ReadLine().Split(',')
    $names=@(0..($header.Length-1) | ForEach-Object { 'c'+$_ })
    $keys=@{}
    foreach ($field in @('ReferenceSymbolReal','ReferenceSymbolImag','EqualizedReal','EqualizedImag',
            'RawEqualizedReal','RawEqualizedImag','OFDMSymbolIndex','Normalization','ObservationSymbolCount','CapturedSymbolCount')) {
        $index=[Array]::IndexOf($header,$field)
        if ($index -lt 0) { throw "Missing source field $field" }
        $keys[$field]=$names[$index]
    }
    while ($null -ne ($line=$reader.ReadLine())) {
        # Unique parser headers avoid case-insensitive collisions in the
        # exported Direction/direction aliases. CSV quoting remains parsed.
        $r=ConvertFrom-Csv -InputObject $line -Header $names
        if ($r.($keys.Normalization) -ne 'receiver_equalized_symbols_average_reference_power_no_payload_fit') {
            throw 'This audit requires unfitted receiver symbols.'
        }
        $tr=[double]::Parse($r.($keys.ReferenceSymbolReal),$culture)
        $ti=[double]::Parse($r.($keys.ReferenceSymbolImag),$culture)
        $xr=[double]::Parse($r.($keys.EqualizedReal),$culture)
        $xi=[double]::Parse($r.($keys.EqualizedImag),$culture)
        if ($xr -ne [double]::Parse($r.($keys.RawEqualizedReal),$culture) -or
            $xi -ne [double]::Parse($r.($keys.RawEqualizedImag),$culture)) { throw 'Receiver symbols were transformed after raw capture.' }
        $er=$xr-$tr; $ei=$xi-$ti; $e=$er*$er+$ei*$ei; $p=$tr*$tr+$ti*$ti
        $count++; $errorSum+=$e; $referenceSum+=$p; $meanRe+=$er; $meanIm+=$ei
        $symbol=[int]$r.($keys.OFDMSymbolIndex)
        if (-not $bySymbol.ContainsKey($symbol)) { $bySymbol[$symbol]=@{n=0;error=0.0;power=0.0} }
        $bySymbol[$symbol].n++; $bySymbol[$symbol].error+=$e; $bySymbol[$symbol].power+=$p
        $observed=[int]$r.($keys.ObservationSymbolCount); $captured=[int]$r.($keys.CapturedSymbolCount)
        if ($observed -ne $captured) { throw 'The capture is not the full allocation.' }
    }
} finally { $reader.Dispose() }
if ($count -ne $observed -or $count -eq 0 -or $referenceSum -le 0) { throw 'Capture cardinality/power mismatch.' }
$trial=@(Import-Csv -LiteralPath $TrialCsv)
if ($trial.Count -ne 1) { throw 'This audit requires the single retained DL trial.' }
$evm=[math]::Sqrt($errorSum/$referenceSum)
$reported=[double]::Parse($trial[0].EVM_rms,$culture)
if ([math]::Abs($evm-$reported) -gt 1e-12) { throw 'Reported EVM disagrees with the raw full-allocation pairs.' }
$result=[ordered]@{
    EvidenceClass='retained_DL_component_CSV_arithmetic_not_12dB_or_PHY_qualification'
    RawSymbolCount=$count; ErrorEnergy=$errorSum; ReferenceEnergy=$referenceSum
    RecomputedEVM=$evm; ReportedEVM=$reported; RecomputedEVMPercent=100*$evm
    MeanResidualReal=$meanRe/$count; MeanResidualImag=$meanIm/$count
    ResidualPower=$errorSum/$count; PublishedPostEqualizationVariance=[double]::Parse($trial[0].PostEqualizationNoiseVariance,$culture)
    CFOApplied=$trial[0].CFOApplied; EstimatedCFO_Hz=$trial[0].EstimatedCFO_Hz
    NominalConnectorNoiseCheck=[ordered]@{
        Role='declared_unit_RE_77dB_connector_estimate_not_independent_receiver_measurement'
        SampleVariance=1e-13; SampleToGridGain=512; ConnectorLoss_dB=77; UnitTransmitREEnergy=1
        IdealUnbiasedSingleBranchEVM=[math]::Sqrt(512*1e-13/[math]::Pow(10,-77/10))
        ExistingFixtureEVMLimit=0.02
    }
    Inputs=@($ConstellationCsv,$TrialCsv,$FixtureSource | ForEach-Object {
        [ordered]@{path=(Resolve-Path -LiteralPath $_).Path; sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash}
    })
}
New-Item -ItemType Directory -Path $OutputDirectory | Out-Null
$symbolRows=@($bySymbol.Keys | Sort-Object | ForEach-Object {
    [PSCustomObject]@{OFDMSymbol=$_; SymbolCount=$bySymbol[$_].n; ErrorEnergy=$bySymbol[$_].error;
        ReferenceEnergy=$bySymbol[$_].power; EVMPercent=100*[math]::Sqrt($bySymbol[$_].error/$bySymbol[$_].power)}
})
$symbolRows | Export-Csv -LiteralPath (Join-Path $OutputDirectory 'evm_by_ofdm_symbol.csv') -NoTypeInformation
[IO.File]::WriteAllText((Join-Path $OutputDirectory 'audit.json'),($result | ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
[PSCustomObject]@{Status='RAW_CSV_EVM_RECOMPUTATION_PASS'; Symbols=$count; EVMPercent=100*$evm;
    NominalNoiseEVMPercent=100*$result.NominalConnectorNoiseCheck.IdealUnbiasedSingleBranchEVM;
    SourceOrThresholdChanged=$false} | Format-List
